﻿# Configuración de VS Code

Esta es la guía de referencia de configuración de VS Code para **bac-ai-stack**.

---

> [!TIP]
> **¿Cómo abrir un setting?**
> 1. Presioná `Ctrl+,` (Windows/Linux) o `Cmd+,` (Mac) para abrir la **UI de Settings**.
> 2. Copiá el nombre del setting de la columna **Setting** y pegalo en el buscador.
> 3. El setting aparece directamente — activalo o configuralo según la descripción.
>
> Alternativamente, podés abrir la **Command Palette** con `Ctrl+Shift+P` → escribir `Open User Settings (UI)` → buscar el setting.

---

## Categorías

- [Copilot Features](#copilot-features)
- [Agents](#agents)
- [Sub-agents](#sub-agents)
- [Skills](#skills)
- [MCPs](#mcps)
- [Plugins](#plugins)

---

## Copilot Features

Features opcionales y experimentales de GitHub Copilot. Mejoran la experiencia de desarrollo pero no son obligatorias para usar los agentes del repositorio. Algunas están en fase preview y requieren la última versión de la extensión.

| Setting | Descripción | Estado |
|---|---|---|
| `github.copilot.chat.codesearch.enabled` | Búsqueda de código del agente cuando se utiliza el modificador #codebase | <img src="https://img.shields.io/badge/Estado-Recomendado-blue?style=plastic" /> |
| `github.copilot.chat.reviewSelection.enabled` | Habilita la revisión de código en la selección actual | <img src="https://img.shields.io/badge/Estado-Recomendado-blue?style=plastic" /> |
| `github.copilot.chat.scopeSelection` | Solicita al usuario que seleccione un ámbito de símbolo cuando se usa /explain sin selección | <img src="https://img.shields.io/badge/Estado-Opcional-lightgrey?style=plastic" /> |

---

## Agents

Habilita el **modo agente** en GitHub Copilot Chat. Sin estos settings, el selector de modo no mostrará la opción "Agent" y los agentes del repositorio no estarán disponibles.

| Setting | Descripción | Estado |
|---|---|---|
| `chat.agent.enabled` | Habilita el modo agente desde el chat. Permite el uso de herramientas en contextos que pueden generar efectos secundarios | <img src="https://img.shields.io/badge/Estado-Requerido-brightgreen?style=plastic" /> |
| `github.copilot.chat.agent.autoFix` | Corrige automáticamente los diagnósticos de los archivos editados | <img src="https://img.shields.io/badge/Estado-Recomendado-blue?style=plastic" /> |

---

## Sub-agents

Controla la capacidad de los agentes para invocar a otros sub-agentes dentro del flujo de ejecución. Estos settings permiten patrones de orquestación donde un agente delega trabajo a sub-agentes especializados.

| Setting | Descripción | Estado |
|---|---|---|
| `chat.customAgentInSubagent.enabled` | Controla si los sub-agentes pueden invocar a otros sub-agentes. El anidamiento se limita a profundidad máxima de 5 | <img src="https://img.shields.io/badge/Estado-Recomendado-blue?style=plastic" /> |
| `chat.subagents.allowInvocationsFromSubagents` | Controla si los sub-agentes pueden invocar a otros sub-agentes (control granular). Anidamiento máximo = 5 | <img src="https://img.shields.io/badge/Estado-Recomendado-blue?style=plastic" /> |

---

## Skills

Habilita el sistema de skills especializadas para chat y controla cómo los agentes pueden invocarlas. Las skills se cargan desde carpetas configuradas y el modelo puede cargarlas a demanda.

| Setting | Descripción | Estado |
|---|---|---|
| `chat.useAgentSkills` | Controla si las habilidades se proporcionan como funcionalidades especializadas para las solicitudes de chat | <img src="https://img.shields.io/badge/Estado-Requerido-brightgreen?style=plastic" /> |
| `chat.experimental.useSkillAdherencePrompt` | Usa un prompt más estricto de cumplimiento que anima al modelo a invocar inmediatamente las skills relevantes | <img src="https://img.shields.io/badge/Estado-Recomendado-blue?style=plastic" /> |
| `github.copilot.chat.getSearchViewResultsSkill.enabled` | Habilita la skill de resultados de la vista de búsqueda y deshabilita la herramienta correspondiente | <img src="https://img.shields.io/badge/Estado-Recomendado-blue?style=plastic" /> |
| `github.copilot.chat.skillTool.enabled` | Habilitar ventana de contexto aislada para skills | <img src="https://img.shields.io/badge/Estado-Recomendado-blue?style=plastic" /> |

---

## MCPs

Controla el acceso a los **Model Context Protocol (MCP) servers** instalados. Los MCP servers en sí (Engram, GitHub, etc.) se configuran en `mcp.json`, no en `settings.json`. Estos settings controlan el comportamiento global de los MCP servers.

| Setting | Descripción | Estado |
|---|---|---|
| `chat.mcp.access` | Controla el acceso a servidores MCP instalados: none (sin acceso), registry (solo del registro), all (todos) | <img src="https://img.shields.io/badge/Estado-Requerido-brightgreen?style=plastic" /> |
| `chat.mcp.gallery.enabled` | Habilita el Marketplace predeterminado para servidores MCP | <img src="https://img.shields.io/badge/Estado-Recomendado-blue?style=plastic" /> |
| `chat.mcp.apps.enabled` | Controla si los servidores MCP pueden proporcionar una interfaz de usuario personalizada para invocaciones | <img src="https://img.shields.io/badge/Estado-Opcional-lightgrey?style=plastic" /> |
| `chat.mcp.autostart` | Controla si los servidores MCP deben iniciarse automáticamente: never, onlyNew, o newAndOutdated | <img src="https://img.shields.io/badge/Estado-Recomendado-blue?style=plastic" /> |

---

## Plugins

> [!IMPORTANT]
> **Es el setting más crítico del repositorio** — sin él, ningún agente ni skill de bac-ai-stack será detectado, incluso si el workspace está correctamente abierto.

Habilita el sistema de plugins de VS Code Copilot Chat.

| Setting | Descripción | Estado |
|---|---|---|
| `chat.plugins.enabled` | Habilita la integración de complementos de agente en el chat | <img src="https://img.shields.io/badge/Estado-Requerido-brightgreen?style=plastic" /> |
| `chat.plugins.marketplaces` | Define los mercados de complementos disponibles: abreviaturas de GitHub (owner/repo), URIs directas o locales | <img src="https://img.shields.io/badge/Estado-Requerido-brightgreen?style=plastic" /> |

---
