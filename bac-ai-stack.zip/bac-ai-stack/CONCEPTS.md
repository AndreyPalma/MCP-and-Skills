<div align="center">

# Conceptos Clave del Ecosistema BAC AI Stack

Conceptos fundamentales del ecosistema `bac-ai-stack`. Antes de crear agentes, diseñar skills o configurar plugins, es imprescindible comprender la función exacta de cada pieza: qué responsabilidad tiene, qué problema resuelve y cómo se relaciona con las demás.

</div>

> [!IMPORTANT]
> Entender estos conceptos no es opcional. Confundirlos lleva a diseños frágiles: agentes sobrecargados que colapsan su ventana de contexto, skills que nunca se cargan, subagentes invocados sin el contexto que necesitan. Cada concepto existe porque resuelve un problema específico — y ese problema no desaparece si se ignora el concepto.

---

## Tabla de Contenidos

- [Plugin](#plugin)
- [Skill](#skill)
- [Agente](#agente)
- [Subagente](#subagente)
- [MCP (Model Context Protocol)](#mcp-model-context-protocol)
- [Herramientas integradas](#herramientas-integradas)

---

## Plugin

### ¿Qué es?

Un plugin es un **paquete autocontenido** que agrupa agentes, skills, hooks y servidores MCP bajo un único directorio con un manifiesto `plugin.json`. Con instalarlo una vez desde el repositorio, todo el equipo accede a las mismas herramientas sin configuración manual.

### ¿Para qué sirve?

Distribuye herramientas de IA de forma centralizada y versionada. Si el equipo agrega una nueva skill o un agente nuevo en el repositorio, el plugin lo propaga a todos los desarrolladores la próxima vez que hacen `git pull` — sin onboarding manual.

### ¿Cuándo usarlo?

Siempre. Todo en `bac-ai-stack` se distribuye como plugin. No hay herramientas sueltas fuera de un plugin.

### Ejemplo concreto

```
bac-ai-stack/
  plugins/
    code-reviewer/   ← Plugin para revisión automatizada de código
    doc-generator/   ← Plugin para generación de documentación técnica
```

Cada plugin tiene su `plugin.json` con metadatos (nombre, versión, descripción) y carpetas `agents/` y `skills/` con sus componentes.

### Anatomía de un plugin

```mermaid
flowchart TD
    PJ["📋 plugin.json\n(manifiesto: nombre, versión)"]
    AG["🤖 agents/\n*.agent.md"]
    SK["🧠 skills/\nNombre-skill/SKILL.md"]
    HK["⚙️ hooks/\nhooks.json"]
    MC[".mcp.json\nMCP servers del plugin"]
    RF["📚 references/\n*.md (conocimiento de dominio)"]

    PJ --> AG
    PJ --> SK
    PJ --> HK
    PJ --> MC
    SK --> RF
```

---

## Skill

### ¿Qué es?

Una skill es un **conjunto de instrucciones y referencias de dominio** que un agente carga bajo demanda. No es código ejecutable — es conocimiento estructurado en Markdown que le enseña al agente cómo comportarse en un contexto específico. Su punto de entrada siempre es un archivo `SKILL.md`.

### ¿Para qué sirve?

Evita que los agentes tengan todo el conocimiento hardcodeado en su system prompt. Las skills se cargan solo cuando son necesarias (carga a demanda / *progressive loading*), lo que mantiene la ventana de contexto limpia y el comportamiento especializado según la consulta.

### ¿Cuándo usarlo?

El agente lo hace automáticamente. Detecta el contexto del pedido del usuario, lee el `SKILL.md`, y carga los archivos de referencia pertinentes. No hace falta invocarlo manualmente — la skill se activa cuando el contexto lo amerita.

### Ejemplo concreto

Una skill `code-best-practices` puede tener dominios separados para nomenclatura, rendimiento, seguridad y manejo de errores. Si el archivo que se revisa no tiene consultas a base de datos, el dominio de SQL nunca se carga — el agente lee solo lo que necesita para esa consulta puntual.

### Flujo de carga de una skill

```mermaid
sequenceDiagram
    participant U as Usuario
    participant A as Agente
    participant S as SKILL.md
    participant R as references/

    U->>A: "Revisá este archivo, tiene consultas SQL"
    A->>S: Lee SKILL.md (siempre primero — obligatorio)
    S-->>A: Tabla de dominios + reglas de carga a demanda
    A->>R: Carga sql.md (hay consultas SQL en el archivo)
    R-->>A: Patrones SQL, criterios de rechazo, ejemplos
    A->>R: Carga security.md (SQL implica riesgo de inyección)
    R-->>A: Reglas de seguridad, detección de vulnerabilidades
    A->>U: Análisis completo basado en dominios pertinentes
```

---

## Agente

### ¿Qué es?

Un agente es un **coordinador de alto nivel** con una personalidad, herramientas y reglas de comportamiento definidas en un archivo `.agent.md`. Mantiene un hilo de conversación con el usuario y puede tanto ejecutar trabajo directamente como delegar tareas a subagentes según la complejidad del flujo. Es el único punto de entrada que el usuario invoca directamente.

### ¿Para qué sirve?

Coordina flujos de trabajo completos: lee contexto, toma decisiones, sintetiza resultados y presenta respuestas al usuario. Cuando el trabajo es intensivo o especializado, delegar a subagentes le permite preservar su ventana de contexto y escalar a tareas más grandes sin degradarse.

### ¿Cuándo usarlo?

Cuando querés arrancar un flujo de trabajo complejo. Lo invocás por nombre en el modo agente de VS Code Copilot Chat, describís lo que necesitás, y él se encarga del resto.

### Ejemplo concreto

Un agente orquestador de revisión de código — lo invocás cuando querés revisar un archivo. Para tareas simples puede responder directamente; para análisis profundos, delega al subagente analizador y, con tu confirmación, al subagente aplicador para aplicar los cambios.

### Buenas prácticas para un uso óptimo

Un agente orquestador puede técnicamente hacer cualquier cosa, pero delegar el trabajo intensivo a subagentes es lo que le permite mantener el contexto limpio y manejar tareas complejas sin degradarse. Estas son las prácticas recomendadas:

| Práctica | ¿Por qué ayuda? | ¿Quién suele hacerlo? |
|---|---|---|
| Delegar la lectura de archivos de código | Evita saturar el contexto principal con información que no necesita el orquestador | Subagente analizador |
| Delegar el análisis técnico detallado | El subagente carga solo las skills relevantes; el orquestador sintetiza el resultado | Subagente especializado |
| Delegar la edición de archivos | Mejora la trazabilidad y reversibilidad de los cambios | Subagente aplicador |
| Confirmar con el usuario antes de lanzar subagentes | El usuario mantiene el control del flujo en todo momento | — |

---

## Subagente

### ¿Qué es?

Un subagente es un **ejecutor especializado** diseñado para una tarea específica: leer y explorar, analizar, escribir, o verificar. Lo lanza el orquestador con contexto ya filtrado y relevante — el subagente nunca habla directamente con el usuario ni lanza otros subagentes encadenados (salvo diseño explícito).

### ¿Para qué sirve?

Ejecuta trabajo intensivo sin contaminar el contexto del orquestador. Cada subagente tiene herramientas limitadas a lo que necesita como por ejemplo solo poder leer archivos (nunca editar) para unicamente análisis.

### ¿Cuándo usarlo?

> [!WARNING]
> **Nunca directamente.** Están marcados con `user-invocable: false` en su frontmatter. Si los invocás sin el orquestador, no tienen el contexto pre-procesado que necesitan para funcionar correctamente y sus respuestas serán incompletas o incorrectas.

---

## MCP (Model Context Protocol)

### ¿Qué es?

MCP (Model Context Protocol) es un **protocolo abierto** que conecta modelos de IA con herramientas externas: bases de datos, APIs y sistemas de archivos remotos. Es como una interfaz USB estándar para herramientas de agentes.

### ¿Para qué sirve?

Extiende lo que un agente puede hacer más allá de los archivos del workspace local. Con MCP podés dar al agente acceso a GitHub (leer issues, crear PRs), a una base de datos remota, o a APIs externas que no están disponibles dentro de VS Code.

### ¿Cuándo usarlo?

Cuando el agente necesita datos o acciones que están fuera del workspace de VS Code. Se configura una vez en `mcp.json` y queda disponible para todos los agentes del workspace.

### Ejemplo concreto

**GitHub MCP** — permite que un agente lea issues abiertos, cree pull requests o consulte el historial de commits directamente desde el chat, sin salir de VS Code.

### Flujo de conexión MCP

```mermaid
flowchart LR
    VS["🖥️ VS Code\nCopilot Chat"]
    MJ["📄 .vscode/mcp.json\n(configuración)"]
    MS["⚙️ MCP Server\n(proceso local o remoto)"]
    EXT["☁️ Servicio externo\nGitHub · DB · API"]

    VS -->|"1. lee al arrancar"| MJ
    VS -->|"2. lanza proceso"| MS
    MS -->|"3. llama al API"| EXT
    EXT -->|"4. retorna datos"| MS
    MS -->|"5. tool result al agente"| VS
```

---

## Herramientas integradas

### ¿Qué es?

Una herramienta integrada es una **capacidad que VS Code o una extensión instalada expone directamente al agente**, sin necesidad de un servidor externo. Hay dos orígenes:

- **Nativas de VS Code** — están disponibles en cualquier instalación: leer archivos (`readFile`), editar archivos (`editFiles`), ejecutar comandos en la terminal integrada (`runInTerminal`), buscar texto en el workspace (`textSearch`), listar directorios, etc.
- **De extensiones** — extensiones instaladas en VS Code pueden registrar sus propias herramientas que los agentes pueden usar.

### ¿Para qué sirve?

Define exactamente qué puede y qué no puede hacer un agente. Cada agente declara en la sección `tools:` de su `.agent.md` la lista de herramientas habilitadas — esto funciona como una whitelist. Si una herramienta no está listada, el agente no puede usarla aunque esté disponible en el sistema.

### ¿Cuándo importa saberlo?

Cuando un agente no puede hacer algo que esperás. La causa más frecuente es que esa herramienta no está en su lista. Revisá la sección `tools:` del archivo `.agent.md` correspondiente. Si la herramienta viene de una extensión, también verificá que la extensión esté instalada y activa.

### Herramientas nativas más usadas

| Herramienta | Qué hace |
|---|---|
| `readFile` | Lee el contenido de un archivo del workspace |
| `editFiles` | Crea o edita archivos del workspace |
| `runInTerminal` | Ejecuta comandos en la terminal integrada de VS Code |
| `textSearch` | Busca texto (con regex) en todos los archivos del workspace |
| `listDirectory` | Lista el contenido de una carpeta |

### Diferencia con las herramientas de MCP

AMBOS, las herramientas integradas y los MCP, exponen "herramientas" que los agentes pueden invocar. La diferencia es dónde vive esa capacidad:

| Característica | Herramienta integrada | Herramienta de MCP |
|---|---|---|
| **Origen** | VS Code o una extensión instalada | Proceso externo (servidor MCP local o remoto) |
| **Configuración** | Declarada en `tools:` del `.agent.md` | Configurada en `mcp.json`; el servidor MCP debe estar corriendo |
| **Qué accede** | Workspace local, editor, terminal, extensiones del IDE | Sistemas externos: GitHub, bases de datos, APIs |

> [!TIP]
> **Regla práctica:** si la capacidad ya existe en tu VS Code o en una extensión instalada, es una herramienta integrada. Si necesita conectarse a un sistema que corre fuera de VS Code, es un MCP.

---
