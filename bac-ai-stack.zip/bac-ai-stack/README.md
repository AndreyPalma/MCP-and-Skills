<div align="center">

# BAC AI Stack

**El stack de IA para desarrolladores de BAC — consciente, controlado y compartido.**

![Agentes](https://img.shields.io/badge/🤖%20Agentes-orquestadores-4B8BBE?style=flat-square)
![Skills](https://img.shields.io/badge/🧠%20Skills-conocimiento-7E57C2?style=flat-square)
![MCP](https://img.shields.io/badge/⚙️%20MCP-herramientas%20externas-2E7D32?style=flat-square)
![Herramientas](https://img.shields.io/badge/🔧%20Herramientas-integradas%20VS%20Code-E65100?style=flat-square)

</div>

---

## Tabla de Contenidos

- [¿Qué es bac-ai-stack?](#qué-es-bac-ai-stack)
- [Prerequisitos](#prerequisitos)
- [Instalación](#instalación)
- [Resumen de componentes](#resumen-de-componentes)
- [Plugins disponibles](#plugins-disponibles)
- [Próximos pasos](#próximos-pasos)

---

## ¿Qué es bac-ai-stack?

`bac-ai-stack` es un **ecosistema versionado** que centraliza agentes, skills, MCPs, herramientas integradas y configuraciones de VS Code Copilot Chat en un solo repositorio controlado por Git. Lo clonás una vez y tenés todo el ecosistema listo para usar.

Hoy cada desarrollador configura "su Copilot", "sus prompts", "sus hacks". `bac-ai-stack` cambia ese modelo: **la IA deja de ser algo personal y pasa a ser parte del stack de BAC**.

Cada herramienta vive dentro de un **plugin**. Cuando alguien agrega un agente, skill, etc, todos los desarrolladores lo reciben automaticamente.

### 🧠 Desarrolladores como orquestadores

> **El desarrollador no delega el criterio. Delegar bien es parte del trabajo técnico.**
>
> Vos decidís **qué** hacer y **cómo** debe hacerse. Establecés el flujo, las reglas y los límites. La IA asiste, ejecuta y **escala** ese criterio.

```mermaid
flowchart LR
    DEV["👤 Desarrollador"]

    subgraph STACK["BAC AI Stack"]
        AG["🤖 Agentes"]
        SK["🧠 Skills"]
        MC["⚙️ MCPs"]
        HE["🔧 Herramientas"]
    end

    DEV -->|"decide, define, controla"| STACK
    STACK -->|"asiste y escala"| DEV
```

---

## Prerequisitos

Antes de instalar, verificá que tenés todo lo necesario:

| Herramienta | Versión mínima | Cómo verificar |
|---|:---:|---|
| VS Code | `1.99` | `code --version` |
| Extensión GitHub Copilot | Última estable | Menú `Extensions` → buscar "GitHub Copilot" |
| Extensión GitHub Copilot Chat | Última estable | Menú `Extensions` → buscar "GitHub Copilot Chat" |
| Git | `2.x` | `git --version` |

> [!NOTE]
> Si no tenés VS Code o Copilot instalados, seguí la [guía oficial de VS Code](https://code.visualstudio.com/docs/copilot/setup) antes de continuar.

---

## Instalación

### Paso 1 — Registrar el marketplace de plugins

Abrí la UI de Settings con `Ctrl+,`, buscá **`chat.plugins.marketplaces`** y agregá la siguiente URL en la lista:

```
BAC-Entornos-IBMi/bac-ai-stack
```

VS Code clonará el repositorio y lo dejará disponible en el marketplace de complementos del chat.

### Paso 2 — Activar la vista de complementos de agente

La sección **Complementos de agente** en el panel de Extensiones está **desactivada por defecto**. Sin este paso, no verás el marketplace ni los plugins instalados.

Para activarla:

1. Abrí el panel de **Extensiones** (`Ctrl+Shift+X`)
2. Hacé clic en el ícono `···` (menú de opciones) en la parte superior del panel
3. Seleccioná **Vistas**
4. Activá **Complementos de agente: instalados (Agent Plugins)**

La sección aparecerá en el panel y desde ahí podés acceder al marketplace.

### Paso 3 — Instalar el plugin

Abrí el marketplace de plugins desde el panel de Copilot Chat y buscá el plugin que necesitás (`ibmi-rpg`, `sdd-workflow`, etc.). Instalalo con un clic.

### Paso 4 — Configurar VS Code

Seguí la guía de configuración para habilitar todos los settings necesarios:

**[→ Guía de Configuración VS Code](SETUP.md)**

### Paso 5 — Verificar que funciona

Confirmá que el plugin está activo revisando sus tres componentes:

| Componente | Cómo verificar |
|---|---|
| **Agentes** | Presioná `Ctrl + .` en el chat; deberían aparecer los agentes del plugin instalado |
| **Skills** | Escribí `/skills` en el chat y presioná `Tab`; se despliegan todas las habilidades detectadas |
| **MCPs** | Abrí *Configurar herramientas* en el chat y verificá que los servidores MCP estén listados y activos |
| **Herramientas integradas** | En el mismo panel, verificá que las herramientas nativas de VS Code y extensiones aparezcan habilitadas |

---

## Resumen de componentes

| Componente | Qué hace |
|---|---|
| **Plugin** | Paquete de distribución que agrupa todo |
| **Agente** | Coordinar tareas y flujos completos; el usuario lo invoca directamente |
| **Subagente** | Ejecuta trabajo especializado; lo lanza el agente orquestador |
| **Skill** | Base de conocimiento de dominio; se carga a demanda |
| **MCP** | Herramienta externa (memoria, APIs, bases de datos) |
| **Herramienta integrada** | Capacidad nativa de VS Code o de una extensión (búsqueda de archivos, terminal, linter, base de datos, etc.) que los agentes pueden invocar directamente sin servidor externo |

**[→ Definiciones de cada componente](CONCEPTS.md)**

```mermaid
flowchart TB
    subgraph P["📦 Plugin"]
        A["🧠🤖 Agente\nDirige el trabajo"]
        S["🤖 Subagente\nEjecuta partes del trabajo"]

        SK["🧠 Skill\nSabe cómo hacer algo"]
        MC["⚙️ MCP\nSistemas externos"]
        HE["🔧 Herramienta integrada\nVS Code o extensión"]
    end

    A -->|delegar| S

    A -->|usar capacidades| SK
    S -->|usar capacidades| SK

    A -->|integrar| MC
    S -->|integrar| MC

    A -->|invocar| HE
    S -->|invocar| HE
```

---

## Plugins disponibles

| Plugin | Descripción |
|---|---|
| [**ai-studio**](plugins/ai-studio/) | Herramientas para diseño y desarrollo de plugins, agentes y skills del ecosistema. |
| [**ibmi-rpg**](plugins/ibmi-rpg/) | Revisión, análisis y mejora de código RPGLE/SQLRPGLE/CLLE para IBM i. |

> Cada plugin tiene su propio README con detalles de agentes, skills y estructura.

---

## Próximos pasos

Con el plugin ya instalado y activo, el siguiente paso es incorporarlo en el trabajo diario. Cada interacción cuenta: nos permite validar su utilidad a partir de la experiencia real de cada uno — los problemas que resolvió, los patrones que reconoce y los errores que se repiten. Ese conocimiento práctico es precisamente lo que hace que estas herramientas evolucionen y mejoren.

Cualquier corrección, ajuste o nueva skill que surja de ese aprendizaje puede integrarse al repositorio y beneficiar automáticamente al resto de los desarrolladores.

La clave está en usar estos agentes dentro del flujo real de trabajo: revisiones de código, diseño de cambios, análisis de problemas. No como un asistente paralelo, sino como una pieza más del proceso.

