# MCP Servers in VS Code Plugins — Complete Reference

Plugins can bundle MCP servers to give agents additional tools and data sources. Plugin MCP servers start automatically when the plugin is enabled and stop when it is disabled.

## Configuration File Location

Place MCP server definitions in `.mcp.json` at the **plugin root**. VS Code discovers this file automatically:

```text
my-plugin/
  .mcp.json              # MCP server definitions
  servers/
    db-server            # Executable server
  config.json            # Server configuration
```

## `.mcp.json` Schema

Define servers in a top-level `mcpServers` object:

```json
{
  "mcpServers": {
    "server-name": {
      "command": "${CLAUDE_PLUGIN_ROOT}/servers/my-server",
      "args": ["--config", "${CLAUDE_PLUGIN_ROOT}/config.json"],
      "cwd": "${CLAUDE_PLUGIN_ROOT}",
      "env": {
        "DB_PATH": "${CLAUDE_PLUGIN_ROOT}/data",
        "LOG_LEVEL": "info"
      }
    }
  }
}
```

> **Critical difference from workspace `mcp.json`**: the top-level key is **`mcpServers`**, not `servers`. Using `servers` will break auto-discovery.

## The `${CLAUDE_PLUGIN_ROOT}` Token in MCP Config

VS Code expands `${CLAUDE_PLUGIN_ROOT}` to the plugin's absolute path in the following MCP server fields:

| Field | Example |
|-------|---------|
| `command` | `"${CLAUDE_PLUGIN_ROOT}/servers/db-server"` |
| `args` | `["--config", "${CLAUDE_PLUGIN_ROOT}/config.json"]` |
| `cwd` | `"${CLAUDE_PLUGIN_ROOT}"` |
| `env` values | `"DB_PATH": "${CLAUDE_PLUGIN_ROOT}/data"` |
| `envFile` | `"${CLAUDE_PLUGIN_ROOT}/.env"` |
| `url` | `"http://localhost:${PORT}${CLAUDE_PLUGIN_ROOT}"` (rare) |
| `headers` values | Auth headers referencing plugin files |

VS Code also injects a `CLAUDE_PLUGIN_ROOT` environment variable into the server process so server code can access the plugin path at runtime.

**Why this is necessary**: Plugins install to a system-managed location outside any workspace. Relative paths will not resolve correctly.

## Server Types

### Local executable server

For bundled binaries or scripts:

```json
{
  "mcpServers": {
    "local-tool": {
      "command": "${CLAUDE_PLUGIN_ROOT}/servers/tool-server",
      "args": ["--mode", "plugin"],
      "env": {
        "CONFIG": "${CLAUDE_PLUGIN_ROOT}/config/settings.json"
      }
    }
  }
}
```

### npm-based server

For servers distributed via npm:

```json
{
  "mcpServers": {
    "npm-tool": {
      "command": "npx",
      "args": ["@company/mcp-server", "--plugin-mode"],
      "cwd": "${CLAUDE_PLUGIN_ROOT}"
    }
  }
}
```

### Multiple servers in one plugin

A plugin can bundle multiple MCP servers:

```json
{
  "mcpServers": {
    "plugin-database": {
      "command": "${CLAUDE_PLUGIN_ROOT}/servers/db-server",
      "args": ["--config", "${CLAUDE_PLUGIN_ROOT}/config.json"],
      "env": {
        "DB_PATH": "${CLAUDE_PLUGIN_ROOT}/data"
      }
    },
    "plugin-api": {
      "command": "npx",
      "args": ["@company/mcp-server", "--plugin-mode"],
      "cwd": "${CLAUDE_PLUGIN_ROOT}"
    }
  }
}
```

## Trust Model

Plugin MCP servers are **implicitly trusted** when the plugin is installed. Unlike workspace MCP servers, they do **not** show a separate trust prompt at startup.

This makes plugin MCP servers simpler to use but increases the importance of verifying the plugin source before installation. Review the plugin contents and publisher, especially for community marketplace plugins.

## How Plugin MCP Servers Interact with Other Servers

Plugin MCP servers appear alongside workspace and user-level MCP servers in:

- **Configure Tools** in the Chat view — tools from all MCP servers, including plugin servers
- **MCP: List Servers** from the Command Palette — plugin servers listed alongside others

When a plugin is **disabled**, its MCP servers stop and their tools are no longer available in chat. Re-enabling the plugin restarts the servers.

## Managing Plugin MCP Servers

| Action | How |
|--------|-----|
| View all servers | Command Palette → `MCP: List Servers` |
| View tools from servers | Chat view → **Configure Tools** |
| Stop a plugin's servers | Disable the plugin |
| Restart a plugin's servers | Re-enable the plugin |

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| Using `servers` as top-level key | VS Code won't discover servers | Use `mcpServers` instead |
| Using relative paths in `command` | Path resolves from wrong directory | Use `${CLAUDE_PLUGIN_ROOT}/...` |
| Forgetting `cwd` for npm servers | npx may fail to find packages | Set `"cwd": "${CLAUDE_PLUGIN_ROOT}"` |
| Assuming separate trust prompt | Plugin MCP servers are implicitly trusted | Verify plugin source before install |
| Placing `.mcp.json` in subdirectory | VS Code won't auto-discover it | Place at plugin root |
