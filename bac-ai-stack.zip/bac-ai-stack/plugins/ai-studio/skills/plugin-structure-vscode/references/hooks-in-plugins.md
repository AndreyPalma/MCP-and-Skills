# Hooks in VS Code Plugins — Complete Reference

Hooks let a plugin execute shell commands at agent lifecycle points. Plugin hooks run alongside workspace-level and user-level hooks — when a plugin is enabled, its hooks fire in addition to any other hooks configured for the same event.

## Hook File Location

VS Code auto-detects the plugin format based on where the hook file lives:

| Plugin format | Hook file path |
|---------------|----------------|
| Claude | `hooks/hooks.json` |
| Copilot | `hooks.json` (at the plugin root) |

**Recommended**: Use the Claude format (`hooks/hooks.json`) for new plugins. It supports matcher syntax and is compatible with Claude Code.

Directory structure for Claude format:

```text
my-plugin/
  hooks/
    hooks.json           # Hook configuration
  scripts/
    format.sh            # Scripts referenced by hooks.json
```

## Hook Configuration Formats

### Flat Format

Standard format, equivalent to workspace hooks:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/scripts/format.sh"
      }
    ],
    "PreToolUse": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/scripts/validate.sh"
      }
    ]
  }
}
```

Multiple hooks on the same event all execute:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/scripts/log.sh"
      },
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/scripts/notify.sh"
      }
    ]
  }
}
```

### Matcher Format (Claude Code Compatibility)

Extends the flat format with a `matcher` field for Claude Code compatibility:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Write|Edit",
        "hooks": [
          {
            "type": "command",
            "command": "${CLAUDE_PLUGIN_ROOT}/scripts/format.sh"
          }
        ]
      }
    ]
  }
}
```

> **Important**: VS Code parses the `matcher` field for Claude Code compatibility but **currently ignores matcher values**. Hooks run on every matching event regardless of the matcher. To filter behavior in VS Code, check the event input inside the hook script itself.

Both formats can be mixed within the same `hooks.json`.

## Supported Hook Events

| Event | When it fires |
|-------|--------------|
| `SessionStart` | When a new chat session begins |
| `UserPromptSubmit` | When the user submits a prompt in chat |
| `PreToolUse` | Before a tool call executes |
| `PostToolUse` | After a tool call completes |
| `PreCompact` | Before context compaction occurs |
| `SubagentStart` | When a sub-agent is launched |
| `SubagentStop` | When a sub-agent finishes |
| `Stop` | When the main agent stops |

## Referencing Plugin Files with `${CLAUDE_PLUGIN_ROOT}`

Always use `${CLAUDE_PLUGIN_ROOT}` in the `command` field to reference scripts inside the plugin directory. VS Code expands this token to the plugin's absolute path at runtime.

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/scripts/validate-tool.sh"
      }
    ]
  }
}
```

VS Code also sets a `CLAUDE_PLUGIN_ROOT` environment variable in the hook process so scripts can access the plugin path internally:

```bash
#!/bin/bash
# validate-tool.sh
CONFIG="$CLAUDE_PLUGIN_ROOT/config/rules.json"
# use $CONFIG...
```

On Windows, access it as `%CLAUDE_PLUGIN_ROOT%` in `.bat` files or `$env:CLAUDE_PLUGIN_ROOT` in PowerShell.

**Why this matters**: Plugins install to a system-managed location outside any workspace. Without `${CLAUDE_PLUGIN_ROOT}`, a static path would break on any machine other than the developer's.

## How Plugin Hooks Interact with Other Hooks

Plugin hooks run **alongside** workspace-level and user-level hooks. All hooks targeting the same event execute.

**Permission resolution for `PreToolUse`:**

When multiple `PreToolUse` hooks return different permission decisions, the most restrictive wins:

```
deny > ask > allow
```

Example: if a workspace hook returns `allow` but a plugin hook returns `deny`, the tool call is denied.

**Disabling a plugin** disables all its hooks — they no longer fire on any event.

## Complete Example: PreToolUse Validation Hook

`hooks/hooks.json`:
```json
{
  "hooks": {
    "PreToolUse": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/scripts/check-tool.sh"
      }
    ],
    "PostToolUse": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/scripts/audit-log.sh"
      }
    ]
  }
}
```

`scripts/check-tool.sh` (using `$CLAUDE_PLUGIN_ROOT` injected by VS Code):
```bash
#!/bin/bash
RULES="$CLAUDE_PLUGIN_ROOT/config/allowed-tools.txt"
# Read rules from plugin config and decide whether to allow/deny
```

## Common Mistakes

| Mistake | Problem | Fix |
|---------|---------|-----|
| Using a relative path in `command` | Breaks when plugin installs outside workspace | Use `${CLAUDE_PLUGIN_ROOT}/scripts/...` |
| Relying on `matcher` for filtering in VS Code | VS Code ignores matcher values | Filter inside the hook script |
| Placing `hooks.json` at plugin root for Claude format | Wrong location for Claude format | Place at `hooks/hooks.json` |
| Assuming hooks replace workspace hooks | Plugin hooks augment, not replace | Account for combined hook behavior |
