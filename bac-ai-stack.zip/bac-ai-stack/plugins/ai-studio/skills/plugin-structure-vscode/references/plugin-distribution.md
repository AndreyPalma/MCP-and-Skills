# Plugin Distribution — Complete Reference

Covers discovery, installation, enable/disable, uninstall, updates, marketplace configuration, local plugin registration, and workspace recommendations for VS Code agent plugins.

## Default Marketplaces

By default, VS Code discovers plugins from:
- [copilot-plugins](https://github.com/github/copilot-plugins)
- [awesome-copilot](https://github.com/github/awesome-copilot/)

## Discovering and Installing Plugins

### Browse from marketplace

1. Open the Extensions view (`Ctrl+Shift+X`)
2. Enter `@agentPlugins` in the search field

   Alternatively: **More Actions** (⋯) in Extensions sidebar → **Views** → **Agent Plugins**

3. Browse available plugins
4. Select **Install** to install into your user profile

> **First install from a new marketplace**: VS Code shows a trust prompt. Review the marketplace source before confirming.

### Install from a Git repository (no marketplace needed)

Run **Chat: Install Plugin From Source** from the Command Palette, then enter a Git repository URL:

```
https://github.com/rwoll/markdown-review
```

VS Code clones the repository and installs the plugin from source.

Alternatively: select the **+** button on the **Plugins** page of the Chat Customizations editor.

## Viewing Installed Plugins

Open the **Agent Plugins - Installed** view in the Extensions view to see all installed plugins.

Also accessible from the Chat view: **gear icon** → **Plugins**.

## Enabling and Disabling Plugins

Enable or disable a plugin globally or per-workspace:

- **Via Extensions view**: right-click a plugin in **Agent Plugins - Installed** → enable/disable options
- **Via Chat Customizations editor**: toggle the plugin's enabled state

The enable/disable state is stored separately from plugin configuration — it does not affect shared workspace settings.

**Effect of disabling a plugin:**
- Skills no longer appear in **Chat: Configure Skills**
- Agents no longer appear in chat
- Hooks no longer fire
- MCP servers stop and their tools become unavailable
- Slash commands disappear

Disabled plugins appear with a dimmed style in the Chat Customizations editor and Extensions view.

## Uninstalling Plugins

Right-click a plugin in **Agent Plugins - Installed** → **Uninstall**.

- **Externally sourced plugins** (npm, PyPI, external Git): removed from disk
- **Marketplace-inlined plugins**: remain on disk but are no longer active

## Configuring Plugin Marketplaces

Add custom marketplaces via `chat.plugins.marketplaces` in `settings.json`.

Marketplaces are Git repositories containing plugin definitions. Supported reference formats:

| Format | Example |
|--------|---------|
| Shorthand (public GitHub) | `"owner/repo"` |
| HTTPS git remote | `"https://github.com/org/repo.git"` |
| SCP-style git remote | `"git@github.com:org/repo.git"` |
| Local file URI | `"file:///path/to/local-marketplace"` |

```json
// settings.json
"chat.plugins.marketplaces": [
  "anthropics/claude-code",
  "your-org/internal-plugins",
  "https://github.com/your-org/private-plugins.git"
]
```

Private repositories are supported. If a public lookup fails, VS Code falls back to cloning the repository directly.

Marketplace plugins can also reference external package sources (npm, PyPI). See the [Claude Code plugin marketplace documentation](https://code.visualstudio.com/docs/copilot/customization/mcp-servers) for the full schema.

## Registering Local Plugins

Register a locally cloned or downloaded plugin with `chat.pluginLocations` in `settings.json`:

```json
// settings.json
"chat.pluginLocations": {
  "/path/to/my-plugin": true,
  "/path/to/another-plugin": false
}
```

| Value | Effect |
|-------|--------|
| `true` | Plugin is enabled |
| `false` | Plugin is registered but disabled |

This is the recommended approach for developing and testing plugins locally before publishing.

## Updating Plugins

VS Code checks for plugin updates when:
- Running **Extensions: Check for Extension Updates** from the Command Palette
- Automatically every 24 hours (if `setting(extensions.autoUpdate)` is enabled)

Update behavior by source:

| Source | Update behavior |
|--------|----------------|
| Git-cloned marketplace plugin | Pulls latest changes from repository |
| npm / PyPI plugin | Shows **Update** button; never auto-updates |
| External Git (install from source) | Checks for new commits |

For npm/PyPI sourced plugins: selecting **Update** prompts for confirmation before running the install command. Background checks find updates but take no action until the user explicitly selects **Update**.

## Workspace Plugin Recommendations

Recommend plugins to team members via workspace settings:

```json
// .vscode/settings.json (workspace)
{
  "extraKnownMarketplaces": {
    "company-tools": {
      "source": {
        "source": "github",
        "repo": "your-org/plugin-marketplace"
      }
    }
  },
  "enabledPlugins": {
    "code-formatter@company-tools": true
  }
}
```

| Setting | Effect |
|---------|--------|
| `enabledPlugins` | Lists plugins enabled by default for the workspace. VS Code notifies team members on next chat message. Also listed under `@agentPlugins @recommended` in Extensions view. |
| `extraKnownMarketplaces` | Registers additional marketplaces for the project. Appears when searching `@agentPlugins`. |

## Security Checklist Before Installing a Plugin

Plugins can run arbitrary code on the machine via hooks and MCP servers. Before installing, verify:

- [ ] Publisher identity and reputation
- [ ] Hook scripts in `hooks/` and `scripts/` — what commands do they run?
- [ ] MCP server executables — what network access do they request?
- [ ] Environment variables the plugin sets
- [ ] Whether the plugin needs marketplace trust approval

Community marketplace plugins carry higher risk than first-party plugins. Review source code when possible.
