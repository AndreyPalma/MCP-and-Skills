---
name: plugin-structure-vscode
description: This skill should be used when the user asks to "create a VS Code plugin", "scaffold a VS Code agent plugin", "structure a plugin for VS Code Copilot", "configure plugin.json", "plugin.json schema", "plugin.json fields", "plugin manifest", "add hooks to a VS Code plugin", "bundle skills in a plugin", "bundle agents in a plugin", "set up MCP servers in a plugin", "use ${CLAUDE_PLUGIN_ROOT}", "install a VS Code plugin from source", "configure plugin marketplaces", "register a local plugin", "workspace plugin recommendations", or wants to understand the VS Code agent plugin system architecture and component organization.
---

# VS Code Plugin Structure

VS Code agent plugins are prepackaged bundles of chat customizations discoverable and installable from plugin marketplaces. A single plugin can provide slash commands, agent skills, custom agents, hooks, and MCP servers.

> **Prerequisite**: Enable plugin support via `setting(chat.plugins.enabled)` in VS Code settings.

## What Plugins Provide

| Component | Purpose |
|-----------|---------|
| **Slash commands** | Additional `/` commands available in chat (authoring syntax not covered by this skill) |
| **Skills** | Agent skills with instructions and resources that load on-demand |
| **Agents** | Custom agents with specialized personas and tool configurations |
| **Hooks** | Shell commands executed at agent lifecycle points |
| **MCP servers** | External tool integrations via Model Context Protocol |

## Plugin Directory Structure

```text
my-plugin/
  plugin.json              # Plugin metadata and configuration
  skills/
    my-skill/
      SKILL.md             # Skill instructions (required)
      references/          # Reference docs loaded as needed
      scripts/             # Utility scripts
      assets/              # Files for output use
  agents/
    my-agent.agent.md      # Custom agent definition
  hooks/
    hooks.json             # Hook configuration (Claude format)
  scripts/
    my-hook-script.sh      # Scripts referenced by hooks
  .mcp.json                # MCP server definitions
```

## plugin.json — Plugin Manifest

`plugin.json` is the **required manifest file** at the plugin root. VS Code reads it to register the plugin's identity, version, and display information.

**Minimum required fields:**

```json
{
  "name": "my-plugin",
  "displayName": "My Plugin",
  "version": "0.1.0",
  "description": "Short description shown in the Extensions view.",
  "publisher": "your-org-or-username"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `name` | string | Unique identifier — lowercase, hyphens only |
| `displayName` | string | Human-readable name shown in the UI |
| `version` | string | Semver version string |
| `description` | string | Short description shown in Extensions view |
| `publisher` | string | Publisher identifier (GitHub org or username) |

> For the complete manifest schema including optional fields (categories, icon, license, repository), see the [VS Code Agent Plugin documentation](https://code.visualstudio.com/docs/copilot/customization).

### Format Detection: Claude vs. Copilot

VS Code auto-detects the plugin format based on hook file location:

| Format | Hook file path |
|--------|---------------|
| Claude | `hooks/hooks.json` |
| Copilot | `hooks.json` (at plugin root) |

Use **Claude format** (`hooks/hooks.json`) for new plugins — it supports matcher syntax and is compatible with Claude Code.

## The `${CLAUDE_PLUGIN_ROOT}` Token

Use `${CLAUDE_PLUGIN_ROOT}` in hook commands and MCP server configuration to reference files within the plugin directory. VS Code expands this token to the plugin's absolute path at runtime.

**This token is mandatory** — plugins install outside the workspace, so relative paths will not work.

VS Code also injects a `CLAUDE_PLUGIN_ROOT` environment variable into hook processes and MCP server processes:
- Unix: `$CLAUDE_PLUGIN_ROOT`
- Windows: `%CLAUDE_PLUGIN_ROOT%`

Fields where VS Code expands `${CLAUDE_PLUGIN_ROOT}`:
- Hooks: `command`
- MCP: `command`, `args`, `cwd`, `env` values, `envFile`, `url`, `headers`

## Skills in Plugins

Organize plugin skills under `skills/<skill-name>/`, each containing a `SKILL.md` with YAML frontmatter (`name` + `description`):

```text
skills/
  my-skill/
    SKILL.md                # Required — frontmatter + instructions
    references/             # Documentation loaded as needed
    examples/               # Working code examples
    scripts/                # Utility scripts
    assets/                 # Files used in output
```

**Auto-discovery flow:**
1. VS Code scans `skills/` for subdirectories containing `SKILL.md`
2. Loads `name` + `description` frontmatter always (metadata level)
3. Loads full `SKILL.md` body when the skill triggers
4. Loads references/scripts as Claude determines they are needed

Keep `SKILL.md` lean (1,500–2,000 words). Move detailed content to `references/`.

## Agents in Plugins

Agent definitions are markdown files placed in `agents/`:

```text
agents/
  my-agent.agent.md       # System prompt, tool config, persona
```

Once the plugin is installed, plugin agents appear alongside locally defined agents in chat.

## Hooks in Plugins — Quick Start

Hooks execute shell commands at agent lifecycle points. Supported events:

| Event | When it fires |
|-------|--------------|
| `SessionStart` | When a chat session begins |
| `UserPromptSubmit` | When the user submits a prompt |
| `PreToolUse` | Before a tool executes |
| `PostToolUse` | After a tool executes |
| `PreCompact` | Before context compaction |
| `SubagentStart` | When a sub-agent starts |
| `SubagentStop` | When a sub-agent stops |
| `Stop` | When the agent stops |

**Flat format** (simplest):

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/scripts/format.sh"
      }
    ]
  }
}
```

**Matcher format** (Claude Code compatibility):

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Write|Edit",
        "hooks": [
          {
            "type": "command",
            "command": "${CLAUDE_PLUGIN_ROOT}/scripts/validate.sh"
          }
        ]
      }
    ]
  }
}
```

> VS Code parses `matcher` for compatibility but currently **ignores matcher values** — hooks run on every matching event. Filter behavior inside the hook script when needed.

For complete hook configuration details, format specifications, and interaction rules, see **`references/hooks-in-plugins.md`**.

## MCP Servers in Plugins — Quick Start

Define MCP servers in `.mcp.json` at the plugin root using the `mcpServers` key (not `servers`):

```json
{
  "mcpServers": {
    "my-server": {
      "command": "${CLAUDE_PLUGIN_ROOT}/servers/my-server",
      "args": ["--config", "${CLAUDE_PLUGIN_ROOT}/config.json"],
      "env": {
        "DATA_PATH": "${CLAUDE_PLUGIN_ROOT}/data"
      }
    },
    "npm-based-server": {
      "command": "npx",
      "args": ["@company/mcp-server", "--plugin-mode"],
      "cwd": "${CLAUDE_PLUGIN_ROOT}"
    }
  }
}
```

> Plugin MCP servers are **implicitly trusted** when the plugin is installed — no separate trust prompt appears at startup.

Plugin MCP servers start automatically when the plugin is enabled and stop when the plugin is disabled. Tools appear in **Configure Tools** alongside workspace and user-level MCP servers.

For complete `.mcp.json` schema and token expansion details, see **`references/mcp-servers-in-plugins.md`**.

## Installing and Managing Plugins — Quick Start

**Browse and install from marketplace:**
1. Open Extensions view (`Ctrl+Shift+X`)
2. Search `@agentPlugins`
3. Select **Install** on the desired plugin

**Install from a Git repository:**
- Command Palette → `Chat: Install Plugin From Source`
- Enter a Git repository URL

**Register a local plugin directory:**

```json
// settings.json
"chat.pluginLocations": {
  "/path/to/my-plugin": true
}
```

**Add a custom marketplace:**

```json
// settings.json
"chat.plugins.marketplaces": [
  "anthropics/claude-code",
  "your-org/internal-plugins"
]
```

For full distribution workflow — enable/disable, uninstall, workspace recommendations, update behavior — see **`references/plugin-distribution.md`**.

## Plugin Security Considerations

Plugins can include hooks and MCP servers that **run code on the machine**. Before installing a plugin from community marketplaces:

- Review the plugin contents
- Verify the publisher
- Check hook scripts and MCP server executables for unexpected behavior

Plugin hooks run alongside workspace-level and user-level hooks. For `PreToolUse`, the most restrictive permission decision across all hooks wins: `deny` > `ask` > `allow`.

Disabling a plugin disables all its hooks, MCP servers, skills, agents, and slash commands.

## Full Example: Testing Plugin Layout

See **`examples/testing-plugin-complete.md`** for a complete, annotated plugin layout including `plugin.json`, hooks, MCP servers, skills, and agents.

## Additional Resources

### Reference Files

- **`references/hooks-in-plugins.md`** — Complete hook configuration: formats, all events, filtering, interaction with other hooks, `${CLAUDE_PLUGIN_ROOT}` in hooks
- **`references/mcp-servers-in-plugins.md`** — Complete `.mcp.json` schema, all token-expansion fields, trust model, managing plugin servers
- **`references/plugin-distribution.md`** — Marketplace setup, install from source, local plugins, enable/disable, uninstall, updates, workspace recommendations

### Examples

- **`examples/testing-plugin-complete.md`** — Complete annotated plugin layout with `plugin.json`, hooks, MCP servers, skills, and agents

### Official VS Code Documentation

- [Agent Skills](https://code.visualstudio.com/docs/copilot/customization/agent-skills)
- [Custom Agents](https://code.visualstudio.com/docs/copilot/customization/custom-agents)
- [Hooks lifecycle automation](https://code.visualstudio.com/docs/copilot/customization/hooks)
- [MCP Servers](https://code.visualstudio.com/docs/copilot/customization/mcp-servers)
