# Complete Plugin Example: Testing Plugin

A fully annotated plugin layout demonstrating hooks, MCP servers, skills, and agents.

## Directory Layout

```text
my-testing-plugin/
  plugin.json              # Required manifest
  skills/
    test-runner/
      SKILL.md             # Skill instructions
      references/
        test-patterns.md   # Detailed test patterns
      scripts/
        run-tests.sh       # Test runner script
  agents/
    test-reviewer.agent.md # Custom review agent
  hooks/
    hooks.json             # Hook configuration (Claude format)
  scripts/
    validate-tests.sh      # Script invoked by hooks
  .mcp.json                # MCP server definitions
```

## plugin.json

```json
{
  "name": "my-testing-plugin",
  "displayName": "My Testing Plugin",
  "version": "0.1.0",
  "description": "Validates and runs tests after code changes.",
  "publisher": "your-org"
}
```

## hooks/hooks.json

Runs `validate-tests.sh` after every tool use:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "type": "command",
        "command": "${CLAUDE_PLUGIN_ROOT}/scripts/validate-tests.sh"
      }
    ]
  }
}
```

## scripts/validate-tests.sh

```bash
#!/bin/bash
# Access plugin path via the injected env variable
CONFIG="$CLAUDE_PLUGIN_ROOT/config/rules.json"
echo "Running validation with config: $CONFIG"
# run validation logic here
```

## .mcp.json

Bundles a test-reporting MCP server:

```json
{
  "mcpServers": {
    "test-reporting": {
      "command": "npx",
      "args": ["@company/test-reporter"],
      "cwd": "${CLAUDE_PLUGIN_ROOT}"
    }
  }
}
```

> Note: use `mcpServers` (not `servers`) as the top-level key — VS Code won't discover servers otherwise.

## skills/test-runner/SKILL.md (frontmatter)

```yaml
---
name: Test Runner
description: This skill should be used when the user asks to run tests, check test results, or validate code changes with automated tests.
---
```

## agents/test-reviewer.agent.md (frontmatter)

```yaml
---
name: Test Reviewer
description: Reviews test quality and coverage for the current codebase.
---
```
