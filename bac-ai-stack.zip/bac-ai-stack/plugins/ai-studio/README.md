# AI Studio

Plugin de herramientas para el diseño, desarrollo y mantenimiento de plugins, agentes y skills del ecosistema BAC AI Stack.

---

## Agentes

| Agente | Descripción |
|--------|-------------|
| **Skill Reviewer** | Revisa la calidad y estructura de skills, evalúa descripciones y propone mejoras. |

## Skills

| Skill | Descripción |
|-------|-------------|
| **agent-development** | Guía para crear agentes: estructura, frontmatter, prompts de sistema y condiciones de disparo. |
| **plugin-settings** | Patrón `.local.md` para almacenar configuración per-project de plugins con YAML frontmatter. |
| **plugin-structure-claude** | Estructura de directorios, manifiesto y organización de componentes para plugins Claude Code. |
| **plugin-structure-vscode** | Arquitectura de plugins para VS Code Copilot Chat: manifiesto, skills, agentes, hooks y MCPs. |
| **prd** | Generación de documentos PRD (Product Requirements Document) profesionales con especificaciones técnicas. |
| **skill-development** | Guía para crear skills efectivas: estructura, progressive disclosure y mejores prácticas. |

## Estructura

```
ai-studio/
├── README.md
├── agents/
│   └── skill-reviewer.agent.md
└── skills/
    ├── agent-development/
    │   ├── SKILL.md
    │   ├── examples/
    │   ├── references/
    │   └── scripts/
    ├── plugin-settings/
    │   ├── SKILL.md
    │   ├── examples/
    │   ├── references/
    │   └── scripts/
    ├── plugin-structure-claude/
    │   ├── SKILL.md
    │   ├── examples/
    │   └── references/
    ├── plugin-structure-vscode/
    │   ├── SKILL.md
    │   ├── examples/
    │   └── references/
    ├── prd/
    │   └── SKILL.md
    └── skill-development/
        ├── SKILL.md
        └── references/
```
