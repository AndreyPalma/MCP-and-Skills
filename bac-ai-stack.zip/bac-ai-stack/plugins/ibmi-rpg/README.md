# IBM i RPG

Plugin de revisión, análisis y mejora de código RPGLE/SQLRPGLE/CLLE para IBM i. Orquesta subagentes especializados respaldados por una skill con 7 dominios de conocimiento técnico según estándares BAC Latam.

---

## Agentes

| Agente | Descripción |
|--------|-------------|
| **RPG Code Reviewer** | Orquestador principal. Coordina los 3 subagentes para el flujo completo de revisión. |
| **RPG Explorer** | Subagente de exploración. Descubre y cataloga fuentes RPG en rutas/librerías. |
| **RPG Analyzer** | Subagente de análisis. Evalúa código contra mejores prácticas y genera reporte de hallazgos. |
| **RPG Applier** | Subagente de implementación. Aplica las mejoras aprobadas a los archivos fuente. |

## Skills

| Skill | Descripción |
|-------|-------------|
| **rpg-best-practices** | Estándares empresariales BAC Latam para RPG. 7 dominios de conocimiento técnico. |

### Referencias de rpg-best-practices

| Referencia | Dominio |
|------------|---------|
| `architecture.md` | Arquitectura ILE |
| `error-handling.md` | Manejo de errores |
| `legacy.md` | Código legacy |
| `naming-types.md` | Nomenclatura y tipos |
| `performance.md` | Rendimiento |
| `security.md` | Seguridad |
| `sql-embedded.md` | SQL embebido |

## Estructura

```
ibmi-rpg/
├── README.md
├── agents/
│   ├── rpg-analyzer.agent.md
│   ├── rpg-applier.agent.md
│   ├── rpg-code-reviewer.agent.md
│   └── rpg-explorer.agent.md
└── skills/
    └── rpg-best-practices/
        ├── SKILL.md
        └── references/
            ├── architecture.md
            ├── error-handling.md
            ├── legacy.md
            ├── naming-types.md
            ├── performance.md
            ├── security.md
            └── sql-embedded.md
```
