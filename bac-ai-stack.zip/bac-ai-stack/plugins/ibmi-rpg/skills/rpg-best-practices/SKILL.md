---
name: rpg-best-practices
description: >-
  This skill should be used when the user asks to "revisar código RPG", "validar fuente RPGLE",
  "mejores prácticas RPG", "review RPG code", "code review SQLRPGLE", "estándares de codificación RPG",
  "analizar código IBM i", "escribir código RPG", "crear código RPGLE", "write RPG code",
  "new RPGLE program", "nuevo programa RPGLE", "escribir nuevo fuente", or requests a checklist
  before promoting to production. Also trigger when the user mentions naming conventions for IBM i,
  SQL injection in RPG, performance optimization, error handling patterns (MONITOR/ON-ERROR,
  CEXCEPTION, throwNewException, catchException), ILE architecture, McCabe complexity,
  Fixed Format legacy code, or wants to create, write, improve, validate, review, or audit any
  RPGLE, SQLRPGLE, or CLLE source. Do NOT use for general SQL without RPG context or general
  programming questions unrelated to IBM i / AS400 / iSeries development.
---

# RPG Best Practices — Estándares Empresariales BAC Latam

Guía de mejores prácticas para desarrollo RPGLE/SQLRPGLE/CLLE. Actúa como **mentor técnico**: orienta,
ejemplifica y mejora código — no como auditor que penaliza.

## Modos de Operación

Determina el modo según el contexto del usuario antes de responder:

### Modo Orientación — "¿Cómo hago esto?"
Cuando el usuario pregunta cómo escribir código, pide un patrón, plantilla o quiere aprender una práctica:

1. Identifica el(los) dominio(s) aplicable(s) a la consulta.
2. Carga el archivo de referencia correspondiente.
3. Presenta la mejor práctica con: **por qué importa** → **patrón correcto** → **qué evitar**.

### Modo Mejora — "Mejora / valida este código"
Cuando el usuario comparte código existente y quiere aplicar mejores prácticas:

1. Detecta formato y lenguaje (Full Free / Fixed Format / Mixto).
2. Identifica dominios relevantes según el contenido del código.
3. Carga solo los archivos de referencia necesarios.
4. Presenta oportunidades de mejora en formato **Antes → Después** con explicación.
5. Prioriza por impacto: seguridad > correctitud > rendimiento > mantenibilidad.

---

## Dominios de Mejores Prácticas

7 dominios especializados, cada uno con su archivo de referencia con patrones, ejemplos y criterios.
**Carga únicamente los dominios que la consulta requiere** — no leas todos los archivos de antemano.

| # | Dominio | Archivo | Cuándo cargar |
|---|---------|---------|---------------|
| 1 | **Arquitectura ILE** | `references/architecture.md` | ctl-opt, estructura de módulos, modularización, McCabe, patrones ILE/CL |
| 2 | **Manejo de Errores** | `references/error-handling.md` | monitor/on-error, SQLCODE, COMMIT/ROLLBACK, deadlocks, memory leaks |
| 3 | **Código Legacy** | `references/legacy.md` | Fixed Format, indicadores, opcodes RPG III, PLIST/KLIST, subrutinas, migración |
| 4 | **Nomenclatura y Tipos** | `references/naming-types.md` | Convenciones de nombres, tipos de datos, precisión financiera, inicialización |
| 5 | **Rendimiento** | `references/performance.md` | I/O eficiente, caché, batch, recursividad, optimización de ciclos |
| 6 | **Seguridad** | `references/security.md` | SQL injection, PCI-DSS, credenciales, QCMDEXC, timing attacks |
| 7 | **SQL Embebido** | `references/sql-embedded.md` | SET OPTION, JOINs, cursores, CTEs, window functions, DDL |

### Carga adicional por contexto específico

- **`references/cexception-pattern.md`**: Cargar cuando la consulta involucre CEXCEPTION,
  patrón corporativo de excepciones, `throwNewException`, `catchException`, `CEXCEPBNDD`, o
  manejo de errores en servicios BAC. Es complemento de `error-handling.md`.
- **`references/comment-templates.md`**: Cargar cuando se pregunte sobre documentación de
  fuentes, encabezados de programa (`@@module`, `@name`, `@objective`), comentarios de
  procedimiento, o plantillas de documentación RPG. Es complemento de `architecture.md`.

## Carga a Demanda — Regla Fundamental

**Carga solo los archivos de referencia que la consulta necesita.** Determina cuáles según:

1. **Pregunta explícita**: el usuario menciona un dominio ("¿cómo manejo errores SQL?", "¿qué convenciones de nombres uso?").
2. **Contenido del código**: si contiene SQL embebido → carga SQL Embebido; si tiene Fixed Format → carga Legacy; etc.
3. **Consulta transversal**: si pide "mejores prácticas generales" o "checklist completo", selecciona dominios según el tipo de programa que describe.

### Mapa de dependencias

```
architecture.md ──→ legacy.md          (cuando detectas Fixed Format)
error-handling.md ──→ performance.md   (reglas de COMMIT en batch)
error-handling.md ──→ security.md      (restricciones de logging PCI-DSS)
error-handling.md ──→ legacy.md        (manejo de errores con indicadores)
naming-types.md ──→ architecture.md    (edge cases: caracteres IBM i)
naming-types.md ──→ legacy.md          (nomenclatura de 10 chars)
performance.md ──→ sql-embedded.md     (optimización SQL detallada)
performance.md ──→ architecture.md     (umbrales McCabe)
sql-embedded.md ──→ performance.md     (COMMIT batch)
```

Solo sigue una dependencia cuando la regla referenciada es directamente relevante para la consulta.

---

## Detección de Formato y Lenguaje

Cuando el usuario comparte código, identifica esto antes de responder:

- **Formato**: ¿`**Free` (Full Free), `/free`…`/end-free` (Mixto), o Fixed Format (columnas H/F/D/C/P/O)?
- **Lenguaje**: ¿RPGLE, SQLRPGLE, CLLE, RPG III, Mixto?
- **Tipo de objeto**: ¿`*PGM`, `*SRVPGM`, `*MODULE`?

| Extensión / Indicador | Tipo | Dominios prioritarios |
|------------------------|------|-------------------|
| `.RPGLE` con `**Free` en línea 1 | Full Free RPGLE | architecture · naming-types · error-handling · security · performance |
| `.RPGLE` sin `**Free`, H/F/D/C/P en col 6 | Fixed / Mixed ILE | architecture · error-handling · security · performance · **legacy** |
| `.RPG` con columnas estrictas (1-80) | RPG III Columnar | error-handling · security · **legacy** |
| `.SQLRPGLE` / `.SQLRPG` | SQLRPGLE | architecture · naming-types · error-handling · security · performance · **sql-embedded** |
| `.CLLE` / `.CLP` | CL | architecture · error-handling · security |
| `.BND` | Binding Directory | architecture |
| Mix de Free + Fixed en mismo fuente | Mixto | todos los dominios relevantes, separar secciones al responder |

---

## Formatos de Respuesta

### Modo Orientación: Guía de Práctica

~~~markdown
## Mejor Práctica: [Tema]

### Por qué importa
[Explicación concisa del impacto de seguir o no esta práctica]

### Patrón recomendado
```rpgle
[Código de ejemplo correcto con comentarios inline]
```

### Qué evitar
```rpgle
[Ejemplo de práctica incorrecta]
```
[Explicación de por qué es problemático]

### Cuándo aplica
[Contextos y condiciones específicas]
~~~

### Modo Mejora: Análisis Antes → Después

~~~markdown
# Mejoras de Código: [NOMBRE_FUENTE]

## Contexto
- **Fuente**: [nombre]
- **Tipo**: [RPGLE | SQLRPGLE | CLLE]
- **Formato**: [Full Free | Fixed Format | Mixto]
- **Objeto**: [*PGM | *SRVPGM | *MODULE]
- **Dominios analizados**: [lista]

## Resumen de Oportunidades
- 🔴 Críticas (seguridad / correctitud): N
- 🟠 Importantes (rendimiento / robustez): N
- 🟡 Recomendadas (mantenibilidad / estándar): N
- 🟢 Opcionales (estilo / cosmético): N

## Complejidad Ciclomática (McCabe)
| Procedimiento | McCabe | Nivel |
|…|…|…|

## Mejoras por Dominio

### [Nombre del dominio]

#### [PRIORIDAD] — [Título de la mejora]
**Regla**: [referencia a la regla específica del dominio]
**Por qué**: [impacto concreto si no se corrige]
**Antes:** [código actual]
**Después:** [código mejorado]

## Checklist de Estándares
[✅/❌ por criterio según los dominios analizados]
~~~

### Prioridades de Mejora

| Nivel | Criterio |
|-------|----------|
| 🔴 **Crítico** | Vulnerabilidad de seguridad, corrupción de datos, fallo en producción |
| 🟠 **Importante** | Bug potencial, race condition, rendimiento severo, McCabe >15 |
| 🟡 **Recomendado** | Incumplimiento de estándar, mantenibilidad, McCabe 11–15 |
| 🟢 **Opcional** | Estilo, documentación complementaria, cosmético |

---

## Reglas Transversales

Aplican en ambos modos independientemente del dominio:

- **Seguridad primero**: cualquier vulnerabilidad tiene prioridad absoluta sobre cualquier otra mejora.
- **Educativo siempre**: explica el *por qué* detrás de cada práctica, no solo el *qué*.
- **Complejidad Ciclomática (McCabe)**: cuando el análisis involucra estructura de código, calcular por procedimiento: `McCabe = 1 + count(if | elseif | else | when | other | for | dow | dou | monitor | on-error | and | or)`. Para umbrales y estrategias de refactoring: ver `references/architecture.md` § Complejidad Ciclomática.
- **Código muerto, documentación inline, caracteres IBM i**: ver `references/architecture.md` § Limpieza de Código y § Edge Cases.
- **Idioma consistente en nomenclatura**: ver `references/naming-types.md` § Nomenclatura.

## Consulta Parcial vs Integral

- **Parcial** (usuario pregunta por un dominio específico): carga solo ese dominio y sus dependencias si aplican.
- **Integral** (usuario pide guía completa o checklist): detecta formato, selecciona dominios según el tipo de programa, genera respuesta completa con McCabe y checklist de estándares.

En ambos casos, nunca cargues un archivo de referencia que la consulta no necesite.
