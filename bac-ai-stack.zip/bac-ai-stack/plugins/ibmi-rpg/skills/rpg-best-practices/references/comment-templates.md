# Plantillas de Documentación — Encabezados de Fuentes y Procedimientos

## Cuándo cargar esta referencia

Cargar cuando la consulta involucre: documentación de fuentes RPG, encabezado de programa,
plantillas de comentarios, `@@module`, `@name`, `@objective`, `@paramin`, `@paramout`,
headers de procedimientos, o cuando se pida ayuda para documentar cualquier fuente
RPGLE/SQLRPGLE/CLLE.

---

## Plantilla 1: Encabezado de Fuente

Debe colocarse como la **primera sección** del archivo, antes de las especificaciones de
control (`**free`, `ctl-opt`). Se aplica a todo fuente nuevo y debe actualizarse al
agregar un pase sobre un fuente existente.

```rpgle
//-----------------------------------------------------------------------
//@@module:   
//@name:      Nombre fuente
//@objective: Objetivo del fuente
//@version..: Número de pase
//@team.....: Nombre del equipo
//@author...: Nombre del autor
//@since....: Fecha
//-----------------------------------------------------------------------
```

### Descripción de campos

| Campo | Descripción |
|---|---|
| `@@module` | Nombre del módulo o dominio de negocio al que pertenece el fuente |
| `@name` | Nombre del fuente tal como aparece registrado en la biblioteca |
| `@objective` | Descripción funcional: qué hace el fuente (1–2 líneas, en español) |
| `@version` | Número de pase o versión (ej. `P001`, `P002`) |
| `@team` | Equipo o squad propietario del desarrollo |
| `@author` | Nombre completo del desarrollador responsable del pase |
| `@since` | Fecha de creación o del último pase significativo (formato ISO: AAAA-MM-DD) |

---

## Plantilla 2: Encabezado de Procedimiento

Debe colocarse **inmediatamente antes de cada `dcl-proc`**. Es obligatorio en todos los
procedimientos exportables; se recomienda en procedimientos internos con lógica compleja
(McCabe > 5).

```rpgle
//-------------------------------------------------------------------------
//@name.....: Nombre procedimiento
//@objective: Objetivo del procedimiento
//@version..: Número de pase
//@team.....: Nombre del equipo
//@author...: Nombre del autor
//@since....: Fecha
//@paramin..: Parámetros de entrada
//@paramout.: Parámetros de salida
//-------------------------------------------------------------------------
```

### Descripción de campos

| Campo | Descripción |
|---|---|
| `@name` | Nombre exacto del procedimiento (`dcl-proc NombreProcedimiento`) |
| `@objective` | Qué hace el procedimiento (verbo + sustantivo en español) |
| `@version` | Número de pase o modificación en que se creó/modificó |
| `@team` | Equipo responsable |
| `@author` | Nombre del desarrollador que creó o modificó el procedimiento |
| `@since` | Fecha de creación (formato ISO: AAAA-MM-DD) |
| `@paramin` | Descripción de cada parámetro de entrada con tipo y propósito |
| `@paramout` | Descripción del valor de retorno o parámetros de salida |

---

## Reglas de aplicación

- **Siempre** incluir el encabezado de fuente en todo programa, módulo o service program nuevo.
- **Siempre** incluir el encabezado de procedimiento en todo procedimiento exportable.
- **Recomendar** el encabezado de procedimiento en procedimientos internos con McCabe > 5.
- **Siempre** actualizar `@version` y `@since` al realizar un pase sobre el fuente.
- **Nunca** dejar campos del encabezado vacíos en fuentes que se promueven a producción.
- **Nunca** colocar el encabezado de procedimiento DENTRO del bloque `dcl-proc` / `end-proc`
  — el header va **antes** del `dcl-proc`.

---

## Posición en el fuente (relación con architecture.md)

El encabezado de fuente precede la estructura ordenada definida en
`architecture.md § Estructura del Código`:

```
0. [Encabezado de fuente ← Plantilla 1]
1. Especificaciones de control (ctl-opt / **free)
2. Declaración de archivos
3. Prototipos externos (/include)
4. Constantes empresariales
5. Variables globales (mínimas)
6. Estructuras de datos
7. [Encabezado de procedimiento ← Plantilla 2]
   dcl-proc ProcedimientoExportable export;
8. [Encabezado de procedimiento ← Plantilla 2]
   dcl-proc ProcedimientoInterno;
```

---

## Ejemplo completo integrado

```rpgle
//-----------------------------------------------------------------------
//@@module:   BCOCLIENTES
//@name:      BCLS001
//@objective: Consultar información básica de cliente por código único
//@version..: P001
//@team.....: Equipo Clientes
//@author...: Juan Pérez
//@since....: 2024-01-15
//-----------------------------------------------------------------------
**free
ctl-opt nomain dftactgrp(*no) actgrp(*caller) datfmt(*iso)
        option(*srcstmt:*nodebugio) debug(*constants);

/INCLUDE CSYSTSRC/QSRCTXT,CEXCEPTION

dcl-c ERROR_CLIENTE_NO_ENCONTRADO  const('BCL0001');
dcl-c ERROR_FALLO_CONSULTA         const('BCL0002');

//-------------------------------------------------------------------------
//@name.....: ObtenerCliente
//@objective: Retorna los datos de un cliente a partir de su código
//@version..: P001
//@team.....: Equipo Clientes
//@author...: Juan Pérez
//@since....: 2024-01-15
//@paramin..: pCodigoCliente - Código único del cliente (Char 10)
//@paramout.: psCliente - DS con datos del cliente (likeDs dsTemplateCliente)
//           Retorna *on si el cliente existe, *off si hay error
//-------------------------------------------------------------------------
dcl-proc ObtenerCliente export;
  dcl-pi *n ind;
    pCodigoCliente char(10)                  const;
    psCliente      likeDs(dsTemplateCliente);
  end-pi;

  exec sql
    SELECT CLID, CLNOMBRE, CLESTADO
      INTO :psCliente
      FROM CLIENTES
     WHERE CLID = :pCodigoCliente;

  select;
    when SQLSTATE = '00000';
      return *on;
    when SQLSTATE = '02000';
      CEXCEPTION_throwNewException(ERROR_CLIENTE_NO_ENCONTRADO : 'BCLS001M');
      return *off;
    other;
      CEXCEPTION_throwNewException(ERROR_FALLO_CONSULTA : 'BCLS001M');
      return *off;
  endsl;

end-proc;
```
