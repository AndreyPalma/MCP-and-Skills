# SQL Embebido

## Objetivo

Validar que todo SQL embebido en fuentes RPGLE/SQLRPGLE cumpla los estándares empresariales BAC Latam: SET OPTION completo, columnas explícitas, JOINs estándar, cursores optimizados, window functions correctas, CTEs con control de recursión, y DDL con constraints apropiados.

**¿Por qué?** `SELECT *` oculta dependencias y multiplica memoria cuando se agregan columnas. JOINs implícitos (WHERE) son ilegibles y propensos a cartesianos. SQL sin optimización causa timeouts en tablas con millones de registros en dominio bancario.

---

## Reglas — SET OPTION y Precompilación

- **Siempre** incluir `SET OPTION` completo al inicio de fuentes SQLRPGLE:
  ```sql
  exec sql set option datfmt=*ISO, timfmt=*ISO, commit=*CHG,
                      closqlcsr=*ENDACTGRP, naming=*SYS,
                      decresult=(63,31), sqlpath=('EMPRESA','QSYS2');
  ```
- **Siempre** documentar opciones CRTSQLRPGI en header del fuente (OBJ, SRCFILE, RDB, OBJTYPE, COMPILEOPT, COMMIT, CLOSQLCSR, TGTRLS).
- **Siempre** documentar SQL Packages: nombre, collection, RDB, access plans, performance esperada.
- **Nunca** omitir `SET OPTION` en fuentes con SQL embebido.

---

## Reglas — Coexistencia I/O Nativo y SQL

- **Nunca** mezclar Chain nativo y SQL embebido sobre el mismo archivo en fuentes nuevos SQLRPGLE. Si el uso mixto es inevitable, debe justificarse documentalmente.
- **Siempre** al migrar a SQLRPGLE, reestructurar el programa para aprovechar SQL DB2 (joins, CTEs, agregaciones). No realizar traducciones literales de Chain→SELECT.

```rpgle
// ❌ Traducción literal — no aprovecha SQL
exec sql
  select * into :dsRecord from MYFILE where MYKEY = :pKey;

// ✅ Reestructuración SQL real
exec sql
  declare curAccounts cursor for
    select a.ACCTID, a.ACCTNAME, sum(t.AMOUNT) as TOTAL
    from ACCOUNTS a
    join TRANSACTIONS t on a.ACCTID = t.ACCTID
    where a.STATUS = 'A'
    group by a.ACCTID, a.ACCTNAME
    order by TOTAL desc;
```

---

## Reglas — SELECT y Columnas

- **Siempre** listar columnas explícitamente con alias de tabla.
- **Siempre** usar alias de tabla cortos y consistentes (C=CLIENTES, CU=CUENTAS).
- **Siempre** incluir `OPTIMIZE FOR n ROWS` en cursores con estimación realista.
- **Siempre** usar `FOR READ ONLY` cuando la query no modifica datos.
- **Siempre** exigir índices en campos de `WHERE` clauses — acceso sin índice en tablas grandes causa table scan y timeouts.
- **Nunca** usar `SELECT *` — causa sorpresas cuando se agregan columnas a tablas.

---

## Reglas — JOINs

- **Siempre** usar JOINs explícitos (`INNER JOIN`, `LEFT OUTER JOIN`).
- **Siempre** usar `INNER JOIN` para relaciones obligatorias, `LEFT JOIN` para opcionales.
- **Siempre** especificar `ON` clauses claras y optimizadas.
- **Siempre** usar `EXCEPTION JOIN` o `NOT EXISTS` para auditorías de registros faltantes.
- **Nunca** usar JOINs implícitos con WHERE (estilo antiguo).
- **Nunca** crear joins cartesianos (`CROSS JOIN`) sin justificación empresarial documentada.

```sql
-- ✅ Join explícito empresarial
SELECT C.CLIENTE_ID, CU.SALDO_DISPONIBLE
FROM CLIENTES C
INNER JOIN CUENTAS CU ON C.CLIENTE_ID = CU.CLIENTE_ID
LEFT JOIN PRODUCTOS P ON C.CLIENTE_ID = P.CLIENTE_ID AND P.ESTADO = 'ACTIVO'
WHERE C.ESTADO_CLIENTE = 'ACTIVO'
FOR READ ONLY;
```

---

## Reglas — Cursores y Paginación

- **Siempre** declarar cursor con `ORDER BY` específico y `OPTIMIZE FOR n ROWS`.
- **Siempre** usar FETCH en bloques (bulk fetch) para mejor rendimiento.
- **Siempre** cerrar cursores con `CLOSE` — cada `DECLARE` debe tener su `CLOSE` correspondiente.
- **Nunca** dejar cursores abiertos sin cerrar.

---

## Reglas — Window Functions y OLAP

- **Siempre** usar `PARTITION BY` apropiado en window functions.
- **Siempre** elegir correctamente entre `RANK`, `DENSE_RANK` y `ROW_NUMBER` según necesidad.
- **Siempre** usar `LAG`/`LEAD` para comparaciones temporales en lugar de self-joins.
- **Siempre** distinguir `ROWS` vs `RANGE` en window frames:
  - `ROWS`: cada fila individual.
  - `RANGE`: agrupa filas con valores iguales.
- **Siempre** usar `FIRST_VALUE`/`LAST_VALUE` con frame completo (`ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING`).
- **Nunca** usar window functions sin `PARTITION BY` cuando se requiere agrupación.

---

## Reglas — CTEs y Recursividad SQL

- **Siempre** usar CTEs (`WITH`) para consultas complejas en lugar de subqueries anidados.
- **Siempre** incluir límite de profundidad en CTEs recursivas (ej. `WHERE nivel < 8`).
- **Siempre** usar `CYCLE` clause en recursiones complejas para detectar ciclos.
- **Siempre** usar `SEARCH DEPTH FIRST` o `BREADTH FIRST` para controlar orden de procesamiento.
- **Siempre** usar `UNION ALL` (no `UNION`) en CTEs recursivas.
- **Siempre** que se use `CONNECT BY`, agregar `NOCYCLE` si hay riesgo de datos cíclicos.
- **Nunca** crear recursión SQL sin control de profundidad. Riesgo: loop infinito, crash del job.

```sql
-- ✅ CTE recursiva segura
WITH JERARQUIA (EMP_ID, NIVEL) AS (
  SELECT EMP_ID, 0 FROM EMPLEADOS WHERE SUPERVISOR_ID IS NULL
  UNION ALL
  SELECT E.EMP_ID, J.NIVEL + 1
  FROM EMPLEADOS E INNER JOIN JERARQUIA J ON E.SUPERVISOR_ID = J.EMP_ID
  WHERE J.NIVEL < 8  -- ✅ Límite obligatorio
)
SEARCH DEPTH FIRST BY EMP_ID SET order_col
CYCLE EMP_ID SET is_cycle TO 'Y' DEFAULT 'N'
SELECT * FROM JERARQUIA WHERE is_cycle = 'N';
```

---

## Reglas — Predicados y Búsquedas

- **Siempre** usar `ESCAPE` clause con patrones `LIKE` que contengan `%` o `_` en datos de usuario.
- **Siempre** ordenar predicados `WHERE` del más selectivo al menos selectivo.
- **Siempre** usar `EXISTS` en lugar de `IN` para subqueries grandes (mejor performance).
- **Siempre** usar `BETWEEN` en lugar de comparaciones múltiples para rangos.
- **Siempre** controlar orden de evaluación con paréntesis en `AND`/`OR` complejos.
- **Siempre** usar comparación de tuplas para múltiples campos cuando aplique: `(COL1, COL2) = (:v1, :v2)`.
- **Nunca** usar `HAVING` donde debería ir `WHERE` (filtros pre-agrupación vs post-agrupación).

---

## Reglas — Operadores de Conjunto

- **Siempre** preferir `UNION ALL` sobre `UNION` cuando no hay duplicados (evita sort innecesario).
- **Siempre** colocar `ORDER BY` solo en la consulta externa final.
- **Siempre** incluir identificador de origen en `UNION` complejos (ej. `'DEPT' AS source_type`).
- **Siempre** usar `INTERSECT` para auditorías de intersección y `EXCEPT` para análisis de gaps.

---

## Reglas — DDL y Objetos de Base de Datos

- **Siempre** incluir `PRIMARY KEY` y `FOREIGN KEY` en `CREATE TABLE`.
- **Siempre** incluir `CHECK` constraints para validación de dominio.
- **Siempre** crear índices compuestos en campos de filtro frecuente.
- **Siempre** usar `IDENTITY` columns para IDs autogenerados.
- **Siempre** documentar MQTs (Materialized Query Tables) y temporal tables para auditoría.

---

## Reglas — Bulk Operations

- **Siempre** usar `MERGE` para operaciones UPSERT eficientes.
- **Siempre** usar INSERT múltiple en lotes para batch processing.

> Reglas de COMMIT HOLD, SAVEPOINT e intervalos de commit en procesamiento batch están en [performance](performance.md) § Procesamiento Batch.

---

## Criterio de aceptación

- Cero ocurrencias de `SELECT *` en el fuente.
- Cero JOINs implícitos (WHERE style) — todos los JOINs son explícitos.
- Cero cursores declarados sin `CLOSE` correspondiente.
- Cero CTEs recursivas sin límite de profundidad.
- SET OPTION presente y completo en todo fuente SQLRPGLE.
- CRTSQLRPGI documentado en header del fuente.
- Todas las window functions tienen `PARTITION BY` apropiado cuando se requiere agrupación.
- Patrones `LIKE` con datos de usuario usan `ESCAPE` clause.
- Índices presentes en campos de `WHERE` clauses en SQL embebido.
- Cero mezcla de Chain nativo y SQL embebido sobre el mismo archivo en fuentes SQLRPGLE nuevos.
- Migraciones a SQLRPGLE reestructuradas para SQL (no traducciones literales Chain→SELECT).
