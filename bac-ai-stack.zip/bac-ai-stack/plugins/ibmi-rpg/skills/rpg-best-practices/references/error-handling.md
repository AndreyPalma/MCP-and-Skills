# Manejo de Errores

## Objetivo

Validar que el fuente RPGLE/SQLRPGLE implemente manejo de errores robusto, verificación de SQLCODE en toda operación SQL, transacciones con COMMIT/ROLLBACK correcto, logging de auditoría y prevención de deadlocks y race conditions.

**¿Por qué?** Sin `(e)` en I/O o sin `monitor` en operaciones, los errores generan excepciones que cierran todo el job. Sin ROLLBACK, transacciones parciales corrompen datos. Sin logging, no se puede auditar quién cambió qué — requisito regulatorio bancario.

---

## Reglas — Monitor / On-Error

- **Siempre** envolver operaciones críticas en bloques `monitor/on-error/endmon`.
- **Siempre** incluir `(e)` extender en operaciones I/O que pueden fallar.
- **Siempre** capturar y loguear el error específico antes de retornar.
- **Nunca** dejar operaciones I/O o conversiones (`%dec`, `%int`) sin protección de error.
- **Nunca** dejar `on-error` vacío — siempre debe manejar, registrar o reportar la excepción. Un `on-error` vacío silencia errores y oculta defectos en producción.

```rpgle
// ✅ Monitor con manejo diferenciado
monitor;
  exec sql UPDATE CUENTAS SET SALDO = SALDO + :monto
           WHERE ID_CUENTA = :cuentaId;

  if sqlcode <> 0;
    select;
      when sqlcode = 100;
        logWarning('Cuenta no encontrada: ' + cuentaId);
        return CUENTA_NO_ENCONTRADA;
      when sqlcode < 0;
        logError('Error DB: SQLCODE ' + %char(sqlcode));
        return ERROR_DATABASE;
    endsl;
  endif;

on-error;
  exec sql ROLLBACK;
  logError('Excepción: ' + %char(%error));
  return ERROR_GENERAL;
endmon;
```

---

## Reglas — Bloques de Control Vacíos

- **Nunca** dejar `ELSE` vacío — omitir la cláusula si no hay acción alternativa.
- **Nunca** dejar `OTHER` vacío en `SELECT/WHEN` — omitir si no hay lógica.

```rpgle
// ❌ ELSE vacío innecesario
if condicion;
  ejecutarLogica();
else;
  // nada
endif;

// ✅ Sin ELSE innecesario
if condicion;
  ejecutarLogica();
endif;

// ❌ OTHER vacío innecesario
select;
  when tipo = 'A';
    procesarTipoA();
  other;
    // vacío
endsl;

// ✅ Sin OTHER innecesario
select;
  when tipo = 'A';
    procesarTipoA();
endsl;
```

---

## Reglas — Verificación de SQLCODE

- **Siempre** verificar SQLCODE después de TODA operación SQL.
- **Siempre** diferenciar: `SQLCODE = 0` (éxito), `SQLCODE = 100` (no encontrado), `SQLCODE < 0` (error DB).
- **Siempre** loguear el SQLCODE específico en errores para diagnóstico.
- **Nunca** asumir que una operación SQL fue exitosa sin verificar SQLCODE.

---

## Reglas — COMMIT / ROLLBACK

- **Siempre** usar `COMMIT` explícito al completar transacciones exitosas.
- **Siempre** usar `ROLLBACK` en bloques `on-error` para deshacer cambios parciales.
- **Siempre** especificar `ISOLATION LEVEL` apropiado: `READ COMMITTED` para operaciones estándar, `SERIALIZABLE` para operaciones que requieren locks exclusivos.
- **Nunca** iniciar transacción sin manejo de ROLLBACK en caso de error.

> Para reglas de COMMIT HOLD, commits parciales, SAVEPOINT e intervalos de commit en procesamiento batch, ver [performance](performance.md) § Procesamiento Batch.

---

## Reglas — Prevención de Deadlocks

- **Siempre** mantener un orden consistente de locks entre procesos: ej. SIEMPRE Cliente → Cuenta → Transacción.
- **Siempre** usar `SELECT ... FOR UPDATE` para locks explícitos cuando se necesita modificar registros.
- **Siempre** mantener la duración de locks al mínimo posible.
- **Nunca** obtener locks en orden diferente en procesos concurrentes (Proceso A: Lock A→B; Proceso B: Lock B→A = DEADLOCK).

```rpgle
// ✅ Orden consistente de locks: Cliente → Cuenta
exec sql SELECT CLIENTE_ID INTO :wsId FROM CLIENTES
         WHERE CLIENTE_ID = :clienteId FOR UPDATE;
exec sql SELECT SALDO INTO :wsSaldo FROM CUENTAS
         WHERE NUMERO_CUENTA = :cuenta FOR UPDATE;
exec sql UPDATE CUENTAS SET SALDO = SALDO - :monto
         WHERE NUMERO_CUENTA = :cuenta;
exec sql COMMIT;
```

---

## Reglas — Prevención de Race Conditions

- **Siempre** usar `SELECT ... FOR UPDATE` + `UPDATE` atómico en lugar de SELECT seguido de UPDATE separado.
- **Siempre** implementar optimistic locking cuando sea viable: verificar timestamp/versión antes de actualizar.
- **Siempre** verificar `sqlerrd(3)` = 1 (exactamente 1 fila afectada) después de UPDATE con condición de versión.
- **Nunca** leer saldo, verificar fondos y actualizar en operaciones separadas sin lock — otro proceso puede cambiar el saldo entre la lectura y la escritura.

---

## Reglas — Prevención de Memory Leaks

- **Siempre** liberar punteros (`dealloc` + `= *null`) en TODOS los caminos de salida (incluyendo early returns y on-error).
- **Siempre** usar patrón try-finally: allocar en monitor, liberar después del endmon.
- **Nunca** hacer `return` dentro de un procedimiento sin liberar punteros allocados.
- **Nunca** hacer `dealloc` de puntero no allocado (verificar `<> *null` primero).

---

## Reglas — Overflow en Cálculos Financieros

- **Siempre** usar precisión extendida (`packed(20:6)`) para cálculos intermedios antes de redondear al resultado final.
- **Siempre** validar rangos de entrada (capital, tasa, días) ANTES del cálculo.
- **Siempre** aplicar redondeo bancario apropiado al resultado final.
- **Siempre** loguear cálculos de auditoría (capital + tasa + días + resultado).

---

## Reglas — Logging y Auditoría

- **Siempre** registrar transacciones críticas con: operación, datos clave, usuario, timestamp.
- **Siempre** usar funciones centralizadas de logging (`logError`, `logWarning`, `logTransaccion`).

> Restricciones sobre qué datos incluir en logs (PCI-DSS, datos sensibles, mensajes que no revelen estructura de BD) están definidas en [security](security.md).

---

## Reglas — Retry Logic en Locks (%status=1218)

- **Siempre** implementar retry logic al detectar conflicto de lock (`%status=1218`): mínimo 3 intentos con espera progresiva.
- **Siempre** loguear cada intento fallido y el resultado final.
- **Nunca** asumir que un lock siempre estará disponible — en ambientes concurrentes los conflictos son frecuentes.

---

## Reglas — Transacciones Atómicas I/O Nativo (CHAIN→UPDATE)

- **Siempre** hacer operaciones de lectura-modificación-escritura de forma atómica en I/O nativo.
- **Siempre** usar `COMMIT`/`ROLLBACK` en operaciones financieras relacionadas.
- **Siempre** mantener lock hasta completar la unidad de trabajo.
- **Siempre** documentar si journaling no aplica — justificar.
- **Nunca** separar lectura de saldo y actualización sin lock (race condition).

```rpgle
// ❌ CRÍTICO — Race condition: window de vulnerabilidad entre CHAIN y UPDATE
CHAIN (account) MASTER;
balance = MSTBAL;
newBalance = balance - amount;    // Otro job puede leer aquí
MSTBAL = newBalance;
UPDATE MSTREC;

// ✅ Operación atómica — sin window de vulnerabilidad
CHAIN (account) MASTER;
MSTBAL = MSTBAL - amount;
UPDATE MSTREC;
```

---

## Reglas — Validación de Entrada antes de Conversión

- **Siempre** validar tipo y contenido de entrada ANTES de usar `%DEC`, `%INT` u otras conversiones.
- **Siempre** usar `%CHECK` para verificar caracteres válidos antes de conversión numérica.
- **Nunca** confiar en conversión directa sin guard (`%DEC(input)` sin validar puede producir 0 con 'ABC').
- Reportar conversiones sin protección `monitor/on-error` como CRÍTICO.

```rpgle
// ❌ CRÍTICO — ¿Qué si input = 'ABC'?
amount = %DEC(input);

// ✅ Validación + monitor
IF %CHECK('0123456789.-' : input) > 0;
  RETURN *OFF;
ENDIF;
MONITOR;
  amount = %DEC(input : 15 : 2);
ON-ERROR;
  logError('Conversión inválida');
  RETURN *OFF;
ENDMON;
```

---

## Reglas — Verificación de %FOUND / %ERROR post-I/O

- **Siempre** verificar `%FOUND` después de operaciones `CHAIN`, `SETLL`, `SETGT`.
- **Siempre** verificar `%ERROR` después de operaciones I/O con extender `(e)`.
- **Siempre** verificar `%EOF` después de operaciones `READ`, `READE`, `READP`, `READPE`.
- **Nunca** asumir que una operación I/O encontró registro sin verificar el indicador correspondiente.

> Para verificación de I/O con indicadores en columnas resultantes (formato Fixed/Legacy), ver [legacy](legacy.md).

```rpgle
// ❌ CRÍTICO — ¿Qué si no existe?
CHAIN (account) MASTER;
balance = MSTBAL;

// ✅ Verificación obligatoria
CHAIN (account) MASTER;
IF %FOUND;
  balance = MSTBAL;
ENDIF;
```

---

## Reglas — Data Areas con Lock Mínimo

- **Siempre** liberar lock de data area inmediatamente después de leer/escribir.
- **Siempre** procesar fuera del lock — nunca dentro.
- **Nunca** mantener lock de data area durante procesamiento largo (>100ms).

```rpgle
// ❌ Lock prolongado → otros jobs bloqueados
IN *LOCK DTAARA;
value = DTAARA;
FOR i = 1 TO 1000;
  // cálculos largos
ENDFOR;
OUT *LOCK DTAARA;

// ✅ Liberar rápido, procesar fuera
IN *LOCK DTAARA;
value = DTAARA;
OUT *LOCK DTAARA;
FOR i = 1 TO 1000;
  // cálculos fuera del lock
ENDFOR;
```

---

## Reglas — Overrides con Cleanup Garantizado

- **Siempre** cerrar overrides con `DLTOVR` en todos los caminos de salida (éxito y error).
- **Siempre** usar patrón monitor con cleanup en on-error.
- **Nunca** hacer `RETURN` sin antes ejecutar `DLTOVR` del override activo.

```rpgle
// ❌ Override persiste en el job
OVRDBF FILE(MASTER) TOFILE(MASTERTEST);
// Procesamiento
RETURN;

// ✅ Cleanup garantizado
OVRDBF FILE(MASTER) TOFILE(MASTERTEST);
MONITOR;
  // Procesamiento
  DLTOVR FILE(MASTER);
ON-ERROR;
  DLTOVR FILE(MASTER);  // Cleanup en error también
ENDMON;
```

---

## Reglas — CLLE/CLP: MONMSG Específicos

- **Siempre** usar MONMSG con ID específico (ej. `CPF2105`) en código CLLE/CLP.
- **Siempre** validar variables antes de usarlas en comandos CL.
- **Nunca** usar MONMSG catch-all (`MSGID(CPF0000)`) — oculta errores reales y dificulta diagnóstico.

```cl
// ❌ Catch-all peligroso — oculta errores
MONMSG MSGID(CPF0000)
DLTF FILE(QTEMP/TEMP)

// ✅ Específico: "objeto no encontrado"
MONMSG MSGID(CPF2105)
```

---

## Criterio de aceptación

- Cero operaciones I/O sin verificación de `%FOUND`, `%EOF` o `%ERROR`.
- Cero operaciones SQL sin verificación de SQLCODE.
- Cero transacciones sin COMMIT/ROLLBACK.
- Cero bloques `on-error` vacíos.
- Cero bloques `ELSE` o `OTHER` vacíos.
- Cero conversiones (`%DEC`, `%INT`) sin validación previa o `monitor/on-error`.
- Cero `RETURN` sin liberar punteros allocados.
- Cero data areas con lock durante procesamiento largo.
- Cero overrides sin cleanup en todos los paths de salida.
- Retry logic presente para conflictos de lock en ambientes concurrentes.
- Logging centralizado con operación, datos clave, usuario y timestamp.
- MONMSG específicos en CLLE/CLP (no catch-all).
