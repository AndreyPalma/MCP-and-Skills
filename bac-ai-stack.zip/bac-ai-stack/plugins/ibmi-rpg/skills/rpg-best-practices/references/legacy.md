# Código Legacy (Fixed Format)

## Objetivo

Proporcionar reglas específicas para trabajar con fuentes RPGLE/RPG III en formato columnar fijo (Fixed Format) que existen en producción. Estos fuentes son críticos para la operación y requieren mantenimiento seguro respetando las restricciones del formato columnar.

**¿Por qué?** Existen fuentes críticos en producción escritos en formato columnar fijo (hojas H, F, D, C, P, O) que NO pueden ser convertidos a fully free de forma inmediata. Cuando un desarrollador necesita modificar, corregir o extender estos fuentes, debe aplicar reglas adaptadas que prioricen funcionalidad, seguridad y mantenibilidad — sin penalizar por el formato heredado.

---

## Reglas — Detección de Formato Legacy

La detección completa de formato (Full Free, Fixed, Mixto) y la tabla de clasificación por extensión/indicador están definidas en **SKILL.md § Paso 1 — Detectar formato y lenguaje**. Este archivo aplica cuando el formato detectado es **Fixed Format (Legacy)**.

- **Nunca** penalizar formato columnar en código legacy — es fixed por diseño.
- **Nunca** exigir conversión a fully free como requisito para aprobar una revisión de código legacy.

---

## Reglas — Distribución de Columnas (Layout)

Referencia rápida de la distribución de columnas por tipo de especificación:

| Especificación | Col 6 | Rango principal | Descripción |
|---------------|-------|-----------------|-------------|
| **H-Spec** | `H` | 7–80 | Control de compilación (keywords) |
| **F-Spec** | `F` | 7–80 | Declaración de archivos |
| **D-Spec** | `D` | 7–80 | Definición de variables, DS, constantes |
| **C-Spec** | `C` | 7–80 | Cálculos y lógica (factor 1, opcode, factor 2, resultado) |
| **P-Spec** | `P` | 7–80 | Inicio/fin de procedimientos |
| **O-Spec** | `O` | 7–80 | Especificaciones de salida |
| **Comentario** | `*` en col 7 | — | Línea de comentario completo |

### C-Spec — Detalle de columnas de cálculo

| Columnas | Contenido |
|----------|-----------|
| 7–8 | Indicadores de control (AN/OR) |
| 9–11 | Indicadores de condición (N01–N99) |
| 12–25 | Factor 1 |
| 26–35 | Opcode (operación + extender) |
| 36–49 | Factor 2 |
| 50–63 | Campo resultado |
| 64–68 | Longitud del resultado |
| 69 | Posiciones decimales |
| 71–76 | Indicadores resultantes (HI/LO/EQ) |

- **Siempre** respetar las posiciones de columna al modificar código en C-Spec.
- **Nunca** desplazar código fuera de las columnas asignadas — causa errores de compilación silenciosos.

---

## Reglas — H-Spec (Especificaciones de Control)

- **Siempre** verificar que el H-Spec incluya `DATFMT`, `TIMFMT`, `DFTACTGRP`, `ACTGRP` y `BNDDIR` cuando aplique.
- **Siempre** preferir keywords explícitas sobre valores por defecto del compilador.
- **Siempre** que el H-Spec sea incompleto, sugerir como mejora incremental agregar los keywords faltantes.

```
     H DATFMT(*ISO) TIMFMT(*ISO) DFTACTGRP(*NO) ACTGRP('EMPRESA')
     H BNDDIR('EMPRESABND001') DEBUG(*YES)
```

---

## Reglas — F-Spec (Declaración de Archivos)

- **Siempre** declarar archivos con tipo de acceso explícito (`IF` input full-procedural, `UF` update full-procedural, `O` output).
- **Siempre** usar `KEYED` en archivos accedidos por clave.
- **Siempre** incluir keyword `RENAME` si el formato de registro tiene nombre genérico por defecto.
- **Siempre** documentar cada archivo declarado con comentario de propósito.
- **Nunca** declarar archivos que no se usan en el programa — eliminar F-Specs sin utilizar.

```
     FMASTER    IF   E           K DISK    RENAME(MSTREC:MASTERR)
     FTRANSACT  UF A E           K DISK
     FREPORT    O    E             PRINTER OFLIND(*INOF)
```

---

## Reglas — D-Spec (Definiciones)

- **Siempre** inicializar variables con `INZ` en D-Spec.
- **Siempre** usar tipos con precisión suficiente para datos financieros (mín. `15P 2` para montos).
- **Siempre** definir constantes con `C` en columna de tipo de definición.
- **Siempre** documentar Data Structures con comentarios que expliquen su propósito.
- **Siempre** nombrar subcampos de DS con prefijo que identifique la estructura.
- **Nunca** dejar variables sin `INZ` — contienen valores residuales.
- **Nunca** usar `packed(7:2)` o `7P 2` para montos que puedan superar 99,999.99.

```
     D wsClienteId    S             10A   INZ(*BLANKS)
     D wsMonto         S             15P 2 INZ(0)
     D MAX_INTENTOS    C                   CONST(3)
     D dsCliente       DS                  QUALIFIED
     D  clId                         10A   INZ(*BLANKS)
     D  clNombre                     50A   INZ(*BLANKS)
     D  clSaldo                      15P 2 INZ(0)
```

---

## Reglas — C-Spec (Cálculos) y Opcodes Legacy

- **Siempre** usar opcodes modernos disponibles en RPG IV Fixed Format:
  - `EVAL` en lugar de `Z-ADD`, `Z-SUB`, `MOVE`, `MOVEL` cuando sea posible.
  - `EVALR` para asignación con alineación derecha.
  - `IF`/`ELSE`/`ENDIF` en lugar de `IFxx`/`ELSE`/`ENDIF` (ej. `IFEQ`, `IFGT`, `IFLT`).
  - `DOW`/`DOU`/`ENDDO` en lugar de `DOWxx`/`DOUxx`.
  - `SELECT`/`WHEN`/`OTHER`/`ENDSL` para decisiones múltiples.
  - `FOR`/`ENDFOR` para loops con contador.
  - `CALLP` para invocación de procedimientos con prototipos.
- **Siempre** que se modifique una línea con opcode obsoleto (`MOVE`, `MOVEL`, `Z-ADD`, `Z-SUB`, `COMP`, `IFxx`, `DOWxx`, `CASxx`), modernizarla al opcode equivalente RPG IV si el cambio es seguro y localizado.
- **Siempre** usar extender `(E)` en operaciones que pueden fallar (I/O, conversiones).
- **Siempre** usar extender `(N)` en `CHAIN` para operaciones de solo lectura (no bloquea registro).
- **Nunca** introducir opcodes RPG III obsoletos (`MOVE`, `MOVEL`, `Z-ADD`, `Z-SUB`, `COMP`, `GOTO`, `TAG`, `CABxx`, `CASxx`) en líneas nuevas.
- **Nunca** usar `GOTO`/`TAG` — reemplazar con `IF`/`ELSE`/`ENDIF` o `DOW`/`DOU`/`LEAVE`/`ITER`.
- **Nunca** usar `*LIKE DEFINE` — usar D-Spec con `LIKE` keyword.

```
     C* ❌ Opcodes RPG III obsoletos
     C                   Z-ADD     0             wsMonto
     C                   MOVE      wsInput       wsOutput
     C     wsValor       IFGT      0
     C                   GOTO      FIN
     C     FIN           TAG

     C* ✅ Opcodes RPG IV equivalentes
     C                   EVAL      wsMonto = 0
     C                   EVAL      wsOutput = wsInput
     C                   IF        wsValor > 0
     C                   LEAVE
     C                   ENDIF
```

---

## Reglas — Subrutinas (BEGSR/ENDSR)

- **Siempre** evaluar subrutinas existentes por lógica, seguridad y mantenibilidad — no penalizar su existencia en código legacy.
- **Siempre** que las subrutinas sean funcionales y correctas, dejarlas como están.
- **Siempre** preferir procedimientos (`P-Spec` con `BEGPROC`/`ENDPROC`) sobre subrutinas en modificaciones mayores, si el refactoring es viable sin riesgo.
- **Siempre** nombrar subrutinas descriptivamente: `srValidarCliente`, `srCalcularInteres`, no `sr001`, `srAux`.
- **Siempre** documentar cada subrutina con comentario de propósito.
- **Siempre** evaluar subrutinas con más de 100 líneas como candidatas a procedimiento.
- **Nunca** introducir subrutinas nuevas (`BEGSR`/`ENDSR`) — usar procedimientos (`dcl-proc` en mixed format o `P-Spec` en fixed format).
- **Nunca** anidar `EXSR` de forma excesiva (máximo 3 niveles de llamada entre subrutinas).
- **Nunca** compartir variables entre subrutinas sin documentar cuáles son las variables compartidas.

```
     C* ✅ Subrutina legacy con documentación
     C*=============================================================
     C* srValidarCliente - Valida existencia y estado del cliente
     C* Entrada: wsClienteId (variable global)
     C* Salida:  wsClienteValido (indicador global)
     C*=============================================================
     C     srValidarCli  BEGSR
     C     wsClienteId   CHAIN     CLIENTES
     C                   IF        %FOUND
     C                   EVAL      wsClienteValido = *ON
     C                   ELSE
     C                   EVAL      wsClienteValido = *OFF
     C                   ENDIF
     C                   ENDSR
```

---

## Reglas — Indicadores

- **Siempre** documentar cada indicador numérico con comentario que explique su propósito.
- **Siempre** preferir indicadores nombrados (`dcl-s` tipo `IND` en D-Spec) sobre indicadores numéricos (`*IN01`–`*IN99`) en código nuevo dentro de fuentes legacy.
- **Siempre** agrupar documentación de indicadores al inicio del fuente o en D-Spec.
- **Siempre** verificar que indicadores resultantes (HI/LO/EQ en columnas 71–76) estén correctamente asignados.
- **Nunca** reutilizar un indicador numérico para propósitos distintos en diferentes partes del programa — causa confusión.
- **Nunca** dejar indicadores sin documentar.

```
     D* Mapa de indicadores:
     D*   *IN30 = Cliente encontrado
     D*   *IN31 = Error en lectura de archivo
     D*   *IN40 = Fin de archivo (EOF)
     D*   *INLR = Last Record (fin de programa)
     D*   *INOF = Overflow de impresora

     C* ✅ Indicadores documentados y con propósito claro
     C     wsKey         CHAIN     MASTER                           30
     C  N30              IF        *IN31 = *OFF
     C* Cliente no encontrado y sin error
     C                   EVAL      wsMsg = 'Cliente no existe'
     C                   ENDIF
```

---

## Reglas — I/O Nativo en Fixed Format

- **Siempre** verificar `%FOUND` después de `CHAIN`.
- **Siempre** verificar `%EOF` después de `READ`, `READE`, `READP`, `READPE`.
- **Siempre** usar `(N)` en `CHAIN` para operaciones de solo lectura.
- **Siempre** verificar indicadores resultantes cuando se usan en lugar de BIFs.
- **Siempre** usar `UNLOCK` si se bloquea un registro innecesariamente.
- **Siempre** que se use `CHAIN` seguido de `UPDATE`, mantener atomicidad (sin lógica compleja entre ambos).
- **Nunca** asumir que una operación I/O fue exitosa sin verificar indicador o BIF.
- **Nunca** separar `CHAIN` y `UPDATE` con lógica extensa — riesgo de race condition y lock prolongado.

```
     C* ✅ Lectura segura con verificación
     C     wsCuenta      CHAIN(N)  CUENTAS                          30
     C   30              IF        *IN30 = *ON
     C* Registro encontrado — procesar
     C                   EVAL      wsSaldo = CTSALDO
     C                   ELSE
     C* Registro no encontrado
     C                   EVAL      wsError = 'Cuenta no existe'
     C                   ENDIF

     C* ✅ Update atómico
     C     wsCuenta      CHAIN     CUENTAS                          30
     C   30              IF        *IN30 = *ON
     C                   EVAL      CTSALDO = CTSALDO - wsMonto
     C                   UPDATE    CTAREC
     C                   ENDIF
```

---

## Reglas — PLIST y KLIST

- **Siempre** documentar cada `PLIST` (lista de parámetros) y `KLIST` (lista de claves) con comentarios.
- **Siempre** nombrar PLISTs y KLISTs descriptivamente.
- **Siempre** que se modifique un CALL con PLIST, verificar que el programa llamado espera los mismos parámetros (cantidad, tipo, longitud).
- **Siempre** preferir prototipos (`dcl-pr`/`dcl-pi` en D-Spec) sobre `PLIST`/`PARM` en modificaciones mayores.
- **Nunca** introducir `PLIST`/`PARM` nuevos — usar prototipos.
- **Nunca** cambiar orden o tipo de parámetros en un `PLIST` sin verificar todos los programas que lo invocan.

```
     C* ✅ KLIST documentada
     C*------------------------------------------------------------
     C* klCuenta: Clave compuesta para archivo CUENTAS
     C*   Campo 1: wsSucursal (código de sucursal)
     C*   Campo 2: wsNumCuenta (número de cuenta)
     C*------------------------------------------------------------
     C     klCuenta      KLIST
     C                   KFLD                    wsSucursal
     C                   KFLD                    wsNumCuenta

     C* ✅ PLIST documentada
     C     *ENTRY        PLIST
     C                   PARM                    pCliente
     C                   PARM                    pMonto
     C                   PARM                    pResultado
```

---

## Reglas — Manejo de Errores en Fixed Format

- **Siempre** usar extender `(E)` en operaciones I/O y verificar `%ERROR` después.
- **Siempre** que el programa no soporte `MONITOR/ON-ERROR` (RPG III puro), usar indicadores de error en columnas resultantes.
- **Siempre** verificar `%STATUS` después de operaciones que puedan fallar.
- **Siempre** implementar `*PSSR` (Program Status Subroutine) como safety net general:
  - Loguear error con código de estado, nombre de programa y línea.
  - Ejecutar cleanup (liberar locks, cerrar archivos temporales).
  - Retornar con `*CANCL` o código de error apropiado.
- **Siempre** implementar `INFSR` (File Information Subroutine) para archivos críticos.
- **Nunca** dejar programas sin `*PSSR` — un error no controlado cancela el job.
- **Nunca** dejar `*PSSR` o `INFSR` vacías — deben manejar, registrar o reportar.

```
     C* ✅ *PSSR como safety net
     C     *PSSR         BEGSR
     C                   EVAL      wsStatus = %STATUS
     C                   EVAL      wsProgram = %PROC
     C* Loguear error
     C                   CALLP     logError(wsStatus : wsProgram)
     C* Cleanup
     C                   EVAL      *INLR = *ON
     C                   RETURN
     C                   ENDSR

     C* ✅ Uso de indicadores de error en operaciones I/O
     C     wsKey         CHAIN(E)  MASTER                           30
     C                   IF        %ERROR
     C                   EVAL      wsMsg = 'Error I/O: ' +
     C                                     %CHAR(%STATUS)
     C                   ENDIF
```

---

## Reglas — CALL/CALLB (Invocación de Programas)

- **Siempre** preferir `CALLP` con prototipos sobre `CALL`/`CALLB` legacy.
- **Siempre** verificar indicadores de error después de `CALL` (`LR` en columna 73–74).
- **Siempre** documentar qué programa se invoca y qué parámetros espera.
- **Nunca** introducir `CALL`/`CALLB` nuevos — usar `CALLP` con prototipos.
- **Nunca** asumir que un `CALL` fue exitoso sin verificar indicador de error.

```
     C* ❌ CALL sin verificación de error
     C                   CALL      'PGMCALC'
     C                   PARM                    pMonto
     C                   PARM                    pResult

     C* ✅ CALL con indicador de error
     C                   CALL(E)   'PGMCALC'
     C                   PARM                    pMonto
     C                   PARM                    pResult
     C                   IF        %ERROR
     C                   EVAL      wsMsg = 'Error CALL PGMCALC'
     C                   ENDIF
```

---

## Reglas — Conversión de Datos Legacy

- **Siempre** convertir fechas con año de 2 dígitos usando **SRVPGM UTLS400** o programas **UTLSP4xx**. No reimplementar la lógica de ventana de siglo.
- **Siempre** que se use `MOVE`/`MOVEL` existente para conversión de tipos, documentar el comportamiento exacto (truncamiento, relleno).
- **Siempre** al modificar conversiones legacy, reemplazar `MOVE`/`MOVEL` por `EVAL` con BIFs explícitos (`%DEC`, `%CHAR`, `%INT`, `%DATE`).
- **Nunca** introducir `MOVE`/`MOVEL` nuevos para conversión de tipos.
- **Nunca** confiar en conversiones implícitas de `MOVE` entre tipos incompatibles.

```
     C* ❌ MOVE implícito entre tipos — comportamiento ambiguo
     C                   MOVE      wsAlpha        wsNumeric

     C* ✅ Conversión explícita con BIF
     C                   EVAL      wsNumeric = %DEC(wsAlpha:15:2)
```

---

## Reglas — Formato Mixto (Fixed + Free en mismo fuente)

- **Siempre** que un fuente legacy contenga secciones en formato mixto (fixed con `/free`...`/end-free`), respetar ambos formatos.
- **Siempre** aplicar reglas fixed format a las secciones fijas y reglas free format a las secciones `/free`.
- **Siempre** que se agregue código nuevo en un fuente mixto, escribirlo dentro del bloque `/free`...`/end-free` cuando exista.
- **Nunca** mezclar estilos arbitrariamente dentro de una misma sección.

```
     H DATFMT(*ISO) TIMFMT(*ISO)

     FMASTER    IF   E           K DISK

     D wsResult        S             15P 2 INZ(0)

      /free
        // Código nuevo en free format dentro de fuente legacy
        wsResult = calcularMonto(wsInput);
        if wsResult < 0;
          logError('Monto negativo detectado');
          return;
        endif;
      /end-free

     C* Código legacy existente que no se modifica
     C     *INLR         IFEQ      *ON
     C                   RETURN
     C                   ENDIF
```

---

## Reglas — Nomenclatura en Fixed Format

- **Siempre** respetar la limitación de 10 caracteres para nombres de variables en RPG III/IV fijo.
- **Siempre** usar prefijos consistentes para identificar tipo y scope:
  - `ws` = variable de trabajo (working storage).
  - `p` = parámetro de entrada.
  - `ds` = data structure.
  - `sr` = nombre de subrutina.
  - `kl` = nombre de KLIST.
  - `ct` = constante.
- **Siempre** mantener consistencia de nomenclatura dentro del fuente existente — no mezclar convenciones nuevas con las legacy dentro del mismo fuente sin plan de migración.
- **Nunca** exigir camelCase completo en fuentes donde la limitación de 10 caracteres lo impide.

---

## Reglas — Limpieza Segura de Código Legacy

- **Siempre** eliminar D-Specs, subrutinas y variables sin utilizar verificando que no haya referencia indirecta (vía indicadores, arrays dinámicos, `PLIST` ocultos).
- **Siempre** verificar impacto en programas que invocan (`CALL`) al fuente modificado antes de remover parámetros.
- **Siempre** que se elimine código, compilar y probar en ambiente de QA antes de promover.
- **Siempre** preferir eliminación sobre comentar — el historial lo gestiona el control de versiones. Si el ambiente no tiene control de versiones, documentar razón del comentario con fecha e iniciales.
- **Nunca** eliminar código sin compilación de verificación.
- **Nunca** cambiar el formato general del fuente (de fixed a free) como parte de un fix puntual — la conversión de formato es un proyecto separado.

---

## Reglas — Compilación de Fuentes Legacy

- **Siempre** documentar el comando de compilación correcto para el tipo de fuente:
  - RPG ILE: `CRTBNDRPG` o `CRTRPGMOD` + `CRTPGM`/`CRTSRVPGM`.
  - SQLRPGLE Fixed: `CRTSQLRPGI` con opciones apropiadas.
  - RPG III (OPM): `CRTRPGPGM` (solo mantenimiento — no crear nuevos).
  - CL Legacy: `CRTCLPGM` para CLP, `CRTBNDCL` para CLLE.
- **Siempre** incluir opciones de debug (`DBGVIEW(*SOURCE)` o `DBGVIEW(*LIST)`) en compilaciones de desarrollo.
- **Siempre** verificar `TGTRLS` (target release) para compatibilidad con la versión de OS instalada.
- **Nunca** compilar fuentes RPG III como ILE ni viceversa sin validar compatibilidad.

---

## Reglas — Mejoras Incrementales en Legacy

- **Siempre** priorizar correcciones de seguridad y funcionalidad sobre modernización de formato.
- **Siempre** sugerir mejoras incrementales viables sin exigir reescritura completa:
  - Agregar `(E)` a operaciones I/O que no lo tienen.
  - Agregar `*PSSR` si no existe.
  - Reemplazar `GOTO`/`TAG` por `IF`/`ENDIF` en la línea modificada.
  - Agregar documentación a indicadores no documentados.
  - Agregar `INZ` a variables sin inicialización.
  - Reemplazar `MOVE`/`MOVEL` por `EVAL` con BIFs en líneas modificadas.
- **Siempre** evaluar el impacto de cada mejora antes de aplicarla — un cambio cosmético no justifica riesgo en producción.
- **Nunca** exigir conversión masiva a free format como parte de un cambio puntual.
- **Nunca** rechazar código legacy funcional solo por usar formato columnar.

---

## Reglas — Migración de Legacy a Free Format

Estas reglas aplican cuando se planifica una migración completa (proyecto separado):

- **Siempre** migrar como proyecto independiente, no como efecto secundario de un fix.
- **Siempre** mantener backups del fuente original antes de migrar.
- **Siempre** convertir en este orden:
  1. H-Spec → `ctl-opt`
  2. F-Spec → `dcl-f`
  3. D-Spec → `dcl-s`, `dcl-ds`, `dcl-c`, `dcl-pr`, `dcl-pi`
  4. C-Spec → free-form expressions
  5. P-Spec → `dcl-proc`/`end-proc`
  6. Subrutinas → procedimientos
  7. Indicadores → variables nombradas
  8. `PLIST`/`KLIST` → prototipos y claves compuestas
  9. `CALL`/`CALLB` → `CALLP` con prototipos
  10. `MOVE`/`MOVEL` → `EVAL` con BIFs
- **Siempre** compilar y probar después de cada paso de conversión.
- **Siempre** que la migración se haga parcial (formato mixto), asegurar que las secciones migradas funcionen correctamente con las no migradas.
- **Nunca** migrar sin plan de testing completo que cubra todos los paths funcionales del programa.

---

> **Reglas de seguridad, rendimiento, SQL embebido y error-handling** que aplican a TODOS los formatos (free y fixed) están en sus documentos respectivos:
> - [security](security.md) — Validaciones, PCI-DSS, inyección, credenciales.
> - [error-handling](error-handling.md) — SQLCODE, COMMIT/ROLLBACK, monitor/on-error.
> - [performance](performance.md) — Caché, I/O eficiente, batch processing.
> - [sql-embedded](sql-embedded.md) — SET OPTION, JOINs, cursores, CTEs.
> - [architecture](architecture.md) — McCabe, modularización, ILE, documentación.

---

## Lineamientos Corporativos Adicionales

### Prohibición de comentarios en columnas 1–5 de código fijo

**❌ PROHIBIDO** colocar comentarios en las columnas 1–5 de cualquier especificación fija
(hojas H, D, F, C, P, O).

- Al modificar una línea que contenga comentarios en columnas 1–5, limpiarlos como parte
  del mismo pase, incluso si no son el objetivo principal del cambio.
- Esta regla aplica en mantenimiento de fuentes legacy: si se toca la línea, se corrige.

```
     * ❌ Comentario en columnas 1-5 — PROHIBIDO
     *-----------------------------
     H DATFMT(*ISO)

     * ✅ Comentario en columna 7 con asterisco — correcto
     H* Especificaciones de control
     H DATFMT(*ISO)
```

> Esta restricción es complementaria a la regla de `architecture.md § Formato de Fuentes`:
> "Nunca colocar comentarios en columnas 1–5 de hojas fijas. Limpiarlos al modificar
> líneas que los contengan."
> - [naming-types](naming-types.md) — Tipos de datos, precisión, punteros.

---

## Criterio de aceptación

- Formato del fuente identificado y documentado antes de evaluar.
- Cero operaciones I/O sin verificación de indicador o BIF (`%FOUND`, `%EOF`, `%ERROR`).
- Cero opcodes RPG III obsoletos (`MOVE`, `MOVEL`, `Z-ADD`, `GOTO`, `TAG`, `CASxx`) en líneas nuevas.
- Cero `CALL`/`CALLB` nuevos — usar `CALLP` con prototipos.
- Cero `PLIST`/`PARM` nuevos — usar prototipos.
- Cero subrutinas nuevas (`BEGSR`/`ENDSR`) — usar procedimientos.
- Cero variables sin `INZ` en D-Spec.
- Cero indicadores numéricos sin documentación.
- `*PSSR` presente como safety net en todo programa.
- Opcodes legacy existentes evaluados por funcionalidad y seguridad (no por formato).
- Mejoras incrementales sugeridas donde sean viables sin riesgo.
- Cero penalizaciones por uso de formato columnar en código existente.
- Compilación verificada con comando correcto para el tipo de fuente.
