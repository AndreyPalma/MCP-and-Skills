# Rendimiento

## Objetivo

Validar que el fuente RPGLE/SQLRPGLE cumpla los estándares de rendimiento empresarial BAC Latam: eficiencia I/O, patrones de caché, optimización SQL, control de recursividad en procedimientos, y procesamiento batch eficiente.

**¿Por qué?** Loops N² con tablas grandes causan timeouts. Sin índices, scans secuenciales de tablas millonarias tardan horas en lugar de milisegundos. Conexiones no pooled crean overhead que degrada performance exponencialmente bajo carga. En dominio bancario, un timeout de 30 segundos es un incidente de producción.

---

## Reglas — Eficiencia I/O

- **Siempre** aplicar control de ruptura para evitar lecturas repetitivas:
  ```rpgle
  // ✅ Control de ruptura — solo recarga cuando cambia
  if codigoEmisorActual <> codigoEmisorAnterior;
    cargarParametrosEmisor(codigoEmisorActual);
    codigoEmisorAnterior = codigoEmisorActual;
  endif;
  ```
- **Siempre** usar `chain(n)` para operaciones de solo lectura (no bloquea registro).
- **Siempre** minimizar apertura/cierre de archivos.
- **Nunca** hacer lecturas repetitivas al mismo registro dentro de un loop — cargar una vez y reutilizar.

---

## Reglas — Patrones de Caché

- **Siempre** implementar caché en memoria para datos consultados repetidamente (ej. parámetros de emisor).
- **Siempre** verificar caché ANTES de ejecutar SQL:
  ```rpgle
  parametros = buscarEnCache(codigoEmisor : arrayCache);
  if not parametros;
    exec sql SELECT ... INTO :param FROM PARAMETROS WHERE CODIGO = :codigoEmisor;
    if sqlcode = 0;
      agregarAlCache(codigoEmisor : param : arrayCache);
    endif;
  endif;
  ```
- **Siempre** incluir timestamp para invalidación de caché.
- **Nunca** ejecutar la misma query SQL en cada iteración de un loop sin caché.

---

## Reglas — Optimización SQL

- **Siempre** crear índices compuestos en campos de filtro frecuente. Sin índice, scans secuenciales de tablas millonarias tardan horas.
- **Siempre** documentar execution plans de queries críticas: costo, filas estimadas, uso de índice, buffer pool hits, tiempo promedio.
- **Nunca** usar archivos sin `KEYED` para acceso por clave — diferencia entre milisegundos y horas.

> Reglas detalladas de sintaxis SQL optimizada (`EXISTS` vs `IN`, `OPTIMIZE FOR`, `FOR READ ONLY`, selectividad de predicados) están en [sql-embedded](sql-embedded.md).

---

## Reglas — Recursividad en Procedimientos

- **Siempre** incluir parámetro de nivel de recursión en procedimientos recursivos.
- **Siempre** definir constante `MAX_RECURSION_LEVELS` como límite de profundidad.
- **Siempre** verificar nivel actual contra límite ANTES de recurrir.
- **Siempre** loguear error cuando se alcanza el máximo de recursión.
- **Siempre** verificar `%parms >= n` para parámetros opcionales de control de recursión.
- **Nunca** crear procedimiento recursivo sin límite de profundidad — riesgo de stack overflow.

```rpgle
// ✅ Recursividad controlada
dcl-proc calcularComision export;
  dcl-pi *n packed(15:2);
    ventaId like(VENTAS.ID);
    nivelRecursion int(3) const options(*nopass);
  end-pi;

  dcl-s nivelActual int(3) inz(1);
  dcl-c MAX_RECURSION const(5);

  if %parms >= 2;
    nivelActual = nivelRecursion;
  endif;

  if nivelActual > MAX_RECURSION;
    logError('Máx recursión: ' + %char(nivelActual));
    return 0;
  endif;

  // ... lógica recursiva con nivelActual + 1 ...
end-proc;
```

---

## Reglas — Procesamiento Batch

- **Siempre** usar `COMMIT HOLD` para mantener conexión abierta durante batch.
- **Siempre** hacer INSERT múltiple en lotes (no uno por uno).
- **Siempre** hacer commits parciales cada N registros (500–1000) para evitar locks largos.
- **Siempre** usar `SAVEPOINT` antes de cada lote para rollback granular.
- **Siempre** usar `MERGE` para operaciones UPSERT masivas.
- **Siempre** establecer `ISOLATION LEVEL` apropiado al inicio de la transacción.
- **Siempre** loguear progreso de lotes procesados.
- **Nunca** mantener un lock abierto durante toda la duración de un batch largo.

---

## Reglas — Testing y Calidad

- **Siempre** diseñar procedimientos testeables: responsabilidad única, parámetros y retornos claros, sin efectos secundarios ocultos.
- **Siempre** que existan tests, deben pasar. Si no existen en código legacy, no se penaliza.
- **Siempre** seguir patrón AAA (Arrange-Act-Assert) en tests RPGUnit.
- **Siempre** nombrar tests: `test_[método]_[escenario]_[resultado]`.

---

## Reglas — Métricas de Rendimiento

- **Siempre** documentar performance esperada de queries críticas (ej. `<50ms para 1M registros`).
- **Siempre** reportar queries sin índices apropiados como issue de rendimiento.
- **Siempre** que se detecten loops N² (loop anidado sobre misma tabla), reportar como issue ALTO.

| Indicador | Umbral | Acción |
|-----------|--------|--------|
| Loop N² sobre tabla | >1000 registros | Refactorizar a JOIN o subquery |
| Caché ausente en loop | >3 iteraciones | Implementar caché en memoria |
| KEYED ausente | Siempre | Agregar clave a archivo |

> Umbrales de tamaño de procedimiento y complejidad ciclomática están en [architecture](architecture.md). Umbrales SQL (`OPTIMIZE FOR`, etc.) están en [sql-embedded](sql-embedded.md).

---

## Criterio de aceptación

- Cero queries SQL críticas sin `OPTIMIZE FOR` o plan de optimización documentado.
- Cero procedimientos recursivos sin constante de límite máximo.
- Cero loops con lectura repetitiva sin control de ruptura o caché.
- Cero procesamiento batch sin COMMIT parcial y SAVEPOINT.
- Cero archivos accedidos por clave sin KEYED.
- Queries críticas documentadas con performance esperada.
