# Patrón CEXCEPTION — Manejo de Excepciones Corporativo BAC

## Cuándo cargar esta referencia

Cargar cuando la consulta involucre: CEXCEPTION, patrón corporativo de excepciones,
`throwNewException`, `catchException`, `CEXCEPBNDD`, ON-ERROR en servicios BAC,
propagación de errores entre capas, o manejo de excepciones en arquitectura
controlador + lógica de negocio.

---

## Problema que resuelve

Cuando un procedimiento retorna `*OFF`, el código consumidor no puede determinar la causa
del fallo:

```rpgle
// ❌ Sin CEXCEPTION — causa desconocida
if ObtenerRegistro(opcode);
  dsply 'Registro existe';
else;
  // ¿No encontrado? ¿Tabla inexistente? ¿Permisos? Imposible saberlo.
  dsply 'Registro no encontrado';
endIf;
```

El patrón CEXCEPTION resuelve esto: la capa de acceso a datos lanza una excepción
descriptiva; el consumidor la captura e inspecciona con precisión.

---

## Componentes principales

### Include y binding directory requeridos

```rpgle
Ctl-Opt BndDir('CEXCEPBNDD');
/INCLUDE CSYSTSRC/QSRCTXT,CEXCEPTION
```

### Los 4 procedimientos core

| Procedimiento | Firma | Rol |
|---|---|---|
| `CEXCEPTION_throwNewException` | `(msgId char(7) : msgFile char(10))` | Lanza excepción desde capa de datos |
| `CEXCEPTION_catchException` | `()` | Captura la excepción activa en ON-ERROR |
| `CEXCEPTION_getMessageId` | `() → char(7)` | Retorna el ID del mensaje capturado |
| `CEXCEPTION_getMessageText` | `() → varchar(500)` | Retorna el texto descriptivo del error |

---

## Lineamiento 1: Lanzar excepciones desde la capa de datos

Los procedimientos de acceso a datos **nunca** deben retornar `*OFF` en silencio.
Deben lanzar una excepción con `CEXCEPTION_throwNewException` indicando el message ID
y el message file correspondiente.

```rpgle
// ✅ Capa de acceso a datos — con CEXCEPTION
dcl-proc ObtenerRegistro;
  dcl-pi *n ind;
    pOpCode char(5) const;
  end-pi;
  dcl-s recordFound ind inz(*off);

  exec sql
    select 1 into :recordFound
      from MQA017
     where OPCODE = :pOpCode;

  select;
    when SQLSTATE = '00000';
      return *on;
    when SQLSTATE = '02000';
      // SQLSTATE 02000 = registro no encontrado
      CEXCEPTION_throwNewException(ERROR_REGISTRO_NO_EXISTE : 'CMSGFILE');
      return *off;
    other;
      // Cualquier otro código = error de sistema (permisos, tabla, etc.)
      CEXCEPTION_throwNewException(ERROR_FALLO_CONSULTA : 'CMSGFILE');
      return *off;
  endsl;

end-proc;
```

---

## Lineamiento 2: Capturar en la capa consumidora

`MONITOR / ON-ERROR` es el **único** mecanismo aprobado para capturar excepciones.
Dentro del `ON-ERROR` se debe llamar a `CEXCEPTION_catchException()` antes de
consumir el mensaje.

```rpgle
// ✅ Capa consumidora — captura y extrae información del error
monitor;
  if ObtenerRegistro(opcode);
    // lógica cuando el registro existe
  endIf;
on-error;
  CEXCEPTION_catchException();
  idError          = CEXCEPTION_getMessageId();
  descripcionError = %trim(CEXCEPTION_getMessageText());
  // comunicar el error al consumidor o a la bitácora
endmon;
```

---

## Lineamiento 3: Propagar hacia arriba en arquitectura de servicios

En la arquitectura controlador + lógica de negocio, la lógica de negocio captura la
excepción y la propaga como parámetros de salida (`pError`, `pErrorDescription`).
El controlador es el responsable de construir la respuesta de error.

```rpgle
// Capa de lógica de negocio — captura y propaga
monitor;
  // lógica del servicio...
on-error;
  CEXCEPTION_catchException();
  pError            = CEXCEPTION_getMessageId();
  pErrorDescription = %trim(CEXCEPTION_getMessageText());
  return *off;
endmon;
```

```rpgle
// Capa controladora — recibe y responde
status = LogicaNegocio(pServiceParms : pResponse : idError : errorDescription);

if not status;
  writeServiceErrorResponse(idError : errorDescription);
endIf;
```

---

## Lineamiento 4: Constantes para IDs de error

Los IDs de mensaje **nunca** deben escribirse como literales dispersos en el código.
Deben declararse como constantes con nombre descriptivo.

```rpgle
// ✅ Constantes con nombre descriptivo
dcl-c ERROR_TABLA_NO_ENCONTRADA  const('MSG0001');
dcl-c ERROR_REGISTRO_NO_EXISTE   const('MSG0002');
dcl-c ERROR_VALIDACION_NEGOCIO   const('MSG0003');

CEXCEPTION_throwNewException(ERROR_REGISTRO_NO_EXISTE : 'CMSGFILE');

// ❌ Literal directo — prohibido
CEXCEPTION_throwNewException('MSG0002' : 'CMSGFILE');
```

---

## Lineamiento 5: Nunca dejar ON-ERROR vacío

> Ver regla completa en [`error-handling.md`](error-handling.md) § Reglas — Monitor / On-Error.

En contexto CEXCEPTION, el `ON-ERROR` siempre debe ejecutar `CEXCEPTION_catchException()` antes de consumir el mensaje — de lo contrario `getMessageId()` y `getMessageText()` retornan valores vacíos.

```rpgle
// ✅ Correcto — captura, registra y propaga
on-error;
  CEXCEPTION_catchException();
  pError            = CEXCEPTION_getMessageId();
  pErrorDescription = %trim(CEXCEPTION_getMessageText());
  return *off;
endmon;
```

---

## Referencia rápida

| Situación | Acción |
|---|---|
| SQL no encuentra registro (`SQLSTATE 02000`) | `CEXCEPTION_throwNewException(ERROR_REGISTRO_NO_EXISTE : msgFile)` |
| Error SQL inesperado | `CEXCEPTION_throwNewException(ERROR_FALLO_CONSULTA : msgFile)` |
| Validación de negocio falla | `CEXCEPTION_throwNewException(ERROR_VALIDACION : msgFile)` |
| Capturar en consumidor | `MONITOR / ON-ERROR + CEXCEPTION_catchException()` |
| Obtener ID del error capturado | `CEXCEPTION_getMessageId()` |
| Obtener texto del error capturado | `CEXCEPTION_getMessageText()` |

---

## Integración con la arquitectura de servicios BAC

Este patrón es el mecanismo corporativo de propagación de errores entre capas.
Ver `references/error-handling.md` para integración detallada con SQLCODE, COMMIT/ROLLBACK
y deadlocks. El patrón CEXCEPTION es complementario a esas reglas y reemplaza el
uso de retorno booleano `*OFF` sin contexto de error.
