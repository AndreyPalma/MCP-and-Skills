# Seguridad

## Objetivo

Validar que el fuente RPGLE/SQLRPGLE cumpla los estándares de seguridad empresarial BAC Latam: prevención de SQL injection, validación de entradas, protección de datos sensibles (PCI-DSS), ausencia de credenciales hardcodeadas, y ausencia de código malicioso u ofuscado.

**¿Por qué?** En dominio bancario, SQL injection, buffer overflow y validaciones faltantes permiten ataques que comprometen datos financieros. Una vulnerabilidad que se detecta en producción puede resultar en un incidente regulatorio de $50,000+ y pérdida de confianza.

---

## Reglas — Prevención de SQL Injection

- **Siempre** usar host variables (`:variable`) en SQL embebido. El engine SQL NUNCA interpreta host variables como código.
- **Siempre** validar entradas de usuario ANTES de usarlas en SQL (largo, tipo, rango).
- **Siempre** sanitizar caracteres peligrosos: `'`, `"`, `;`, `--`, `/*`, `*/`.
- **Siempre** detectar patrones de ataque en entradas: `UNION`, `DROP`, `DELETE`, `INSERT`, `UPDATE`, `EXEC`.
- **Nunca** concatenar inputs directamente en strings SQL.
- **Nunca** usar `EXECUTE IMMEDIATE` con datos de usuario sin sanitización.

```rpgle
// ❌ PELIGROSO — Concatenación directa = SQL injection
sqlQuery = 'SELECT * FROM CLIENTES WHERE NOMBRE = ''' + nombreBuscado + '''';
exec sql execute immediate :sqlQuery;

// ✅ SEGURO — Host variables (parametrizado)
exec sql SELECT CLIENTE_ID, NOMBRE_CLIENTE
  INTO :clienteId, :nombreCliente
  FROM CLIENTES WHERE NOMBRE = :nombreBuscado;
```

---

## Reglas — Validación de Entradas por Tipo

- **Siempre** validar campos según tipo específico:
  - `NUMERIC`: solo dígitos `0-9`, `.`, `-`.
  - `ALPHA`: solo letras y espacios.
  - `EMAIL`: debe contener `@` y `.`.
- **Siempre** verificar longitud máxima antes de asignar a variable.
- **Siempre** registrar intentos de inyección como evidencia de ataque.
- **Nunca** confiar en datos provenientes de entrada de usuario sin validar.

---

## Reglas — Sanitización de Caracteres SQL

- **Siempre** escapar comillas simples (`'` → `''`) antes de usar en contextos SQL dinámico.
- **Siempre** remover punto y coma (`;`), comentarios SQL (`--`, `/*`, `*/`).
- **Siempre** usar función auxiliar dedicada de sanitización (no inline ad-hoc).

---

## Reglas — PCI-DSS y Datos Sensibles

- **Siempre** enmascarar tarjetas de crédito inmediatamente: mostrar solo últimos 4 dígitos (`**** **** **** 1234`).
- **Siempre** usar hash SHA-256 (con salt empresarial) para comparaciones de tarjetas — nunca almacenar tarjeta completa.
- **Siempre** usar encriptación AES-256 para datos sensibles almacenados en BD.
- **Siempre** generar IV (vector de inicialización) aleatorio para cada encriptación.
- **Siempre** limpiar variables sensibles de memoria después de uso (`tarjeta = *blanks`).
- **Nunca** almacenar números de tarjeta completos en base de datos.
- **Nunca** loguear datos de tarjeta — solo el hash o últimos 4 dígitos.

---

## Reglas — Credenciales y Secrets

- **Siempre** detectar variables con nombres sospechosos: `password`, `apiKey`, `token`, `secret`.
- **Siempre** reportar credenciales hardcodeadas como issue CRÍTICO.
- **Siempre** recomendar mover a configuración externa o vault.
- **Nunca** revelar el valor de credenciales hardcodeadas en el reporte — solo reportar `"Password hardcodeado detectado - CRÍTICO"`.

---

## Reglas — Detección de Código Malicioso

- **Siempre** buscar constantes fragmentadas que reconstruyen credenciales o paths del sistema:
  ```rpgle
  // ❌ SOSPECHOSO — credencial oculta en constantes fragmentadas
  dcl-c P1 const('U1'); dcl-c P2 const('S2'); dcl-c P3 const('E3');
  credencial = P1 + P2 + P3; // Reconstruye 'USER'
  ```
- **Siempre** buscar backdoors temporales (activación por fecha/hora específica).
- **Siempre** buscar lógica invertida confusa (doble negación) que oculta bypasses de autenticación.
- **Siempre** buscar ofuscación matemática (operaciones aritméticas que producen IDs o credenciales).
- **Siempre** buscar conversiones ASCII sospechosas que reconstruyen strings.
- **Nunca** pasar por alto patrones de acceso incondicional a hora/fecha específica.

---

## Reglas — Privacidad en Reportes

- **Nunca** revelar en reportes de revisión: nombres de BD de producción reales, credenciales, información de clientes reales (nombres, cuentas, tarjetas), IPs de servidores, URLs de producción, nombres de usuarios del sistema.
- **Siempre** se puede mencionar: nombres de tablas genéricas, lógica de negocio general, patrones arquitecturales, tipos de validaciones, nombres de programas/módulos (sin paths completos).
- **Siempre** que se detecte dato sensible en código, reportar su existencia sin mostrar el valor: `"Credencial hardcodeada en línea 45 — mover a vault"`.

---

## Reglas — Control de Acceso

- **Siempre** verificar permisos antes de operaciones críticas (updates, deletes).
- **Siempre** validar autorización de usuario para la operación solicitada.
- **Siempre** que mensajes de error no revelen estructura interna de BD.

---

## Reglas — Timing Attacks

- **Siempre** reportar como CRÍTICO: comparación directa de passwords/PINs (`IF password = storedPassword`). La comparación byte-a-byte revela información por tiempo de ejecución variable.
- **Siempre** exigir comparación de tiempo constante o hash con salt.
- **Nunca** comparar credenciales carácter por carácter — un atacante puede deducir el password midiendo diferencias de tiempo.

```rpgle
// ❌ CRÍTICO — Timing attack: tiempo variable revela información
IF password = storedPassword;

// ✅ SEGURO — Hash con salt, comparación de tiempo fijo
hashedInput = %HASH(password + salt);
IF hashedInput = storedHash;
```

---

## Reglas — Valores Hexadecimales Sospechosos

- **Siempre** reportar como CRÍTICO: literales hex (`X'...'`) sin explicación en comentario. Ocultan credenciales en formato EBCDIC no legible.
- **Nunca** pasar por alto hex en contextos de autenticación o tokens.

```rpgle
// ❌ CRÍTICO — 'PASS' oculto en hexadecimal
password = X'50415353';
// ❌ CRÍTICO — 'ABC' en EBCDIC hex
token = X'C1C2C3';
```

---

## Reglas — Nombres Sospechosos en Contexto Crítico

- **Siempre** reportar: variables con nombres genéricos (`temp`, `aux`, `x`, `data`, `buffer`, `proc1`, `test`) en módulos de autenticación, cálculo de montos financieros o parsing ISO 8583.
- **Siempre** exigir nombres descriptivos que revelen intención en contextos de seguridad.

```rpgle
// ❌ En módulo de autenticación
DCL-S temp CHAR(100);
// ✅ Nombre descriptivo
DCL-S customerFullName CHAR(100);
```

---

## Reglas — Data Structures Fragmentadas (Overlay)

- **Siempre** reportar como CRÍTICO: overlay que reconstruye nombre de biblioteca/comando al concatenar subcampos de una DS.
- **Nunca** ignorar DS con subcampos cortos concatenados en contexto de llamada a sistema.

```rpgle
// ❌ CRÍTICO — Overlay reconstruye nombre oculto
DCL-DS libName QUALIFIED;
  prefix CHAR(4) INZ('JRCM');
  suffix CHAR(6) INZ('DATPRO');
END-DS;
library = libName.prefix + libName.suffix;  // Oculta JRCMDATPRO
```

---

## Reglas — Criterios de Concatenación Sospechosa

- **Siempre** clasificar concatenaciones de literales (`||`, `+`, `*CAT`) según estos criterios:

| Patrón | Nivel | Razón |
|--------|-------|-------|
| Forma palabra completa (>3 chars/parte) | 🔴 CRÍTICO | Evasión intencional |
| Longitud resultante 6–10 chars | 🔴 CRÍTICO | Formato biblioteca/comando |
| Variable `&LIB*`, `&CMD*`, `&PATH*` | 🔴 CRÍTICO | Uso en sistema |
| Usado en CALL/CHGLIB/SBMRMTCMD | 🔴 CRÍTICO | Ejecución sistema |

- **Nunca** marcar como sospechoso: formateo UI (`'Usuario: ' || nombre`) o conversión (`'Monto: $' + %CHAR(monto)`).

```rpgle
// ❌ CRÍTICO — Oculta QS36F
CHGVAR VAR(&LIB) VALUE('QS' || '36F');
// ❌ CRÍTICO — Oculta DLTLIB
cmd = 'DLT' || 'LIB';
// ✅ Explícito y auditable
DCL-C QS36F_LIB CONST('QS36F');
```

---

## Reglas — Aritmética Sospechosa

- **Siempre** reportar como CRÍTICO: cálculos que producen valores significativos (números de tarjeta, índices, montos ocultos).
- **Nunca** ignorar aritmética que combina partes para formar cuenta/tarjeta.

```rpgle
// ❌ CRÍTICO — Reconstruye número de tarjeta
part1 = 4521; part2 = 1234;
account = part1 * 10000 + part2;  // = 45211234
```

---

## Reglas — Variables STATIC con Datos PCI-DSS

- **Siempre** declarar variables con PANs/PINs como locales (no `STATIC`). Variables STATIC persisten en memoria entre llamadas al procedimiento.
- **Nunca** declarar PANs/PINs como `STATIC` — riesgo de exposición en memoria.
- **Nunca** usar variables globales para datos de tarjeta.

```rpgle
// ❌ CRÍTICO — PAN persiste en memoria entre llamadas
DCL-S gbl_pan CHAR(19) STATIC;

// ✅ Local, no STATIC, con limpieza
DCL-S localPan CHAR(19);
// ... uso ...
CLEAR localPan;
```

---

## Reglas — QCMDEXC con Whitelist (Patrón Completo)

- **Siempre** mantener whitelist de comandos permitidos como constante auditable.
- **Siempre** sanitizar inputs removiendo `;` y caracteres de inyección antes de QCMDEXC.
- **Siempre** verificar comando contra whitelist ANTES de ejecutar.
- **Nunca** pasar `userInput` directamente a QCMDEXC sin sanitización.

```rpgle
// ❌ CRÍTICO — Command injection
cmd = 'DLTF FILE(' + userInput + ')';
CALL QCMDEXC PARM(cmd : %LEN(cmd));

// ✅ Whitelist + sanitización
DCL-C ALLOWED_CMDS CONST('DLTF:CHGAUT:CPYF');
IF %SCAN(cmdType : ALLOWED_CMDS) = 0;
  RETURN *OFF;  // Comando no permitido
ENDIF;
fileName = %SCANRPL(';' : '' : fileName);  // Sanitizar
cmd = 'DLTF FILE(' + fileName + ')';
```

---

## Reglas — Bibliotecas Explícitas (no *LIBL)

- **Siempre** usar biblioteca explícita en accesos a archivos críticos (`PRODLIB/MASTER`).
- **Nunca** usar `*LIBL` para accesos críticos — DEV/QA/PROD tienen diferentes library lists y puede leer datos incorrectos.

```rpgle
// ❌ Acceso ambiguo — ¿qué biblioteca?
CHAIN (key) *LIBL/MASTER;
// ✅ Biblioteca explícita
CHAIN (key) PRODLIB/MASTER;
```

---

## Reglas — Tokenización y Configuración Externa

- **Siempre** validar tokenización sin permitir fallback a valor original (si token falla, rechazar operación).
- **Siempre** aplicar bounds checking en parsing de mensajes ISO 8583 (verificar longitud antes de extraer campos).
- **Siempre** exigir configuración de tokens/endpoints en configuración externa, no hardcoded.
- **Nunca** permitir que un fallo de tokenización exponga el dato original como respaldo.

---

## Criterio de aceptación

- Cero concatenaciones directas de inputs en strings SQL.
- Cero credenciales hardcodeadas en el fuente.
- Cero números de tarjeta almacenados sin enmascarar/encriptar.
- Cero patrones de código malicioso detectados (backdoors, ofuscación, constantes fragmentadas).
- Todas las entradas de usuario tienen validación de tipo y longitud antes de uso en SQL.
- Función de sanitización dedicada presente si se usa SQL dinámico.
- Variables sensibles limpiadas de memoria después de uso.
- Cero comparaciones directas de passwords/PINs (timing attack).
- Cero valores hexadecimales sin comentario explicativo en contextos de seguridad.
- Cero nombres genéricos (`temp`, `aux`, `x`) en contexto de seguridad o financiero.
- Cero data structures con subcampos que reconstruyan valores ocultos via overlay.
- Cero variables `STATIC` conteniendo PANs, PINs o datos de tarjeta.
- Cero usos de QCMDEXC sin whitelist de comandos permitidos.
- Cero accesos a archivos críticos con `*LIBL` en lugar de biblioteca explícita.
- Tokenización sin fallback a valor original en caso de fallo.
