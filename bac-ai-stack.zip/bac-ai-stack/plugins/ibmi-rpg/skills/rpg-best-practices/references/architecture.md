# Arquitectura ILE

## Objetivo

Validar que el fuente RPGLE/SQLRPGLE cumpla los patrones arquitecturales ILE empresariales BAC Latam: especificaciones de control completas, estructura ordenada, modularización adecuada y complejidad ciclomática controlada.

**¿Por qué?** Sin arquitectura ILE correcta, los programas generan conflictos de compilación, dependencias implícitas difíciles de diagnosticar y código imposible de mantener o testear en aislamiento.

---

## Reglas — Especificaciones de Control (ctl-opt)

- **Siempre** incluir `ctl-opt` explícito con todos los parámetros requeridos. El compilador no debe asumir valores por defecto.
- **Siempre** usar `nomain` para service programs. Previene activación de grupos de acciones no intencionales.
- **Siempre** especificar `datfmt(*ISO)`. El formato ISO (YYYYMMDD) es resistente a problemas Y2040 y proporciona ordenamiento natural.
- **Siempre** especificar `timfmt(*ISO)`. Garantiza comparabilidad y ordenamiento temporal consistente.
- **Siempre** declarar `bndDir` empresarial. Acelera compilación y previene conflictos de dependencias implícitas.
- **Siempre** incluir `dftactgrp(*no)` y `actgrp('EMPRESA')`. Compartir activation group causa memory leaks entre jobs.
- **Nunca** dejar ctl-opt incompleto. Causa diferencias entre compilaciones y activation groups inesperados.

```rpgle
// ✅ ctl-opt empresarial completo
ctl-opt nomain debug(*yes) dftactgrp(*no) actgrp('EMPRESA')
        bndDir('EMPRESABND001')
        datfmt(*ISO) timfmt(*ISO);
```

---

## Reglas — Formato de Fuentes

- **Siempre** usar fully free format (`**free` en la primera línea) en todo ítem RPGLE/SQLRPGLE nuevo.
- **Siempre** mantener sangría consistente en todo el archivo (2 o 4 espacios, uniforme).
- **Nunca** colocar comentarios en columnas 1–5 de hojas fijas (H, D, F, P, O). Limpiarlos al modificar líneas que los contengan.
- **Nunca** declarar archivos mediante hoja F (File specification) en SQLRPGLE — todo acceso a archivos debe realizarse vía SQL embebido.

> Para reglas de formato columnar fijo (Fixed Format / Legacy), ver [legacy](legacy.md).

---

## Reglas — Estructura del Código

- **Siempre** ordenar las secciones del fuente en este orden:
  1. Especificaciones de control
  2. Declaración de archivos
  3. Prototipos externos (/include)
  4. Constantes empresariales
  5. Variables globales (mínimas)
  6. Estructuras de datos
  7. Procedimientos exportables
  8. Procedimientos internos
- **Nunca** mezclar declaraciones con lógica de negocio fuera de procedimientos.

---

## Reglas — Modularización

- **Siempre** diseñar procedimientos con responsabilidad única.
- **Siempre** limitar cada procedimiento a máximo 50 líneas ejecutables (objetivo recomendado; 150 líneas es el máximo absoluto antes de refactoring obligatorio).
- **Siempre** preferir reutilización sobre duplicación de código.
- **Siempre** mantener cohesión alta y acoplamiento bajo.
- **Siempre** exportar prototipos (`dcl-pr`) de procedimientos exportados en archivo separado (`.rpgleinc` / TXT). Estructura esperada: `.sqlrpgle` (implementación), `.rpgleinc` (prototipos), `.bnd` (exports).
- **Siempre** marcar como `export` únicamente procedimientos diseñados para ser invocados desde otros programas o módulos — no exponer detalles de implementación.
- **Siempre** declarar `CONST` en parámetros que no se modifican dentro del procedimiento. Permite paso de literales y comunica intención.
- **Siempre** compartir datos entre procedimientos por parámetro explícito, no por variables globales.
- **Siempre** declarar `extproc(*dclcase)` **únicamente en el prototipo** (`dcl-pr`) dentro del (`.rpgleinc` / TXT). **Nunca** declararlo en el `dcl-pi` de la implementación — el `dcl-pi` solo define los parámetros y el tipo de retorno del procedimiento ya nombrado por `dcl-proc`.

```rpgle
// ❌ MAL — extproc en dcl-pi
dcl-proc MiProcedimiento export;
  dcl-pi *n extproc(*dclcase) ind;   // ← INCORRECTO
    pParam  int(10) const;
  end-pi;
  ...
end-proc;

// ✅ BIEN — extproc solo en el dcl-pr del (`.rpgleinc` / TXT)
// Archivo: MIPROGRAH.rpgleinc
dcl-pr MiProcedimiento ind extproc(*dclcase);  // ← extproc va AQUÍ
  pParam  int(10) const;
end-pr;

// Archivo: MIPROGRA.sqlrpgle (implementación)
dcl-proc MiProcedimiento export;
  dcl-pi *n ind;                    // ← SOLO tipo retorno y parámetros
    pParam  int(10) const;
  end-pi;
  ...
end-proc;
```

- **Siempre** consumir directamente procedimientos que retornan indicador en expresiones, sin wrappers intermedios.
- **Siempre** evaluar `*NOPASS` con cuidado: todos los parámetros subsiguientes serán también opcionales. Documentar justificación y valor por defecto.
- **Siempre** omitir `dcl-pi`/`end-pi` si el procedimiento no tiene retorno ni parámetros.
- **Siempre** usar `dcl-pi *n` sin tipo retorno cuando solo se reciben parámetros.
- **Siempre** declarar tipo retorno inline cuando solo se devuelve un valor sin parámetros.
- **Nunca** superar 2000 líneas en un archivo total — requiere advertencia y plan de modularización.
- **Nunca** anidar includes — deben ser planos y directos, sin `/copy` o `/include` a otros includes.
- **Nunca** declarar prototipos (`dcl-pr`) de procedimientos internos en objetos `*PGM`/`*MODULE` — el compilador los resuelve automáticamente.
- **Siempre** que un service program encapsule una funcionalidad específica: 1 service program = 1 responsabilidad.

---

## Reglas — Complejidad Ciclomática (McCabe)

**Fórmula obligatoria:**
```
McCabe = 1 + count(if | elseif | else | when | other | for | dow | dou | monitor | on-error | and | or)
```

| McCabe | Calificación | Acción |
|--------|-------------|--------|
| 1–10   | 🟢 BAJA     | Código mantenible y testeable |
| 11–15  | 🟡 MEDIA    | Monitorear, requiere refactoring |
| 16–20  | 🟠 ALTA     | Refactoring urgente |
| >20    | 🔴 CRÍTICA  | Reescribir completamente |

- **Siempre** calcular McCabe contando ocurrencias exactas, no estimando.
- **Siempre** descomponer procedimientos con McCabe >10 en sub-procedimientos.
- **Nunca** usar interpretación subjetiva ("parece complejo") — solo matemática.

**Reducción:** Modularizar → sub-procedures, guard clauses → early returns, máx 3 niveles de indentación, tablas de decisión → lookup.

```rpgle
// ❌ McCabe ≈ 15 (CRÍTICO) — anidamiento excesivo
dcl-proc procesarTransaccion export;
  if tipoTransaccion = 'PAGO';
    if moneda = 'USD';
      if monto > 1000; ...

// ✅ McCabe = 3 (EXCELENTE) — delegación
dcl-proc procesarTransaccion export;
  if not validarDatosBasicos();
    return *off;
  endif;
  return ejecutarProcesamiento();
end-proc;
```

---

## Reglas — Programas CL e ILE

- **Siempre** crear ítems CL nuevos como tipo **CLLE** (CL ILE), no CLP ni CLPGM.
- **Siempre** asignar grupo de activación explícito en CLLE (`DCLPRCOPT DFTACTGRP(*NO) ACTGRP(...)`) — no usar `DFTACTGRP`. Para CLLEs desde CMC500, usar `*DEFER` en `BNDDIR`.
- **Siempre** ejecutar service programs con `ACTGRP(*CALLER)`, salvo que requieran memoria aislada.
- **Siempre** en programas ILE concurrentes, **reinicializar TODAS las variables** al inicio de cada invocación con `clear`. Las variables retienen valores entre llamadas y producen contaminación cruzada si no se reinicializan.

```rpgle
// ✅ Reinicialización obligatoria en ILE concurrente
dcl-proc MiPrograma_procesarPeticion;
  dcl-pi *n;
    pInput char(100) const;
  end-pi;

  clear wsCustomerId;
  clear wsCustomerName;
  clear dsResult;
  // Lógica con estado limpio
end-proc;
```

---

## Reglas — Conversión de Fechas

- **Siempre** convertir fechas con año de 2 dígitos usando **SRVPGM UTLS400** o programas **UTLSP4xx**. No reimplementar la lógica de ventana de siglo.

---

## Reglas — Limpieza de Código

- **Siempre** eliminar líneas obsoletas, no comentarlas — el historial lo gestiona el control de versiones.
- **Siempre** eliminar variables, DS, constantes, subrutinas y procedimientos no exportables sin utilizar. El código muerto dificulta la navegación y oculta problemas reales.

---

## Reglas — Documentación Inline

- **Siempre** documentar cada procedimiento exportable con header: propósito, parámetros, retorno, autor, fecha, SQL objects accedidos.
- **Siempre** documentar SQL complejo con: query description, índice utilizado, performance esperada.
- **Siempre** escribir comentarios en español que capturen intención de negocio (no se deduce del código).
- **Nunca** dejar procedimientos exportables sin header de documentación.

---

## Reglas — Separación de Responsabilidades

- **Siempre** aplicar separación DAO/Service/Controller. Un cambio en estructura de datos no debe afectar lógica de negocio.
- **Siempre** documentar exports en binding source con STRPGMEXP y SIGNATURE.
- **Siempre** documentar proceso de compilación (CRTSQLRPGI/CRTRPGMOD + CRTSRVPGM) en header del fuente.
- **Nunca** concentrar >3 funcionalidades distintas en un mismo módulo.

```rpgle
//*-------------------------------------------------------------------*
//* BINDING SOURCE (MODULE.BND):                                      *
//* STRPGMEXP PGMLVL(*CUR) SIGNATURE(EMPRESA_CLIENTES_V1_0)          *
//*   EXPORT SYMBOL(EMPRESA_CLIENTES_obtenerDatos)                    *
//* ENDPGMEXP                                                         *
//*-------------------------------------------------------------------*

---

## Lineamientos Corporativos Adicionales

### Prohibición de BEANS (Simulación OOP con handlers y punteros)

**❌ PROHIBIDO** el patrón BEANS: simular programación orientada a objetos en RPG
mediante `handler_dfn`, estructuras `object` envolventes, punteros `based()` y
constructores tipo `OBJBAS_new`.

Esta restricción aplica a **todas las capas**: Controlador, Lógica de Negocio y Respuesta.

**Lo que identifica un BEAN prohibido:**
- Tipo `like(XyzType)` donde `XyzType` es un `handler_dfn` / puntero de objeto.
- Estructura `object` que envuelve los datos en `.attr` con indirección de puntero.
- Constructor `OBJBAS_new` o equivalente para inicializar "instancias".
- Acceso indirecto: `bitacoraObject.attr.CAMPO = valor` en lugar de `ds.CAMPO = valor`.

```rpgle
// ❌ Prohibido — simulación OOP con handler y objeto envolvente
dcl-proc Bitacora_setNOMJOB export;
    dcl-pi *n;
        pBitacora like(BitacoraType) const;   // handler / puntero de objeto
        pNOMJOB   char(10) const;
    end-pi;
    dcl-ds bitacoraObject likeds(object) based(pBitacora);  // wrapper con based()
    bitacoraObject.attr.NOMJOB = pNOMJOB;   // acceso indirecto a través de .attr
end-proc;
```

**✅ PERMITIDO — setters/getters sobre DS plana (patrón estándar de bitácoras)**

Los setters y getters que operan directamente sobre una DS pasada por referencia
(`likeds`) son el patrón correcto para módulos de bitácora y DAO. No hay indirección
de punteros, no hay wrapper `object`, no hay simulación de estado mutable.

```rpgle
// ✅ Correcto — setter sobre DS plana pasada por referencia
dcl-proc Bitacora_setNOMJOB export;
    dcl-pi *n;
        pBitacora likeds(Bitacora_ds);   // DS plana, sin puntero ni wrapper
        pNOMJOB   char(10) const;
    end-pi;
    pBitacora.NOMJOB = pNOMJOB;         // asignación directa
end-proc;

// ✅ Correcto — consulta completa con propósito de negocio (Repository Pattern)
dcl-proc ObtenerDatosCliente export;
  dcl-pi *n ind;
    pClienteId char(10)                  const;
    psCliente  likeDs(dsTemplateCliente);
  end-pi;

  exec sql
    SELECT CLID, CLNOMBRE, CLESTADO, CLLIMITE
      INTO :psCliente
      FROM CLIENTES
     WHERE CLID = :pClienteId;

  if SQLSTATE <> '00000';
    CEXCEPTION_throwNewException(ERROR_CLIENTE_NO_ENCONTRADO : 'BMSGFILUTL');
    return *off;
  endIf;

  return *on;
end-proc;
```

---

## Reglas — Patrones Empresariales de Referencia

- **Siempre** considerar estos patrones para organización:
  - **DAO Pattern** para módulos de acceso a datos (bitácoras, tablas maestras): DS plana + CRUD + setters/getters de asignación directa.
  - **Repository Pattern** para consultas con propósito de negocio (encapsulan queries completas, no acceso campo a campo).
  - **Factory Pattern** para creación de objetos.
  - **Strategy Pattern** para algoritmos variables.
- **Nota:** El patrón DAO con DS plana y setters/getters directos **está permitido**. Lo prohibido es la simulación OOP con `handler_dfn`, `object` wrapper y `based()` — ver sección "Prohibición de BEANS" arriba.

---

## Reglas — Detección de Formato (Full Free vs Fixed)

La tabla maestra de detección por extensión/indicador y la clasificación de formatos (Full Free, Fixed, Mixto) están definidas en **SKILL.md § Paso 1 — Detectar formato y lenguaje**. No duplicar aquí.

- **Siempre** aplicar criterios modernos estrictos a **Full Free**: ctl-opt completo, camelCase, full free obligatorio.
- **Siempre** aplicar criterios legacy adaptados a **Fixed Format**: priorizar funcionalidad, seguridad, mantenibilidad.
- **Nunca** penalizar formato antiguo en código legacy — es fixed por diseño.

> Para el catálogo completo de reglas de Fixed Format, ver [legacy](legacy.md).

---

## Reglas — Código Nuevo vs Legacy

- **Siempre** exigir procedures y service programs en código nuevo — no subrutinas. El formato full free (`**Free`) es obligatorio según la sección **Formato de Fuentes**.
- **Nunca** permitir subrutinas (`BEGSR`/`ENDSR`) en código nuevo.
- **Siempre** evaluar código legacy (Fixed Format) por: lógica, seguridad, mantenibilidad.
- **Siempre** sugerir mejoras incrementales viables en legacy sin penalizar formato.

> Para reglas detalladas de mantenimiento legacy, ver [legacy](legacy.md).

---

## Reglas — Diseño y Scope de Variables

- **Siempre** reportar código duplicado con lógica de negocio como issue de diseño.
- **Siempre** reportar variables con scope innecesariamente amplio (globales usadas como si fueran locales).
- **Siempre** reportar lógica no testeable sin justificación documentada.
- **Siempre** evaluar que tests cubran paths críticos (no solo happy path).

---

## Reglas — Edge Cases de Análisis

- **Siempre** reportar "No hay código analizable" si archivo está vacío.
- **Siempre** aplicar todas las metodologías a código mixto (RPGLE + SQL + CL).
- **Nunca** penalizar caracteres válidos en IBM i (`@`, `#`, `$`, `€`) en nombres de objetos.
- **Siempre** que se detecte código generado automáticamente (comentario "Generated by X"), aplicar estándares reducidos.

---

## Criterio de aceptación

- Cero procedimientos exportables sin header de documentación.
- Cero bloques de código comentado (dead code) mayores a 5 líneas.
- Cero fuentes sin `ctl-opt` completo (nomain, datfmt, timfmt, bndDir, actgrp).
- Cero procedimientos con McCabe >10 sin plan de refactoring documentado.
- Cero procedimientos exportables sin documentación de compilación y binding.
- El código sigue el orden de secciones establecido.
- Cada service program tiene responsabilidad única y exports documentados.
- Formato RPGLE correctamente identificado y documentado (Full Free vs Fixed).
- Cero subrutinas (`BEGSR`/`ENDSR`) en código nuevo.
- Cero variables con scope innecesariamente amplio sin justificación.
- Tests cubren paths críticos, no solo happy path.
- Cero fuentes SQLRPGLE nuevos con hoja F (File specification).
- Cero comentarios en columnas 1–5 de hojas fijas.
- Sangría uniforme en todo el archivo.
- Prototipos exportados en archivo separado (.rpgleinc/TXT).
- Cero prototipos de procedimientos internos en *PGM/*MODULE.
- Cero includes anidados.
- Parámetros no modificados declarados como CONST.
- Datos compartidos entre procedimientos por parámetro, no por global.
- `extproc(*dclcase)` presente en prototipos de procedimientos exportados con casing mixto.
- Cero CL nuevos como CLP — todos como CLLE con grupo de activación explícito.
- Service programs en ACTGRP(*CALLER) salvo excepción documentada.
- Variables reinicializadas al inicio de cada invocación en ILE concurrente.
- Fechas con año 2 dígitos convertidas vía UTLS400/UTLSP4xx.
- Cero elementos sin utilizar (variables, DS, constantes, subrutinas, procedimientos no exportables).
