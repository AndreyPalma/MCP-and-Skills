# Nomenclatura y Tipos de Datos

## Objetivo

Validar que todos los identificadores del fuente RPGLE cumplan las convenciones de nomenclatura empresarial BAC Latam, y que las declaraciones de variables y tipos de datos sean correctas, seguras e inicializadas.

**¿Por qué?** Nomenclatura inconsistente hace el código imposible de buscar/reemplazar con seguridad. Variables sin inicializar contienen valores aleatorios que causan comportamientos impredecibles. Tipos incorrectos causan overflow silencioso, truncamiento o conversiones lentas — errores que corrompen datos financieros.

---

## Reglas — Nomenclatura

- **Siempre** usar camelCase para variables locales y de estructura. Mejora legibilidad y búsqueda en IDE.
- **Siempre** usar UPPER_CASE con separador `_` para constantes nombradas. Facilita encontrar y modificar valores.
- **Siempre** prefixar procedimientos exportables con prefijo de módulo empresarial (ej. `MODEMPRESA_calcularIntereses`).
- **Siempre** usar nombres descriptivos que revelan intención: `tasaInteresAnual` en lugar de `ti`.
- **Nunca** usar nombres de 1–2 caracteres salvo índices de loop (i, j, k).
- **Nunca** usar abreviaciones ambiguas (`MOD_CalcInt` → ¿módulo? ¿CalcInt = calcular integer?).
- **Nunca** mezclar estilos de nomenclatura dentro del mismo fuente (consistencia interna obligatoria).
- **Siempre** que el código esté en inglés o español, mantener consistencia interna en un solo idioma.

> Para convenciones de nomenclatura adaptadas a Fixed Format (limitación de 10 caracteres, prefijos `ws`, `p`, `ds`, `sr`, `kl`, `ct`), ver [legacy](legacy.md).

```rpgle
// ❌ Nomenclatura confusa
dcl-proc MOD_CalcInt export;
  dcl-s ti packed(5:4) inz;
  dcl-c DEFVAL const(0.0525);

// ✅ Nomenclatura clara y consistente
dcl-proc MODEMPRESA_calcularIntereses export;
  dcl-s tasaInteresAnual packed(5:4) inz(0);
  dcl-c TASA_INTERES_PREDETERMINADA const(0.0525);
```

---

## Reglas — Inicialización de Variables

- **Siempre** declarar toda variable con `inz` y valor inicial explícito. Variables sin INZ causan garbage values.
- **Siempre** inicializar punteros a `*null` o `%nullind`.
- **Nunca** declarar `dcl-s` sin `inz`.

---

## Reglas — Tipos de Datos y Precisión

- **Siempre** usar `packed` con precisión suficiente para cálculos financieros (mín. `packed(15:2)` para montos).
- **Siempre** usar `varchar` con tamaño suficiente para campos de texto variable.
- **Siempre** validar rangos ANTES de asignación para prevenir overflow silencioso.
- **Siempre** usar BIFs explícitos para conversiones entre tipos (`%dec`, `%char`, `%int`).
- **Nunca** confiar en conversiones implícitas entre tipos diferentes (packed→zoned, etc.).
- **Nunca** usar `packed(7:2)` para montos que puedan superar 99,999.99 — overflow silencioso corrompe datos.

```rpgle
// ❌ Overflow silencioso — soporta máx 99999.99
dcl-s montoCalculado packed(7:2) inz;
montoCalculado = 123456.789; // Truncado silenciosamente

// ✅ Rango correcto y verificación
dcl-s montoCalculado packed(15:2) inz(0);
if valorEntrada <= 99999999999999.99;
  montoCalculado = %dec(valorEntrada : 15 : 2);
else;
  logError('Overflow detectado: ' + %char(valorEntrada));
  return *off;
endif;
```

---

## Reglas — Manejo Seguro de Punteros

- **Siempre** inicializar punteros a `*null`: `dcl-s miPuntero pointer inz(*null)`.
- **Siempre** validar puntero `<> *null` ANTES de uso.
- **Siempre** verificar resultado de `%alloc()` antes de usar.
- **Siempre** liberar con `dealloc` + asignar `*null` para evitar dangling pointers.
- **Nunca** retornar `%addr()` de una variable local (undefined behavior — la variable muere al salir del procedimiento).
- **Nunca** usar un puntero sin validar nulidad.
- **Nunca** hacer `dealloc` sin posterior asignación a `*null`.

```rpgle
// ✅ Ciclo seguro de puntero
dcl-s datos pointer inz(*null);
datos = %alloc(1000000);
if datos = *null;
  logError('Error allocación');
  return *off;
endif;

monitor;
  // ... usar datos ...
on-error;
  logError('Error procesando');
endmon;

if datos <> *null;
  dealloc datos;
  datos = *null;
endif;
```

---

> **Caracteres IBM i y código generado:** Estas reglas están definidas en [architecture](architecture.md) § Edge Cases de Análisis.

---

## Criterio de aceptación

- Cero variables sin `inz` en declaraciones.
- Cero conversiones implícitas entre tipos diferentes sin BIF explícito.
- Cero punteros sin inicialización a `*null`.
- Cero punteros usados sin validación previa de nulidad.
- Nomenclatura consistente en 100% del fuente (camelCase variables, UPPER_CASE constantes, prefijo módulo en exports).
- Cero `packed` con precisión insuficiente para el dominio de datos que maneja.

---

## Lineamientos Corporativos Adicionales

### Prefijos de parámetros

Los parámetros de procedimientos siguen una convención de prefijo que comunica su intención
de modificación. Es obligatorio para todos los procedimientos exportables.

| Prefijo | Uso | Ejemplo |
|---|---|---|
| `p` | Parámetro de solo lectura — debe llevar `const` | `pCodigoCliente char(10) const` |
| `ps` | Parámetro modificable — puede ser alterado por el procedimiento | `psCliente likeDs(dsTemplate)` |

```rpgle
// ✅ Correcto — prefijos que comunican intención
dcl-proc ActualizarCliente export;
  dcl-pi *n ind;
    pClienteId  char(10)                     const;  // p = solo lectura
    psCliente   likeDs(dsTemplateCliente);            // ps = modificable
  end-pi;
  ...
end-proc;

// ❌ Incorrecto — sin prefijos, intención opaca
dcl-proc ActualizarCliente export;
  dcl-pi *n ind;
    clienteId  char(10)                     const;
    cliente    likeDs(dsTemplateCliente);
  end-pi;
```

---

### Prefijo `ds` para data structures

Todas las data structures declaradas con `dcl-ds` deben comenzar con el prefijo `ds`
(minúscula) en formato camelCase.

```rpgle
// ✅ Correcto
dcl-ds dsEstructuraTrabajo qualified;
  campo1 char(10)     inz(*blanks);
  campo2 packed(15:2) inz(0);
end-ds;

dcl-s miVariable likeDs(dsEstructuraTrabajo) inz(*likeds);

// ❌ Incorrecto — sin prefijo ds
dcl-ds estructuraTrabajo qualified;
  ...
end-ds;
```

---

### No declarar DS directamente en la interfaz de un procedimiento

Al pasar data structures como parámetros, usar `likeDs` con referencia a un template —
no declarar la estructura inline dentro del `dcl-pi`.

```rpgle
// ✅ Correcto — likeDs como referencia a template
dcl-proc ProcesarCliente export;
  dcl-pi *n ind;
    psCliente likeDs(dsTemplateCliente);
  end-pi;
  ...
end-proc;

// ❌ Prohibido — DS declarada inline en la interfaz
dcl-proc ProcesarCliente export;
  dcl-pi *n ind;
    dsCliente ds qualified;
      nombre char(50);
      saldo  packed(15:2);
    end-ds;
  end-pi;
  ...
end-proc;
```

---

### `clear` obligatorio en loops antes de reasignar variables

En todo loop que reutilice variables o data structures, ejecutar `clear` antes de
asignarles un nuevo valor. Las variables en RPGLE retienen el valor de la iteración
anterior — sin `clear`, se mezclan datos entre iteraciones con resultados impredecibles.

```rpgle
// ✅ Correcto — clear antes de reutilizar en cada iteración
dow sqlcod = 0;
  clear dsRegistro;          // limpia residuos de la iteración anterior
  fetch next from Cursor into :dsRegistro;
  ProcesarRegistro(dsRegistro);
enddo;

// ❌ Incorrecto — sin clear, datos sucios de iteración anterior
dow sqlcod = 0;
  fetch next from Cursor into :dsRegistro;   // puede mezclar campos
  ProcesarRegistro(dsRegistro);
enddo;
```

> Esta regla aplica también a procedimientos invocados repetidamente desde un loop:
> inicializar todas las variables locales al inicio de cada invocación.
