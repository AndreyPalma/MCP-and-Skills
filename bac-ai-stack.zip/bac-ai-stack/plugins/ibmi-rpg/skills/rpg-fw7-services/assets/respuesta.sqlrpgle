**free

ctl-opt nomain bnddir('BNDDIR que utilice');
//----------------------------------------------------------------------------
//@name.....: Nombre fuente
//@objective: Objetivo del fuente
//@version..: Numero de pase
//@team.....: Nombre Equipo
//@author...: Autor
//@since....: Fecha
//@comments.: Resumen del contenido del fuente
//@----------------------------------------------------------------------------

/INCLUDE ccgitsrc/qsrctxt,usec
/INCLUDE CSYSTSRC/QSRCTXT,PGMSTSH
/INCLUDE CMQASRC/QSRCTXT,CFWUTIL7
/INCLUDE CAJLSRC/QSRCTXT,YAJLH
/INCLUDE CSYSTSRC/QSRCTXT,CEXCEPTION

// Importaciones necesarias de lógica de negocio o módulos

//-------------------------------------------
//  VARIABLES GLOBALES
//-------------------------------------------

// Declaración de variables globales si son necesarias

//-------------------------------------------------------------------------
//@name.....: Nombre procedimiento
//@objective: Construye la respuesta en formato JSON
//            Realiza el manejo de errores
//@version..: Numero de pase
//@team.....: Nombre Equipo
//@author...: Autor
//@since....: Fecha
//@paramin..: Parámetros de entrada si los hay
//@paramout.: *on: Exitoso
//            *off: Error
//-------------------------------------------------------------------------
Dcl-Proc Nombre_procedimiento export;
  Dcl-Pi *n ind;
    // Parámetros de entrada
  End-Pi;

  // Variables si se necesitan

  Monitor;

    // Llamados a la lógica de negocio o módulos necesarios
    Nombre_fuente_cargaNombre_bitacora(serviceParms);
    successResponse = *on;

  on-error;
    CEXCEPTION_catchException();
    Nombre_bitacora_setCODERR(@Nombre_bitacora:CEXCEPTION_getMessageId());
    Nombre_bitacora_setMSGERR(@Nombre_bitacora:%trim(CEXCEPTION_getMessageText()));
    CFWUTIL7_addError(CEXCEPTION_getMessageId():%trim(CEXCEPTION_getMessageText()));
    Nombre_fuente_insertNombre_bitacora();
    successResponse = *off;
  endmon;
  return successResponse;
End-Proc;

//-------------------------------------------------------------------------
//@name.....: Nombre_fuente_cargaNombre_bitacora
//@objective: Carga la información inicial en la bitácora del servicio
//@version..: Numero de pase
//@team.....: Nombre Equipo
//@author...: Autor
//@since....: Fecha
//@paramin..: i_pServiceParms: Parámetros de entrada del servicio
//@paramout.: N/A
//-------------------------------------------------------------------------
Dcl-Proc Nombre_fuente_cargaNombre_bitacora;
  Dcl-Pi *n;
    @i_pServiceParms LikeDs(serviceParmsT) Const;
  End-Pi;

  Dcl-S sysName Char(8) inz;

  clear @Nombre_bitacora;

  exec sql VALUES CURRENT_SERVER INTO :sysName;

  Nombre_bitacora_new(@Nombre_bitacora);
  Nombre_bitacora_setFECREQ(@Nombre_bitacora:%Timestamp);
  Nombre_bitacora_setCODAPL(@Nombre_bitacora:CFWUTIL7_GETSERVICECODE());
  Nombre_bitacora_setNOMJOB(@Nombre_bitacora:PgmJob);
  Nombre_bitacora_setUSRJOB(@Nombre_bitacora:PgmUsr);
  Nombre_bitacora_setNUMJOB(@Nombre_bitacora:PgmJobNbr);
  Nombre_bitacora_setNOMPRG(@Nombre_bitacora:PgmNam);
  Nombre_bitacora_setCANREQ(@Nombre_bitacora:%Trim(CFWUTIL7_GETORIGINCHANNEL()));
  Nombre_bitacora_setNOMSVD(@Nombre_bitacora:sysName);
  Nombre_bitacora_setUUID(@Nombre_bitacora:CFWUTIL7_GETUUIDVALUE());
  // Datos del Request

End-Proc;

//-------------------------------------------------------------------------
//@name.....: Nombre_fuente_insertNombre_bitacora
//@objective: Inserta la bitácora del servicio
//@version..: Numero de pase
//@team.....: Nombre Equipo
//@author...: Autor
//@since....: Fecha
//@paramin..: N/A
//@paramout.: N/A
//-------------------------------------------------------------------------
Dcl-Proc Nombre_fuente_insertNombre_bitacora;
  Dcl-Pi *n;
  End-Pi;

  Nombre_bitacora_setFECRPT(@Nombre_bitacora:%Timestamp);
  Nombre_bitacora_insert(@Nombre_bitacora);

End-Proc;
