**free
// Módulo de acceso a datos para la bitácora: Nombre bitácora
ctl-opt nomain bnddir('CEXCEPBNDD');

/INCLUDE CSYSTSRC/QSRCTXT,CEXCEPSQLH
// /INCLUDE Ruta de archivo txt de la bitacora

// Atributos privados de la DS de bitácora
dcl-ds Nombre_bitacora_ds qualified template;
    IDNREQ int(10) inz;
    FECREQ timestamp inz;
    CODAPL char(10) inz;
    NOMJOB char(10) inz;
    USRJOB char(10) inz;
    NUMJOB packed(6) inz;
    NOMPRG char(10) inz;
    CANREQ char(30) inz;
    NOMSVD char(10) inz;
    UUID char(100) inz;
    FECRPT timestamp inz;
    CODERR char(7) inz;
    MSGERR char(132) inz;
    MCGCOD char(2) inz;
    // Agregar aquí los parámetros específicos del request del servicio
    // Ejemplo:
    // campoParm1 char(10) inz;
    // campoParm2 zoned(9:0) inz;
    // campoParm3 date inz;
end-ds;

// Constructor — limpia la DS
dcl-proc Nombre_bitacora_new export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
    end-pi;

    exec sql set option datfmt=*iso,datsep='-',
                      timfmt=*iso,timsep='.';
    clear pNombre_bitacora;
    return;
end-proc;

// Obtener registro por ID
dcl-proc Nombre_bitacora_getRecord export;
    dcl-pi *n ind;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pIDNREQ int(10) const;
    end-pi;

    dcl-s exists ind inz(*off);

    clear pNombre_bitacora;

    exec sql
    SELECT
      IDNREQ,
      FECREQ,
      CODAPL,
      NOMJOB,
      USRJOB,
      NUMJOB,
      NOMPRG,
      CANREQ,
      NOMSVD,
      UUID,
      FECRPT,
      CODERR,
      MSGERR,
      MCGCOD
      -- Agregar campos específicos del servicio aquí
    INTO :pNombre_bitacora
    FROM Nombre_bitacora
    WHERE IDNREQ = :pIDNREQ;

    CEXCEPSQL_testStatement(sqlCode:sqlState);

    if sqlCode = 0;
        exists = *on;
    endif;

    return exists;
end-proc;

// Insertar registro
dcl-proc Nombre_bitacora_insert export;
    dcl-pi *n ind;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
    end-pi;

    dcl-s success ind inz(*off);

    exec sql
    INSERT INTO Nombre_bitacora (
      FECREQ,
      CODAPL,
      NOMJOB,
      USRJOB,
      NUMJOB,
      NOMPRG,
      CANREQ,
      NOMSVD,
      UUID,
      FECRPT,
      CODERR,
      MSGERR,
      MCGCOD
      -- Agregar campos específicos del servicio aquí
    )
    VALUES(
      :pNombre_bitacora.FECREQ,
      :pNombre_bitacora.CODAPL,
      :pNombre_bitacora.NOMJOB,
      :pNombre_bitacora.USRJOB,
      :pNombre_bitacora.NUMJOB,
      :pNombre_bitacora.NOMPRG,
      :pNombre_bitacora.CANREQ,
      :pNombre_bitacora.NOMSVD,
      :pNombre_bitacora.UUID,
      :pNombre_bitacora.FECRPT,
      :pNombre_bitacora.CODERR,
      :pNombre_bitacora.MSGERR,
      :pNombre_bitacora.MCGCOD
      -- Agregar valores de campos específicos aquí
    );

    CEXCEPSQL_testStatement(sqlCode:sqlState);

    if sqlCode = 0;
        success = *on;
        exec sql
        VALUES IDENTITY_VAL_LOCAL() INTO :pNombre_bitacora.IDNREQ;
    endif;

    return success;
end-proc;

// Actualizar registro
dcl-proc Nombre_bitacora_update export;
    dcl-pi *n ind;
        pNombre_bitacora likeds(Nombre_bitacora_ds) const;
    end-pi;

    dcl-s success ind inz(*off);

    exec sql
    UPDATE Nombre_bitacora
      SET
      FECRPT = :pNombre_bitacora.FECRPT,
      CODERR = :pNombre_bitacora.CODERR,
      MSGERR = :pNombre_bitacora.MSGERR
      -- Agregar campos específicos del servicio aquí
    WHERE
      IDNREQ = :pNombre_bitacora.IDNREQ;

    CEXCEPSQL_testStatement(sqlCode:sqlState);

    if sqlCode = 0;
        success = *on;
    endif;

    return success;
end-proc;

// Eliminar registro
dcl-proc Nombre_bitacora_delete export;
    dcl-pi *n ind;
        pIDNREQ int(10) const;
    end-pi;

    dcl-s success ind inz(*off);

    exec sql
    DELETE FROM Nombre_bitacora
    WHERE IDNREQ = :pIDNREQ;

    CEXCEPSQL_testStatement(sqlCode:sqlState);

    if sqlCode = 0;
        success = *on;
    endif;

    return success;
end-proc;

// ─── Setters ─────────────────────────────────────────────────────────────────

dcl-proc Nombre_bitacora_setIDNREQ export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pIDNREQ int(10) const;
    end-pi;
    pNombre_bitacora.IDNREQ = pIDNREQ;
end-proc;

dcl-proc Nombre_bitacora_setFECREQ export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pFECREQ timestamp const;
    end-pi;
    pNombre_bitacora.FECREQ = pFECREQ;
end-proc;

dcl-proc Nombre_bitacora_setCODAPL export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pCODAPL char(10) const;
    end-pi;
    pNombre_bitacora.CODAPL = pCODAPL;
end-proc;

dcl-proc Nombre_bitacora_setNOMJOB export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pNOMJOB char(10) const;
    end-pi;
    pNombre_bitacora.NOMJOB = pNOMJOB;
end-proc;

dcl-proc Nombre_bitacora_setUSRJOB export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pUSRJOB char(10) const;
    end-pi;
    pNombre_bitacora.USRJOB = pUSRJOB;
end-proc;

dcl-proc Nombre_bitacora_setNUMJOB export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pNUMJOB packed(6) const;
    end-pi;
    pNombre_bitacora.NUMJOB = pNUMJOB;
end-proc;

dcl-proc Nombre_bitacora_setNOMPRG export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pNOMPRG char(10) const;
    end-pi;
    pNombre_bitacora.NOMPRG = pNOMPRG;
end-proc;

dcl-proc Nombre_bitacora_setCANREQ export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pCANREQ char(30) const;
    end-pi;
    pNombre_bitacora.CANREQ = pCANREQ;
end-proc;

dcl-proc Nombre_bitacora_setNOMSVD export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pNOMSVD char(10) const;
    end-pi;
    pNombre_bitacora.NOMSVD = pNOMSVD;
end-proc;

dcl-proc Nombre_bitacora_setUUID export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pUUID char(100) const;
    end-pi;
    pNombre_bitacora.UUID = pUUID;
end-proc;

dcl-proc Nombre_bitacora_setFECRPT export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pFECRPT timestamp const;
    end-pi;
    pNombre_bitacora.FECRPT = pFECRPT;
end-proc;

dcl-proc Nombre_bitacora_setCODERR export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pCODERR char(7) const;
    end-pi;
    pNombre_bitacora.CODERR = pCODERR;
end-proc;

dcl-proc Nombre_bitacora_setMSGERR export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pMSGERR char(132) const;
    end-pi;
    pNombre_bitacora.MSGERR = pMSGERR;
end-proc;

dcl-proc Nombre_bitacora_setMCGCOD export;
    dcl-pi *n;
        pNombre_bitacora likeds(Nombre_bitacora_ds);
        pMCGCOD char(2) const;
    end-pi;
    pNombre_bitacora.MCGCOD = pMCGCOD;
end-proc;

// ─── Setters campos específicos del servicio ─────────────────────────────────
// Agregar un setter por cada campo específico del servicio:
//
// dcl-proc Nombre_bitacora_setCampoParm1 export;
//     dcl-pi *n;
//         pNombre_bitacora likeds(Nombre_bitacora_ds);
//         pCampoParm1 char(10) const;
//     end-pi;
//     pNombre_bitacora.campoParm1 = pCampoParm1;
// end-proc;
