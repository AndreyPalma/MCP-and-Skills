**free

//============================================================================*
// @name.....:  Nombre del fuente                                        
// @objective:  Programa de montaje/desmontaje de servicio FW7 — Core Tarjetas (COM)
// @changes..:  Cambios que se hicieron en la programación               
// @version..:  Numero de pase                                           
// @team.....:  Nombre del equipo                                         
// @author...:  Nombre del autor                                          
// @since....:  Fecha                                                     
//============================================================================*

dcl-pr qCmdExc extpgm('QCMDEXC');
    @i_command char(200) const Options(*varSize);
    @i_commandLength packed(15:5) const;
end-pr;

// Variables, constantes y estructuras de datos globales.
dcl-c INSTALL   const('I');
dcl-c UNINSTALL const('D');
dcl-s command char(500) inz(*blanks);
dcl-s message char(50)  inz(*blanks);

// Prototipo principal.
// Nota: COM no requiere parámetro de país
dcl-pi *n;
    inp_process char(1) const;
end-pi;

// Lógica del programa.
if inp_process = INSTALL;

    // ── MATRÍCULA DE MENSAJES NUEVOS DE ERROR ──────────────────────────────
    command = 'ADDMSGD MSGID(COD0001) MSGF(Biblioteca/ArchivoMensajes) ' +
              'MSG(''Texto del mensaje de error COD0001'')';
    monitor;
        qCmdExc(command:%len(command));
    on-Error;
        message = 'Error al agregar el mensaje COD0001';
        dsply (message);
    endMON;

    // Agregar más mensajes si el servicio los requiere

    // ── MATRÍCULA DEL SERVICIO EN MQA034 ───────────────────────────────────
    exec sql
    INSERT INTO cmqmdat.MQA034
            (CODIGO_OPERACION, NOMBRE_SERVICIO, DESCRIPCION, ALCANCE, ESTADO,
             TIPO_SERVICIO, TIEMPO_EXPIRACION_MENSAJE, PRIORIDAD,
             CONTROLADOR, BIBLIOTECA_CONTROLADOR,
             GUARDA_REQUEST, GUARDA_RESPUESTA,
             RESPONDE_CON_LLAVE, SOLO_REQUEST, FECHA_CREACION)
    VALUES  ('Codigo_servicio', 'Nombre_del_servicio',
             'Descripcion_larga_del_servicio',
             'REGIONAL', '1', 'BASIC', 50, 0,
             'Nombre_controlador_servicio', 'TCOMSRV',
             '1', '1', '1', '0', CURRENT DATE);

    // ── REGISTRO DE BIBLIOTECA EN TCA063 ───────────────────────────────────
    exec sql
    INSERT INTO tccmdatpro.TCA063
            (TCAAPL, TCAOPC, TCASE2, TCABIB, TCAC03)
    VALUES  ('Nombre_job', 'Opcion',
             (SELECT Max(TCASE2) + 10
              FROM tccmdatpro.TCA063
              WHERE TCAAPL = 'Nombre_job'
                AND TCAOPC = 'Opcion'),
             'TCOMSRV',
             'Descripcion del registro en TCA063');

    // ── REGISTRO DE BITÁCORA EN HOUSEKEEPING ───────────────────────────────
    // COM: biblioteca fija TBITDAT (no hay distinción regional)
    exec sql
    INSERT INTO CHSKPDAT.CHSKPA003
           (HSKPLIBT, HSKPTAB, HSKPFRE, HSKPNEXTEX, HSKPMISSTM, HSKPDELSTM)
    VALUES ('TBITDAT', 'Nombre_bitacora', 1, CURRENT DATE, ' ',
            'WHERE DATE(FECREQ) <= (CURRENT_DATE - 1 MONTH) AND CODAPL = ''Codigo_servicio''');

elseif inp_process = UNINSTALL;

    // ── ELIMINA LOS MENSAJES DE ERROR ──────────────────────────────────────
    command = 'RMVMSGD MSGID(COD0001) MSGF(Biblioteca/ArchivoMensajes)';
    monitor;
        qCmdExc(command:%len(command));
    on-Error;
        message = 'Error al remover el mensaje COD0001';
        dsply (message);
    endMON;

    // Eliminar más mensajes si se agregaron en INSTALL

    // ── ELIMINA LA MATRÍCULA DEL SERVICIO ──────────────────────────────────
    exec sql
    DELETE FROM CMQMDAT.MQA034
    WHERE OPCODE = 'Codigo_servicio';

    // ── ELIMINA EL REGISTRO DE BIBLIOTECA EN TCA063 ────────────────────────
    exec sql
    DELETE FROM TCCMDATPRO.TCA063
    WHERE TCAAPL = 'Nombre_job'
      AND TCAOPC = 'Opcion'
      AND TCABIB = 'TCOMSRV';

    // ── ELIMINA EL REGISTRO DE BITÁCORA EN HOUSEKEEPING ────────────────────
    exec sql
    DELETE FROM CHSKPDAT.CHSKPA003
    WHERE HSKPLIBT = 'TBITDAT'
      AND HSKPTAB = 'Nombre_bitacora';

endif;

*inlr = *on;
