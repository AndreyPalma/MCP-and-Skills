**FREE

//_______________________________________________________________________________________
//@name:      Nombre fuente                                                         
//@objective: Controlador servicio Numero del servicio - Nombre del servicio   
//@version..: Numero de pase                                                        
//@author:    Autor                                                                 
//@team.....: Nombre Equipo                                                         
//@since:     Fecha                                                                 
//_______________________________________________________________________________________

ctl-opt nomain bnddir('BNDDIR que utilice');

/INCLUDE CSYSTSRC/QSRCTXT,CEXCEPTION
/INCLUDE CAJLSRC/QSRCTXT,YAJLH
/INCLUDE CMQASRC/QSRCTXT,CFWUTIL7
/INCLUDE Importación de la respuesta del servicio

//_______________________________________________________________________________________
//                                                                                       
//@name: processParms                                                                    
//@objective: Procedimiento principal. Invoca la respuesta del servicio.                 
//@version: Numero de pase                                                          
//@team: Nombre Equipo                                                              
//_______________________________________________________________________________________
dcl-proc processParms export;
    dcl-pi *n ind;
        JSONReqBuffer char(32767);
    end-pi;
    dcl-s status ind inz(*on);
    dcl-ds request likeds(serviceParmsT) inz;
    monitor;
        if %trim(JSONReqBuffer) = *blanks;
            CFWUTIL7_addErrorFromMessageFile('FSC4004':'CMSGFILUTL');
            status = *Off;
        else;
            if loadKeys(JSONReqBuffer:request);
                status = Llamado al procedimiento principal respuesta;
            else;
                status = *off;
            endif;
        endif;
    on-error;
        // Capturar la excepción
        CEXCEPTION_catchException();
        // Verificar si hay un mensaje de excepción
        if %trim(CEXCEPTION_getMessageId()) <> '' and %trim(CEXCEPTION_getMessageText()) <> '';
            CFWUTIL7_addError(CEXCEPTION_getMessageId(): %trim(CEXCEPTION_getMessageText()));
        else;
            // Agregar mensaje de error por defecto si no hay mensaje de excepción
            CFWUTIL7_addErrorFromMessageFile('FSC4003':'CMSGFILUTL');
        endif;
        status = *off;
    endmon;
    return status;
end-proc;

//_______________________________________________________________________________________
//                                                                                       
//@name.....: loadKeys                                                                   
//@objective: Extrae los elementos que estan en la seccion "Keys" del request          
//@paramin..: JSONReqBuffer: Request enviado al servicio                                 
//            request: Estructura DS que almacenara los datos de las "Keys"            
//@paramout.: N/A                                                                        
//_______________________________________________________________________________________
dcl-proc loadKeys;
    dcl-pi *n ind;
        JSONReqBuffer char(32767);
        request likeds(serviceParmsT);
    end-pi;
    dcl-s successGetKeys ind inz(*on);
    dcl-s options char(150) inz;
    monitor;
        options = 'path= requestRoot/message/key ' +
            'case=any allowextra=yes trim=none allowmissing=yes';
        data-into request %data(JSONReqBuffer:options)
            %parser('YAJLINTO': '{ "document_name": "requestRoot" }');
    on-error;
        // Capturar la excepción
        CEXCEPTION_catchException();
        // Verificar si hay un mensaje de excepción
        if %trim(CEXCEPTION_getMessageId()) <> '' and %trim(CEXCEPTION_getMessageText()) <> '';
            CFWUTIL7_addError(CEXCEPTION_getMessageId(): %trim(CEXCEPTION_getMessageText()));
        else;
            // Agregar mensaje de error por defecto si no hay mensaje de excepción
            CFWUTIL7_addErrorFromMessageFile('FSC4003':'CMSGFILUTL');
        endif;
        successGetKeys = *off;
    endmon;
    return successGetKeys;
end-proc;
