--==============================================================================
-- Nombre de la Vista: Nombre_bitacora (BITAR + código del servicio)
-- Descripción:
--     Vista de bitácora del servicio Código_servicio
-- Objetivo:
--     Tener trazabilidad del uso del servicio Código_servicio
-- Tipo de Tabla:
--     Bitácora
-- Origen de los datos:
--     Se ingresan por el llamado del servicio a través de canales digitales
-- Permanencia de los datos:
--     3 Meses (controlado por HouseKeeping en CHSKPDAT.CHSKPA003)
-- Uso de los datos:
--     Rastrear el flujo completo de cada petición procesada
-- Restricciones o consideraciones:
--     Solo escritura — no leer de la bitácora desde los servicios
--==============================================================================
-- Para BANCO: usar FROM BITAREG  (biblioteca BCOCYFILES o BPACYFILES)
-- Para TARJETAS: usar FROM BITAREGTAR (biblioteca TBITDAT)
--==============================================================================

CREATE VIEW Nombre_bitacora (
-- CAMPOS ESTÁNDAR
IDNREQ,
FECREQ,
CODAPL,
NOMJOB,
USRJOB,
NUMJOB,
NOMPRG,
CANREQ,
NOMSVD,
UUIDEN,
FECRPT,
CODERR,
MSGERR,
-- CAMPOS ESPECÍFICOS DEL SERVICIO
MCGCOD
-- Agregar aquí los campos específicos del servicio
) AS SELECT
  ID_PETICION,
  TIMESTAMP_PETICION,
  CODIGO_APLICACION,
  NOMBRE_TRABAJO,
  USUARIO_TRABAJO,
  NUMERO_TRABAJO,
  PROGRAMA_INVOCADO,
  CANAL_CONSUMIDOR,
  SERVIDOR,
  ID_UNIVERSAL,
  TIMESTAMP_RESPUESTA,
  CODIGO_ERROR,
  MENSAJE_ERROR,
-- CAMPOS ESPECÍFICOS DEL SERVICIO
  DAT2_1
  -- Mapear aquí los campos específicos del servicio (DAT2_1, DAT2_2, etc.)
FROM BITAREG
-- Para TARJETAS reemplazar por: FROM BITAREGTAR
WHERE CODIGO_APLICACION = 'Codigo_servicio'
RCDFMT BITRCodigo_servicio;

COMMENT ON TABLE Nombre_bitacora IS 'VISTA BITACORA SERVICIO Codigo_servicio';

LABEL ON TABLE Nombre_bitacora IS 'VISTA BITACORA SERVICIO Codigo_servicio';

COMMENT ON COLUMN Nombre_bitacora (
  MCGCOD IS 'MCG CODE'
  -- Agregar comentarios de campos específicos aquí
);

LABEL ON COLUMN Nombre_bitacora (
  MCGCOD IS 'MCG CODE'
  -- Agregar labels de campos específicos aquí
);

LABEL ON COLUMN Nombre_bitacora (
  MCGCOD TEXT IS 'MCG CODE'
  -- Agregar labels TEXT de campos específicos aquí
);
