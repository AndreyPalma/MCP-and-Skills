---
name: rpg-fw7-services
description: >-
  Esta skill debe usarse cuando el usuario necesite crear, diseñar, revisar o validar
  un servicio en Framework 7 (FW7), servicio JSON, servicio MQ, o cualquier servicio
  que siga la arquitectura de 3 capas (controlador-respuesta-lógica de negocio) en
  IBM i / RPGLE. También disparar cuando mencione "crear servicio", "nuevo servicio",
  "revisar servicio FW7", "validar arquitectura de servicio", "framework 7", "fw7",
  "FRMW7", "servicio JSON", "3 capas", "controlador", "capa de respuesta",
  "lógica de negocio", "bitácora de servicio", "BITAREG", "programa de montaje
  para servicio", "registrar servicio", "processParms", "estructura de servicio",
  o quiera crear, verificar o mejorar controladores, módulos de respuesta, lógica
  de negocio o prototipos de servicios — incluso si no dice explícitamente "Framework 7".
---

# Servicios Framework 7 — IBM i

## Propósito

Aplicar y verificar servicios Framework 7 con arquitectura de 3 capas siguiendo los estándares BAC.

Esta skill aplica en dos modos:
- **Aplicación:** Crear servicios nuevos usando las plantillas de `assets/` como base
- **Verificación:** Revisar servicios existentes contra las reglas de `references/` y la estructura de `assets/`

---

## Arquitectura de 3 Capas

Los servicios FW7 siguen un flujo de 3 capas: `Controlador → Respuesta → Lógica de Negocio`. Cada capa tiene responsabilidades exclusivas y restricciones estrictas — incluyendo qué includes son obligatorios, qué errores maneja cada capa y las 7 restricciones críticas globales (Full Free, sin hoja F, sin bibliotecas quemadas, etc.). Para esas reglas detalladas, cargar `references/fw7-architecture.md`.

> **Co-loading obligatorio:** Al crear o modificar código de un servicio FW7, cargar SIEMPRE también la skill `rpg-best-practices` para asegurar la calidad del código escrito (naming, manejo de errores, estructura ILE, etc.).

---

## Tabla de Decisión: ¿Qué plantilla usar?

| Escenario | Controlador | Respuesta |
|-----------|-------------|-----------|
| Servicio simple (sin lista) | `assets/controlador.sqlrpgle` | `assets/respuesta.sqlrpgle` |
| Servicio con lista de resultados | `assets/controlador_con_lista.sqlrpgle` | `assets/respuesta_con_listas.sqlrpgle` |
| Servicio transaccional (commit) | `assets/controlador.sqlrpgle` | `assets/respuesta_control_compromiso.sqlrpgle` |

Siempre se requieren además: `assets/bitacora.sqlrpgle`, `assets/processParms.rpgleinc` (o `serviceParamsList.rpgleinc`), `assets/prototipoBitacora.rpgleinc`, `assets/vista_bitacora.sql`.

---

## References — Cuándo cargar cada archivo

| Archivo | Cargar cuando… |
|---------|----------------|
| `references/fw7-architecture.md` | Necesitas reglas detalladas de capas, includes obligatorios, patrón CEXCEPTION, tablas MQ, o criterios de verificación de arquitectura |
| `references/library-standards.md` | Necesitas saber en qué biblioteca va cada componente (BCO vs Tarjetas), o estás validando que el servicio está en la biblioteca correcta |
| `references/montaje-servicios.md` | Estás creando o verificando el programa de montaje/desmontaje de un servicio |

---

## Assets — Plantillas de Código

### Para el Controlador
- **`assets/controlador.sqlrpgle`** — Controlador sin lista (caso más común)
- **`assets/controlador_con_lista.sqlrpgle`** — Controlador con iteración sobre lista de entrada

### Para la Respuesta
- **`assets/respuesta.sqlrpgle`** — Respuesta simple sin lista
- **`assets/respuesta_con_listas.sqlrpgle`** — Respuesta con generación de lista JSON (usa `yajl_beginArray`/`yajl_endArray`)
- **`assets/respuesta_control_compromiso.sqlrpgle`** — Respuesta con COMMIT/ROLLBACK para servicios transaccionales

### Para la Bitácora
- **`assets/bitacora.sqlrpgle`** — Módulo de acceso a datos de la bitácora (CRUD con setters/getters)
- **`assets/vista_bitacora.sql`** — Vista SQL sobre BITAREG o BITAREGTAR

### Para los Prototipos (archivos RPGLEINC/TXT)
- **`assets/processParms.rpgleinc`** — Prototipo del controlador sin lista + estructura `serviceParmsT`
- **`assets/serviceParamsList.rpgleinc`** — Prototipo del controlador con lista + estructura con contador `c_Contador`
- **`assets/prototipoBitacora.rpgleinc`** — Prototipo completo de la bitácora (constructor, CRUD, setters)

### Para el Montaje
- **`assets/programa_montaje_BCO.sqlrpgle`** — Montaje/desmontaje para servicios Banco (soporta Panamá y Regional)
- **`assets/programa_montaje_COM.sqlrpgle`** — Montaje/desmontaje para servicios Tarjetas/COM

---

## Flujo de Uso al Crear un Servicio Nuevo

1. Leer `references/fw7-architecture.md` para entender la arquitectura antes de escribir código
2. Decidir si el servicio tiene lista → seleccionar plantillas según la tabla de decisión
3. Copiar las plantillas de `assets/` como punto de partida
4. Completar los placeholders en cada fuente: nombre del servicio, parámetros, lógica de negocio
5. Crear el archivo de prototipos (RPGLEINC/TXT) usando `assets/processParms.rpgleinc` o `assets/serviceParamsList.rpgleinc`
6. Crear la bitácora: módulo RPGLE con `assets/bitacora.sqlrpgle` y vista SQL con `assets/vista_bitacora.sql`
7. Crear el programa de montaje con `assets/programa_montaje_BCO.sqlrpgle` o `assets/programa_montaje_COM.sqlrpgle`
8. Verificar contra `references/library-standards.md` que los componentes están en la biblioteca correcta

## Flujo de Uso al Verificar un Servicio Existente

1. Leer `references/fw7-architecture.md` → sección "Criterios de Verificación"
2. Comparar el controlador existente con `assets/controlador.sqlrpgle` o `assets/controlador_con_lista.sqlrpgle`
3. Verificar que la Respuesta no contiene lógica de negocio y tiene un único `monitor`
4. Verificar que la Lógica de Negocio no hace llamadas a PGMs ni CLs
5. Verificar bibliotecas con `references/library-standards.md`
6. Verificar programa de montaje con `references/montaje-servicios.md`
