# Programas de Montaje — Servicios Framework 7

## Tabla de Contenidos

1. [Propósito del Programa de Montaje](#propósito-del-programa-de-montaje)
2. [Operaciones de Instalación](#operaciones-de-instalación)
3. [Operaciones de Desinstalación](#operaciones-de-desinstalación)
4. [Diferencias BCO vs COM](#diferencias-bco-vs-com)
5. [Criterios de Verificación](#criterios-de-verificación)

---

## Propósito del Programa de Montaje

Todo servicio FW7 nuevo **debe** ir acompañado de un programa de montaje que:
1. Registra el servicio en las tablas del framework (MQA034)
2. Registra la biblioteca del controlador en TCA063
3. Registra la bitácora en HouseKeeping para limpieza automática
4. Agrega los mensajes de error al archivo de mensajes
5. Provee una operación de reversión (UNINSTALL) que deshace todo lo anterior

El programa de montaje es idempotente: al hacer INSTALL y luego UNINSTALL, el sistema queda en el mismo estado que antes.

---

## Operaciones de Instalación

El parámetro `inp_process = 'I'` activa el bloque de instalación que ejecuta en este orden:

### 1. Agregar mensajes de error

```rpgle
command = 'ADDMSGD MSGID(COD0001) MSGF(Biblioteca/ArchivoMensajes) ' +
          'MSG(''Texto del mensaje de error'')';
monitor;
    qCmdExc(command:%len(command));
on-Error;
    message = 'Error al agregar el mensaje COD0001';
    dsply (message);
endMON;
```

Repetir un bloque por cada mensaje de error del servicio.

### 2. Matricular el servicio en MQA034

```sql
INSERT INTO cmqmdat.MQA034
        (CODIGO_OPERACION, NOMBRE_SERVICIO, DESCRIPCION, ALCANCE, ESTADO,
         TIPO_SERVICIO, TIEMPO_EXPIRACION_MENSAJE, PRIORIDAD,
         CONTROLADOR, BIBLIOTECA_CONTROLADOR,
         GUARDA_REQUEST, GUARDA_RESPUESTA, RESPONDE_CON_LLAVE,
         SOLO_REQUEST, FECHA_CREACION)
VALUES  ('CodigoServicio', 'NombreServicio', 'DescripcionLarga',
         'REGIONAL', '1', 'BASIC', 50, 0,
         'NombreControlador', 'BibliotecaControlador',
         '1', '1', '1', '0', CURRENT DATE);
```

### 3. Registrar biblioteca en TCA063

```sql
INSERT INTO tccmdatpro.TCA063
        (TCAAPL, TCAOPC, TCASE2, TCABIB, TCAC03)
VALUES  ('NombreJob', 'Opcion',
         (SELECT Max(TCASE2) + 10
          FROM tccmdatpro.TCA063
          WHERE TCAAPL = 'NombreJob' AND TCAOPC = 'Opcion'),
         'NombreBiblioteca',
         'Descripcion del registro');
```

### 4. Registrar bitácora en HouseKeeping

**BCO (biblioteca dinámica):**
```sql
INSERT INTO CHSKPDAT.CHSKPA003
       (HSKPLIBT, HSKPTAB, HSKPFRE, HSKPNEXTEX, HSKPMISSTM, HSKPDELSTM)
VALUES (:production_library, 'NombreBitacora', 1, CURRENT DATE, ' ',
        'WHERE DATE(FECREQ) <= (CURRENT_DATE - 1 MONTH) AND CODAPL = CodigoServicio');
```

**COM (biblioteca fija):**
```sql
INSERT INTO CHSKPDAT.CHSKPA003
       (HSKPLIBT, HSKPTAB, HSKPFRE, HSKPNEXTEX, HSKPMISSTM, HSKPDELSTM)
VALUES ('TBITDAT', 'NombreBitacora', 1, CURRENT DATE, ' ',
        'WHERE DATE(FECREQ) <= (CURRENT_DATE - 1 MONTH) AND CODAPL = CodigoServicio');
```

---

## Operaciones de Desinstalación

El parámetro `inp_process = 'D'` activa el bloque de reversión que deshace todo en orden inverso:

### 1. Eliminar mensajes de error

```rpgle
command = 'RMVMSGD MSGID(COD0001) MSGF(Biblioteca/ArchivoMensajes)';
monitor;
    qCmdExc(command:%len(command));
on-Error;
    message = 'Error al remover el mensaje COD0001';
    dsply (message);
endMON;
```

### 2. Eliminar matrícula de MQA034

```sql
DELETE FROM CMQMDAT.MQA034
WHERE OPCODE = 'CodigoServicio';
```

### 3. Eliminar registro de TCA063

```sql
DELETE FROM TCCMDATPRO.TCA063
WHERE TCAAPL = 'NombreJob'
  AND TCAOPC = 'Opcion'
  AND TCABIB = 'NombreBiblioteca';
```

### 4. Eliminar registro de HouseKeeping

**BCO:**
```sql
DELETE FROM CHSKPDAT.CHSKPA003
WHERE HSKPLIBT = :production_library
  AND HSKPTAB = 'NombreBitacora';
```

**COM:**
```sql
DELETE FROM CHSKPDAT.CHSKPA003
WHERE HSKPLIBT = 'TBITDAT'
  AND HSKPTAB = 'NombreBitacora';
```

---

## Diferencias BCO vs COM

| Aspecto | BCO (`programa_montaje_BCO.sqlrpgle`) | COM (`programa_montaje_COM.sqlrpgle`) |
|---------|---------------------------------------|---------------------------------------|
| Parámetros | `inp_process` + `inp_country` | Solo `inp_process` |
| Soporte Panamá | Sí — `'P'` cambia biblioteca a `BPACYFILES` | No aplica |
| Biblioteca bitácora | Dinámica (`:production_library`) | Fija `TBITDAT` |
| Tabla bitácora base | `BITAREG` | `BITAREGTAR` |
| Constantes de país | `PANAMA = 'P'`, `REGION = 'R'` | No hay |

---

## Criterios de Verificación

Al revisar un programa de montaje existente:

- [ ] Tiene la constante `INSTALL = 'I'` y `UNINSTALL = 'D'`
- [ ] El bloque `INSTALL` ejecuta: mensajes → MQA034 → TCA063 → HouseKeeping
- [ ] El bloque `UNINSTALL` revierte todo en orden inverso
- [ ] BCO: tiene lógica de selección por `inp_country` (REGION/PANAMA)
- [ ] COM: no tiene lógica de Panamá ni variable `inp_country`
- [ ] BCO: usa `:production_library` (variable, no hardcodeada) en HouseKeeping
- [ ] COM: usa `'TBITDAT'` fijo en HouseKeeping
- [ ] La matrícula en MQA034 usa la biblioteca correcta del controlador
- [ ] Los mensajes de error tienen el prefijo/código correcto del servicio
- [ ] Cada `ADDMSGD` tiene su correspondiente `RMVMSGD` en el bloque UNINSTALL
