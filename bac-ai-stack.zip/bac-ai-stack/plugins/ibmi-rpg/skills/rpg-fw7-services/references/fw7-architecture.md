# Arquitectura Framework 7 — Reglas Detalladas

## Tabla de Contenidos

1. [Diagrama de Flujo](#diagrama-de-flujo)
2. [Capa Controlador](#capa-controlador)
3. [Capa Respuesta](#capa-respuesta)
4. [Capa Lógica de Negocio](#capa-lógica-de-negocio)
5. [Módulo de Bitácora](#módulo-de-bitácora)
6. [Patrón CEXCEPTION](#patrón-cexception)
7. [Tablas MQ de Referencia](#tablas-mq-de-referencia)
8. [Criterios de Verificación](#criterios-de-verificación)

---

## Diagrama de Flujo

```
Petición JSON entrante
        │
        ▼
┌───────────────────┐
│    CONTROLADOR    │  ← parsea JSON, valida buffer, delega
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│     RESPUESTA     │  ← llama lógica, bitácora, formatea JSON
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ LÓGICA DE NEGOCIO │  ← reglas, acceso a datos, CEXCEPTION
└───────────────────┘
```

---

## Capa Controlador

### Estructura Obligatoria

```rpgle
**FREE
ctl-opt nomain bnddir('BNDDIR que utilice');

/INCLUDE CSYSTSRC/QSRCTXT,CEXCEPTION
/INCLUDE CAJLSRC/QSRCTXT,YAJLH
/INCLUDE CMQASRC/QSRCTXT,CFWUTIL7
/INCLUDE <archivo TXT/RPGLEINC de la respuesta>
```

### Includes Obligatorios

| Include | Propósito |
|---------|-----------|
| `CSYSTSRC/QSRCTXT,CEXCEPTION` | Manejo de excepciones |
| `CAJLSRC/QSRCTXT,YAJLH` | Librería YAJL para parseo JSON |
| `CMQASRC/QSRCTXT,CFWUTIL7` | Utilitarios Framework 7 |
| `<TXT/RPGLEINC del servicio>` | Prototipo `processParms` + `serviceParmsT` |

### Procedimiento `processParms` — Firma Estándar

```rpgle
dcl-proc processParms export;
    dcl-pi *n ind;
        JSONReqBuffer char(32767);
    end-pi;
```

- Nombre fijo: `processParms` — el framework lo invoca por nombre
- Siempre `export`
- Parámetro único: `JSONReqBuffer char(32767)` — contiene la trama JSON

### Procedimiento `loadKeys`

Extrae los campos de la sección `key` del JSON usando `data-into` con YAJLINTO.

```rpgle
options = 'path= requestRoot/message/key ' +
    'case=any allowextra=yes trim=none allowmissing=yes';
data-into request %data(JSONReqBuffer:options)
    %parser('YAJLINTO': '{ "document_name": "requestRoot" }');
```

Para servicios con lista (controlador_con_lista): agregar `countprefix=c_` en las opciones para que cada DS de lista reciba el campo `c_Contador` con el número de elementos.

### Manejo de Errores en el Controlador

Solo maneja errores de framework (no de negocio):

- `FSC4004` — Buffer JSON en blanco (`CFWUTIL7_addErrorFromMessageFile`)
- `FSC4003` — Error de formato JSON (en `on-error` del monitor)

El controlador **no captura** errores de negocio; esos son responsabilidad de la Respuesta.

### Controlador con Lista

Cuando el request contiene una lista de elementos, el controlador itera con `FOR`:

```rpgle
FOR index = 1 TO request.NombreLista.c_Contador;
    status = ProcedimientoRespuesta(
                  request.NombreLista.ParametroEntrada(index)
                  :(index = 1)
                  :(index = request.NombreLista.c_Contador));
ENDFOR;
```

Los parámetros `isFirstRegister` e `isLastRegister` permiten a la Respuesta controlar apertura/cierre del array JSON.

---

## Capa Respuesta

### Includes Obligatorios

| Include | Propósito |
|---------|-----------|
| `ccgitsrc/qsrctxt,usec` | User space error codes |
| `CSYSTSRC/QSRCTXT,PGMSTSH` | Información del programa (job, user, etc.) |
| `CMQASRC/QSRCTXT,CFWUTIL7` | Utilitarios FW7 para construir respuesta JSON |
| `CAJLSRC/QSRCTXT,YAJLH` | Librería YAJL para construir JSON |
| `CSYSTSRC/QSRCTXT,CEXCEPTION` | Captura de excepciones de negocio |
| `<include lógica de negocio>` | Prototipo del procedimiento de lógica |

### Estructura del Procedimiento Principal

```rpgle
Dcl-Proc NombreProcedimiento export;
  Dcl-Pi *n ind;
    // Parámetros de entrada
  End-Pi;

  Monitor;
    // 1. Cargar bitácora con datos iniciales
    NombreFuente_cargaNombreBitacora(serviceParms);

    // 2. Llamar lógica de negocio
    // ...

    successResponse = *on;

  on-error;
    CEXCEPTION_catchException();
    NombreBitacora_setCODERR(@NombreBitacora:CEXCEPTION_getMessageId());
    NombreBitacora_setMSGERR(@NombreBitacora:%trim(CEXCEPTION_getMessageText()));
    CFWUTIL7_addError(CEXCEPTION_getMessageId():%trim(CEXCEPTION_getMessageText()));
    NombreFuente_insertNombreBitacora();
    successResponse = *off;
  endmon;

  return successResponse;
End-Proc;
```

### Regla del Monitor Único

La Respuesta tiene **exactamente un bloque** `monitor/on-error`. No se anidan monitores adicionales. La excepción lanzada desde la Lógica de Negocio sube hasta este único handler.

### Procedimientos de Bitácora en la Respuesta

Todo módulo de Respuesta debe implementar dos procedimientos internos:

**`NombreFuente_cargaNombreBitacora`** — carga los datos iniciales del request:
```rpgle
Nombre bitácora_new(@NombreBitacora);
Nombre bitácora_setFECREQ(@NombreBitacora:%Timestamp);
Nombre bitácora_setCODAPL(@NombreBitacora:CFWUTIL7_GETSERVICECODE());
Nombre bitácora_setNOMJOB(@NombreBitacora:PgmJob);
Nombre bitácora_setUSRJOB(@NombreBitacora:PgmUsr);
Nombre bitácora_setNUMJOB(@NombreBitacora:PgmJobNbr);
Nombre bitácora_setNOMPRG(@NombreBitacora:PgmNam);
Nombre bitácora_setCANREQ(@NombreBitacora:%Trim(CFWUTIL7_GETORIGINCHANNEL()));
Nombre bitácora_setNOMSVD(@NombreBitacora:sysName);
Nombre bitácora_setUUID(@NombreBitacora:CFWUTIL7_GETUUIDVALUE());
// + campos específicos del request
```

**`NombreFuente_insertNombreBitacora`** — establece timestamp de respuesta e inserta:
```rpgle
Nombre bitácora_setFECRPT(@NombreBitacora:%Timestamp);
Nombre bitácora_insert(@NombreBitacora);
```

### Respuesta con Control de Compromiso

Para servicios transaccionales:

```rpgle
// ANTES del monitor: cargar bitácora con datos iniciales
NombreFuente_cargaNombreBitacora(serviceParms);

Monitor;
  exec sql set transaction isolation level CS;
  // ... lógica transaccional ...
  successResponse = *on;
  exec sql commit;

on-error;
  exec sql rollback hold;
  exec sql set transaction isolation level NC;
  CEXCEPTION_catchException();
  // ... setear error en bitácora ...
  successResponse = *off;
endmon;

exec sql set transaction isolation level NC;
NombreFuente_insertNombreBitacora();
```

Observar que `insertNombreBitacora` se llama **fuera** del monitor para que siempre se inserte (éxito o error).

### Respuesta con Lista

Cuando el servicio retorna múltiples registros, la Respuesta abre/cierra el array JSON:

```rpgle
IF (isFirstRegister);
    yajl_beginObj('NombreObjetoList');
    yajl_beginArray('NombreDetalleDetail');
ENDIF;

Monitor;
  atLeastOneRegisterShown = *on;
  // ... llenar registro JSON ...
on-error;
  IF (isLastRegister = *on and atLeastOneRegisterShown = *off);
    // error: no hay registros
    CFWUTIL7_addError(...);
    successResponse = *off;
  ELSE;
    // error en registro individual: bitácora y continuar
  ENDIF;
endmon;

IF (isLastRegister);
    yajl_endArray();
    yajl_endObj();
ENDIF;
```

---

## Capa Lógica de Negocio

### Responsabilidades

- Aplicar reglas de negocio, validaciones, cálculos
- Acceder a datos (SQL, otros módulos/SRVPGM)
- Ser reutilizable desde múltiples interfaces (REST, MQ, batch, mantenimiento)
- Lanzar excepciones controladas con `CEXCEPTION_throwNewException`

### Patrón de Excepción

```rpgle
// Lanzar error controlado
CEXCEPTION_throwNewException('COD_ERR':'NOMBRE_ARCHIVO_MENSAJES');

// Nunca atrapar la excepción aquí — sube a la Respuesta
```

La lógica de negocio **lanza** excepciones pero **no las atrapa**. El `on-error` de la Respuesta es el único handler.

### Restricciones

- No importar CFWUTIL7 ni YAJLH (son del framework, no del negocio)
- No usar `exec sql commit` ni `exec sql rollback`
- No llamar a `QCMDEXC`, CLs, ni PGMs — solo procedimientos en módulos/SRVPGM con `ACTGRP(*CALLER)`

---

## Módulo de Bitácora

El módulo de bitácora es un fuente SQLRPGLE separado que implementa el patrón DAO (Data Access Object) para la tabla de bitácora del servicio.

### Estructura de la DS Privada

```rpgle
dcl-ds NombreBitacora_ds qualified template;
    IDNREQ int(10) inz;       // ID auto-generado
    FECREQ timestamp inz;     // Timestamp del request
    CODAPL char(10) inz;      // Código de aplicación (código del servicio)
    NOMJOB char(10) inz;      // Nombre del job
    USRJOB char(10) inz;      // Usuario del job
    NUMJOB packed(6) inz;     // Número del job
    NOMPRG char(10) inz;      // Nombre del programa
    CANREQ char(30) inz;      // Canal del request (web, app, etc.)
    NOMSVD char(10) inz;      // Nombre del servidor
    UUID char(100) inz;       // UUID de la petición
    FECRPT timestamp inz;     // Timestamp de la respuesta
    CODERR char(7) inz;       // Código de error
    MSGERR char(132) inz;     // Mensaje de error
    MCGCOD char(2) inz;       // Código MCG
    // + campos específicos del servicio
end-ds;
```

### Procedimientos del Módulo

| Procedimiento | Descripción |
|---------------|-------------|
| `NombreBitacora_new` | Constructor — limpia la DS |
| `NombreBitacora_getRecord` | Lee un registro por IDNREQ |
| `NombreBitacora_insert` | Inserta y recupera el ID generado |
| `NombreBitacora_update` | Actualiza un registro existente |
| `NombreBitacora_delete` | Elimina un registro por IDNREQ |
| `NombreBitacora_setXXXXX` | Setter para cada campo |

### Vista SQL de Bitácora

La vista se crea sobre:
- **Banco:** `BITAREG` en biblioteca `BCOCYFILES`
- **Tarjetas:** `BITAREGTAR` en biblioteca `TBITDAT`

La vista filtra por `CODIGO_APLICACION = 'CódigoServicio'`.

---

## Patrón CEXCEPTION

### Flujo Completo

```
Lógica de Negocio                    Respuesta
─────────────────                    ─────────
CEXCEPTION_throwNewException(...)    monitor;
    ↓                                  ...
  Excepción lanzada ──────────────→  on-error;
                                       CEXCEPTION_catchException();
                                       id  = CEXCEPTION_getMessageId();
                                       msg = CEXCEPTION_getMessageText();
                                       CFWUTIL7_addError(id:msg);
                                     endmon;
```

### Funciones CEXCEPTION de Uso Frecuente

| Función | Uso |
|---------|-----|
| `CEXCEPTION_throwNewException(id:msgFile)` | Lanzar excepción desde lógica de negocio |
| `CEXCEPTION_catchException()` | Atrapar la excepción en el on-error de Respuesta |
| `CEXCEPTION_getMessageId()` | Obtener el código de error (char 7) |
| `CEXCEPTION_getMessageText()` | Obtener el texto del mensaje de error |

### Funciones CFWUTIL7 de Uso Frecuente

| Función | Uso |
|---------|-----|
| `CFWUTIL7_addError(id:msg)` | Agregar error a la respuesta JSON del framework |
| `CFWUTIL7_addErrorFromMessageFile(id:msgFile)` | Agregar error desde archivo de mensajes |
| `CFWUTIL7_GETSERVICECODE()` | Obtener código del servicio activo |
| `CFWUTIL7_GETORIGINCHANNEL()` | Obtener canal de la petición |
| `CFWUTIL7_GETUUIDVALUE()` | Obtener UUID de la petición |

---

## Tablas MQ de Referencia

Todas se ubican en la biblioteca **`CMQMDAT`**.

| Tabla | Descripción |
|-------|-------------|
| `MQA034` | Inventario de servicios matriculados — aquí se registra cada servicio nuevo |
| `MQA032` | Logs de JOBs |
| `MQA033` | Logs de mensajes de peticiones procesadas |
| `MQA011` | Logs de errores a nivel de framework |

---

## Criterios de Verificación

Al revisar un servicio FW7 existente, validar:

### Controlador — Checklist

- [ ] Primera línea `**FREE`
- [ ] `ctl-opt nomain`
- [ ] Includes: CEXCEPTION, YAJLH, CFWUTIL7, TXT del servicio
- [ ] `processParms` declarado como `export` con firma correcta
- [ ] `loadKeys` usa `data-into` con `%parser('YAJLINTO'...)`
- [ ] Monitor maneja solo FSC4004 y FSC4003
- [ ] No contiene lógica de negocio
- [ ] No hay `exec sql` (excepto en loadKeys si aplica)
- [ ] No hay llamadas a PGMs o CLs
- [ ] No hay `ADDLIBLE`, `RMVLIBLE`, `CHGLIBL`
- [ ] No hay nombres de biblioteca hardcodeados

### Respuesta — Checklist

- [ ] Primera línea `**free`
- [ ] `ctl-opt nomain`
- [ ] Includes: usec, PGMSTSH, CFWUTIL7, YAJLH, CEXCEPTION, lógica de negocio
- [ ] Procedimiento principal declarado `export`
- [ ] Un solo bloque `monitor/on-error`
- [ ] `on-error` usa CEXCEPTION_catchException antes de CFWUTIL7_addError
- [ ] Contiene `cargaBitacora` e `insertBitacora` como procedimientos internos
- [ ] No contiene lógica de negocio
- [ ] No hay control de compromiso (excepto en respuesta_control_compromiso)
- [ ] No hay llamadas a PGMs o CLs

### Lógica de Negocio — Checklist

- [ ] No importa CFWUTIL7 ni YAJLH
- [ ] No hace `exec sql commit` ni `exec sql rollback`
- [ ] Lanza excepciones con `CEXCEPTION_throwNewException` en vez de retornar códigos de error
- [ ] No llama a `QCMDEXC`, CLs ni PGMs externos
- [ ] Puede ser llamada desde múltiples interfaces

### Bitácora — Checklist

- [ ] DS privada contiene los campos estándar (IDNREQ, FECREQ, CODAPL, NOMJOB, USRJOB, NUMJOB, NOMPRG, CANREQ, NOMSVD, UUID, FECRPT, CODERR, MSGERR, MCGCOD)
- [ ] Existe prototipo RPGLEINC con constructor, CRUD y setters
- [ ] Vista SQL creada sobre BITAREG (banco) o BITAREGTAR (tarjetas)
- [ ] Vista filtra por `CODIGO_APLICACION`
