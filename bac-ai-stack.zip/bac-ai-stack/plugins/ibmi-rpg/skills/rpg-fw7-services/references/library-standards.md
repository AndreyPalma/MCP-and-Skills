# Estándares de Bibliotecas — Framework 7

## Tabla de Contenidos

1. [Bibliotecas por Tipo de Core](#bibliotecas-por-tipo-de-core)
2. [Reglas de Montaje por Core](#reglas-de-montaje-por-core)
3. [Registro en Tablas de Inventario](#registro-en-tablas-de-inventario)
4. [HouseKeeping de Bitácora](#housekeeping-de-bitácora)
5. [Criterios de Verificación](#criterios-de-verificación)

---

## Bibliotecas por Tipo de Core

### Core Bancario (BCO)

| Componente | Biblioteca Estándar |
|------------|---------------------|
| Controlador | `BBCOSRV` |
| Respuesta | `BBCOSRV` |
| Lógica de Negocio | `BCOUSRLIB` u otra según la aplicación |
| Bitácora (tabla física) | `BCOCYFILES` (regional) / `BPACYFILES` (Panamá) |
| Vista de Bitácora retención | Aplicación: `BCO`, Versión: `REG`, Biblioteca: `BCOCYFILES` |

### Core Tarjetas / Credomatic (COM)

| Componente | Biblioteca Estándar |
|------------|---------------------|
| Controlador | `TCOMSRV` |
| Respuesta | `TCOMSRV` |
| Lógica de Negocio | Depende de la aplicación |
| Bitácora (tabla física) | `TBITDAT` |
| Vista de Bitácora retención | Aplicación: `TBIT`, Versión: `1`, Biblioteca: `TBITDAT` |

---

## Reglas de Montaje por Core

### BCO — Soporte Regional y Panamá

El programa de montaje BCO recibe dos parámetros:
- `inp_process`: `'I'` (INSTALL) o `'D'` (UNINSTALL)
- `inp_country`: `'R'` (REGION) o `'P'` (PANAMA)

La biblioteca de producción se determina en tiempo de ejecución:

```rpgle
if inp_country = REGION;
   production_library = 'BCOCYFILES';
elseif inp_country = PANAMA;
   production_library = 'BPACYFILES';
endif;
```

Esto aplica para:
- La referencia a la bitácora en HouseKeeping (`HSKPLIBT`)
- Cualquier INSERT/DELETE a tablas que dependan de la biblioteca del país

### COM — Sin distinción regional

El programa de montaje COM **no** tiene lógica de Panamá. La biblioteca siempre es `TBITDAT` para la bitácora.

```rpgle
// En COM, la biblioteca siempre es fija
values('TBITDAT', 'NombreBitacora', ...)
```

---

## Registro en Tablas de Inventario

### MQA034 — Matrícula del Servicio

Tabla ubicada en `CMQMDAT`. Campos clave del INSERT:

| Campo | Descripción | Ejemplo |
|-------|-------------|---------|
| `CODIGO_OPERACION` | Código único del servicio | `'99999'` |
| `NOMBRE_SERVICIO` | Nombre corto del servicio | `'NombreServicio'` |
| `DESCRIPCION` | Nombre largo descriptivo | `'Descripción completa'` |
| `ALCANCE` | Alcance del servicio | `'REGIONAL'` |
| `ESTADO` | Estado activo | `'1'` |
| `TIPO_SERVICIO` | Tipo de servicio | `'BASIC'` |
| `TIEMPO_EXPIRACION_MENSAJE` | Tiempo en segundos | `50` |
| `PRIORIDAD` | Prioridad de procesamiento | `0` |
| `CONTROLADOR` | Nombre del fuente controlador | `'NombreCtrl'` |
| `BIBLIOTECA_CONTROLADOR` | Biblioteca del controlador | `'BBCOSRV'` |
| `GUARDA_REQUEST` | Guardar request en log | `'1'` |
| `GUARDA_RESPUESTA` | Guardar respuesta en log | `'1'` |
| `RESPONDE_CON_LLAVE` | Responde con llave de sesión | `'1'` |
| `SOLO_REQUEST` | Solo procesa request sin respuesta | `'0'` |
| `FECHA_CREACION` | Fecha de creación | `CURRENT DATE` |

### TCA063 — Registro de Biblioteca

Tabla ubicada en `tccmdatpro`. El número de secuencia (`TCASE2`) se calcula automáticamente:

```sql
INSERT INTO tccmdatpro.TCA063
        (TCAAPL, TCAOPC, TCASE2, TCABIB, TCAC03)
VALUES  ('NombreJob', 'Opcion',
         (SELECT Max(TCASE2) + 10
          FROM tccmdatpro.TCA063
          WHERE TCAAPL = 'NombreJob' AND TCAOPC = 'Opcion'),
         'NombreBiblioteca',
         'Descripción del agregado');
```

---

## HouseKeeping de Bitácora

Tabla en `CHSKPDAT.CHSKPA003`. Registra la bitácora del servicio para limpieza automática de datos antiguos.

### BCO — INSERT con biblioteca dinámica

```sql
INSERT INTO CHSKPDAT.CHSKPA003
       (HSKPLIBT, HSKPTAB, HSKPFRE, HSKPNEXTEX, HSKPMISSTM, HSKPDELSTM)
VALUES (:production_library, 'NombreBitacora', 1, CURRENT DATE, ' ',
        'WHERE DATE(FECREQ) <= (CURRENT_DATE - 1 MONTH) AND CODAPL = CodigoServicio');
```

La variable `:production_library` es `BCOCYFILES` o `BPACYFILES` según el país.

### COM — INSERT con biblioteca fija

```sql
INSERT INTO CHSKPDAT.CHSKPA003
       (HSKPLIBT, HSKPTAB, HSKPFRE, HSKPNEXTEX, HSKPMISSTM, HSKPDELSTM)
VALUES ('TBITDAT', 'NombreBitacora', 1, CURRENT DATE, ' ',
        'WHERE DATE(FECREQ) <= (CURRENT_DATE - 1 MONTH) AND CODAPL = CodigoServicio');
```

### Política de retención

Por defecto: **1 mes** de retención de datos de bitácora.

---

## Criterios de Verificación

Al revisar un servicio existente, validar:

- [ ] **Controlador** está en `BBCOSRV` (BCO) o `TCOMSRV` (COM)
- [ ] **Respuesta** está en `BBCOSRV` (BCO) o `TCOMSRV` (COM)
- [ ] **Lógica de Negocio** está en biblioteca correcta para la aplicación
- [ ] **No hay nombres de biblioteca hardcodeados** en el código fuente del servicio
- [ ] El programa de montaje BCO tiene lógica de Panamá (`inp_country = PANAMA`)
- [ ] El programa de montaje COM **no** tiene lógica de Panamá
- [ ] La matrícula en `MQA034` tiene `BIBLIOTECA_CONTROLADOR` con la biblioteca correcta
- [ ] El HouseKeeping usa la biblioteca dinámica (BCO) o fija `TBITDAT` (COM)
- [ ] La vista de bitácora existe en la biblioteca correcta (`BCOCYFILES` o `TBITDAT`)
