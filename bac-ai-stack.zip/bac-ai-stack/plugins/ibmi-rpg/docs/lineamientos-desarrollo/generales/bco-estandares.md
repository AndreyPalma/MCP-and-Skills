# Manual de Estándares de Banco — BAC Credomatic

---

## 1. Alcance del Manual de Estándares de Banco

El presente Manual de Estándares aplica para objetos que se encuentran en las bibliotecas que forman el CORE de Banco. Estas bibliotecas son las que inician de la siguiente forma: BCO, IBS, RL, BPA, COMUSR, EIBS, TFBS, BSI y PYM.

---

## 2. Definición de Nombres de Objetos

### 2.1 Aplicaciones

Se considera aplicaciones aquellos programas tipo `*PGM` y `*SRVPGM` que forman parte de un producto o servicio bancario (Préstamos, Cuentas de Ahorro, Certificados, etc.).

Para nombrar un objeto que forma parte de una aplicación se debe considerar los siguientes aspectos:

- **ID de Aplicación:**
  Según la aplicación del sistema se busca que en tres letras se pueda identificar fácilmente su funcionalidad. Ejemplo:

  | Código | Descripción                  |
  |--------|------------------------------|
  | LNS    | Módulo de préstamos           |
  | LNE    | Módulo de Líneas de Crédito   |
  | ADS    | Adelanto de Salarios          |
  | UTL    | Funciones utilitarias         |
  | PPP    | Pago Planillas y Proveedores  |

  > **Nota:** La lista completa de aplicaciones de Banco se encuentra en: http://cri400f/BaseDeDatos/index.html, seleccionar "Listado de Aplicaciones", indicar usuario y contraseña de ingreso al CRI400F.

- **Tipos de objeto:**
  Permite identificar con una letra el tipo de objeto. Para definir el tipo se debe considerar alguno de los siguientes valores:

  | Código | Descripción                              |
  |--------|------------------------------------------|
  | C      | CL o CLLE                                |
  | P      | Programa tipo `*PGM`                     |
  | S      | Programa de servicio o tipo `*SRVPGM`    |

  > **Nota:** En caso de `*Módulos`, ver apartado para este tipo de ítems.

- **Consecutivo:**
  Número único que identifica el aplicativo u objeto.

#### Estructura del nombre de objeto o programa

```
AAATCCC
│  │└──  Consecutivo del objeto.
│  └───  Tipo de objeto.
└──────  Código de aplicación.
```

---

### 2.2 Procesos de Cierre Bancario

Los objetos que se utilizan para personalizar procesos que corren en la corriente del cierre, se deben nombrar `EODBTHxxx`, `EODAYxxx`, `EOYEARxxx` y `EODWPxxxxx`. Es importante, antes de crear un nuevo objeto de cierre, validar si existe uno en el punto de cierre en el cual es requerido realizar el cambio, de ser así reutilizar este proceso.

#### 2.2.1 Programas tipo Wrappers de la corriente del cierre

Siguiendo la estrategia de modularización del cierre, cuando se necesite agregar nuevas funcionalidades en la corriente del cierre que **no** sean solamente un *CALL* directo a un programa sin parámetros, se debe crear un wrapper. Un wrapper se define como un pequeño programa de tipo CL en el cual se encapsulan las funcionalidades del cierre en unidades independientes.

El estándar para nombrar un wrapper es el siguiente:

```
EODWPXXXXX
│   └──── Consecutivo.
└──────── Constante para identificarlo.
```

Los primeros tres dígitos del consecutivo se utilizan para nombrar los wrappers en orden, por ejemplo, **EODWP00100**, **EODWP00200**, **EODWP00300** y así sucesivamente.

Los últimos dos dígitos del consecutivo se utilizan por si es necesario ingresar un nuevo wrapper en medio de dos wrappers ya existentes. Por ejemplo, si se tienen los wrappers **EODWP11000** y **EODWP11100** y se desea ingresar un nuevo wrapper en la corriente del cierre en medio de estos dos entonces se nombraría **EODWP11001**.

En caso de ser requerido crear un nuevo objeto en la corriente del cierre, se debe contar con el VB de Experto de Cierre de Banco. Para gestionar el VB, es necesario incluir la tarea en Azure, en la pizarra *"Implementación de Cambios en Cierre de Bancario"*

**Nota por considerar:**

1. Aquellos aplicativos de lógica de negocio que se trabajen bajo la metodología de orientación a Servicios (Servicios expuestos por los diferentes FrameWorks corporativos) deben seguir las especificaciones dadas en este documento. Dichos aplicativos se deben catalogar en las bibliotecas que se consideran CORE Bancario.

#### 2.2.2 Programas usados en los backups previo y posterior del cierre

El cierre del banco entre sus procesos, cuenta con 2 wrappers encargados de los respaldos previo y posterior, estos son: **EODWP00030** y **EODWP13900**, para cada uno de ellos se deberá crear el programa que se desea ejecute el respaldo deseado según el parámetro ingresado en la tabla `CNTRLCNT` en la columna `CNTBUM`, este valor en el cierre se utiliza como una variable global inserta en la Data Area (DTAARAEOD) y se llama `BUPMED`, basado en el este valor, se toman los primeros 2 caracteres que se concatenan a la constante correspondiente según el momento de respaldo para conocer el nombre del programa a ser ejecutado.

- Para el respaldo previo (EODWP00030). La convención es la siguiente:

  ```
  EODBK900XX
  │      └── Identificador de respaldo
  └───────── Constante
  ```

- Para el respaldo posterior (EODWP13900). La convención es la siguiente:

  ```
  EODBK901XX
  │      └── Identificador de respaldo
  └───────── Constante
  ```

Ambos programas deben cumplir con lo siguiente:

- El tipo de programa debe ser CLLE.
- No debe tener parámetros de entrada. De ocupar algún dato valide si la Data Area de valores globales le puede ayudar (DTAARAEOD).
- Para el registro de tiempos, al inicio del programa se debe ejecutar la siguiente sentencia:
  ```
  PTCMLIBPRO/STARTTIMER PROCESO(nombre_del_programa) JOBID(&JOBID)
  ```
  El JOBID es una variable de caracteres de longitud 8.
  Al final del programa deberá ejecutar la sentencia que registra la hora de finalización:
  ```
  PTCMLIBPRO/ENDTIMER PROCESO(nombre_del_programa) JOBID(&JOBID)
  ```
- En caso de falla del programa, controle el error y de opción al operador de reintentar de ser posible o de elegir otra opción, dicha opción se debe apegar a la convención estándar que le dio origen al programa actual.

> **Nota:** Todo programa nuevo debe contar con el Visto Bueno de Experto de Cierre de Banco.

---

### 2.3 Archivos de Despliegue

Se considera archivo de despliegue las pantallas (`*DSPF`) y reportes (`*PRTF`). A este tipo de archivo se le identifica de acuerdo con el nombre del aplicativo al cual está asociado, más un identificador de dispositivo.

- **Identificador de dispositivo: `FM`** — Id para archivos de despliegue

  ```
  AAATCCCFM
  │  │  └── Constante "FM".
  │  │
  │  └───── Consecutivo.
  │
  └──────── Tipo de Objeto.
            Código de Aplicación.
  ```

- **`R`** — Id para archivos de Impresión

  ```
  AAATCCCR
  │  │  └── Constante "R".
  │  │
  │  └───── Consecutivo.
  │
  └──────── Tipo de Objeto.
            Código de Aplicación.
  ```

---

### 2.4 Módulos

El nombre de los módulos (`*Module`) va asociado al nombre del programa de servicio al cual pertenece más un consecutivo, que permita la identificación del módulo en forma única. Ejemplo:

| Nombre     | Descripción          |
|------------|----------------------|
| LNSS001    | Programa de servicio |
| LNSS00100  | Módulo 00            |
| LNSS00101  | Módulo 01            |

```
AAATCCCXX
│  │  └── Consecutivo para identificación única del módulo.
│  └───── Nombre del programa (*SRVPGM).
└──────── (implícito en los primeros caracteres)
```

---

### 2.5 Prototipos

Definición externa de la interfaz del procedimiento o función. Su nombre se define de acuerdo con el módulo al cual pertenece más la constante `"H"`.

- **ID para prototipos:** Permite identificar el objeto como un archivo de texto, para ello se utiliza el valor de `H`.

  ```
  AAATCCCXXH
  │       └── Id que identifica que es un archivo tipo texto (TXT). Su valor es "H".
  └────────── Nombre del módulo.
  ```

---

## 3. Nomenclatura Interna de Objetos

El nombre interno de los procedimientos o funciones debe estar relacionado con el nombre del módulo o programa al cual pertenece más un nombre descriptivo de su funcionalidad. Ejemplo:

### 3.1 Definición Interna de Módulos

```
AAATCCCXXDescrip...N
│        └── Nombre del procedimiento o función.
└──────────── Nombre del módulo.
```

Ejemplo en formato columnar:

```rpgle
P LNES00101_CrearLineaCR...
P                B                EXPORT
D LNES00101_CrearLineaCR...
```

### 3.2 Definición Interna de Programas

```
AAATCCCDescrip...N
│      └── Nombre del procedimiento o función.
└───────── Nombre del programa.
```

### 3.3 Parámetros en Procedimientos y/o Funciones

- **Definición en un Módulo:**
  En caso de conocer si el valor del parámetro no variará su valor, se debe indicar como constante y su nombre debe empezar con `pc_` + nombre descriptivo. De lo contrario, si es un valor que es alterado por el procedimiento, entonces iniciará con `ps_` + nombre descriptivo. Ejemplo:

  ```rpgle
  D CUSS00101_ObtNombre...
  D                 PR                n
  D  pc_NumCliente            9p 0 const
  D  ps_NombCliente          45a
  ```

### 3.4 Variables Internas

Los nombres de las variables deben reflejar la razón del dato que almacena por lo que su nombre debe ser significativo; si el nombre es compuesto, entonces se combinará la primera palabra en minúscula y las siguientes iniciarán con la primera letra en mayúscula. Ejemplo:

```
tipo de prestamo => tipPrestamo
```

### 3.5 Variables de Archivos

Los nombres de las variables utilizadas en el programa cuyo origen está definido en un archivo, se recomienda escribirlas en MAYÚSCULA. Ejemplo:

```
DEAACC = numContrato ;
```

### 3.6 Documentación Interna de Programas y/o Procedimientos

Es un aspecto muy importante, tanto durante el desarrollo de la aplicación como en el mantenimiento, ya que permite la posibilidad de la reutilización de parte del programa en otras aplicaciones, ya que provee una perspectiva general del aplicativo. Para la documentación se debe considerar al menos los siguientes aspectos:

- **La documentación de los programas:**

  | Campo       | Descripción                                           |
  |-------------|-------------------------------------------------------|
  | Descripción | Descripción general del programa.                     |
  | Autor       | Nombre de la persona que realiza la programación.     |
  | Fecha       | Fecha formato AAAA/MM/DD en que se realizó la programación. |
  | Proyecto    | Numero de solicitud de programación.                  |

  ```rpgle
  *******************************************************************
  * Descripción: Descripción general del proceso.                   *
  * Autor       : Nombre de quien lo programó                       *
  * Fecha       : Fecha en que se creó en formato AAAA/MM/DD        *
  * Proyecto    : CRI-XXXXX                                         *
  *******************************************************************
  *                   M O D I F I C A C I O N E S                   *
  *******************************************************************
  * Descripción: Descripción del cambio.                            *
  * Autor       : Nombre del responsable.                           *
  * Fecha       : Fecha del cambio.                                 *
  * Proyecto    : CRI-XXXXX                                         *
  *******************************************************************
  ```

- **La documentación de procedimientos y/o función:**

  ```rpgle
  *-------------------------------------------------------------------
  * Procedimiento: LNSS00115_CalcCuota
  * Proposito    : Calcula cuota de pago de prestamo
  * Valor Retorno: Monto de la cuota
  * Lista Parámetros:
  *   principal  => Monto del principal
  *   tasaInteres => Tasa de interes
  *   nPeriodos  => Número de periodos
  *   frecuencia => Frecuencia de pago.
  * Codigos de mensaje:
  *   - no hay -
  *-------------------------------------------------------------------
  D LNSS00115_CalcCuota...
  D                 PR           13s 2
  D  principal                   13s 2 const
  D  tasaInteres                  9s 6 const
  D  nPeriodos                    3s 0 const
  D  frecuencia                   1a    const
  ```

---

### 3.7 Objetos retenidos en BBCOCLS

Los siguientes lineamientos aplican para objetos retenidos en la biblioteca BBCOCLS:

#### 3.7.1 Como nombrar los objetos DAO

Los RPGDAO deben tener el mismo nombre de la tabla a la cual pertenece. Ejemplo: DAO de tabla `GLMSTTB` al igual que el fuente TXT con los prototipos.

#### 3.7.2 Como nombrar los objetos tipo Clase

Los RPG Class se deben nombrar utilizando las abreviaturas definidas por el DBA, por ejemplo:
Debito Cuenta Contable --> `DBTCTB`

Hasta un máximo de 9 caracteres dejando el último carácter para definir el nombre del TXT donde se incluyen los prototipos de los procedimientos de la clase, el nombre se compone de:

- Del nombre de la clase
- Constante `"H"`.

Ejemplo: `DBTCTBH`

Para consultar las abreviaturas o avps se utilizan los scripts de consulta

> **Nota:** Para incluir nuevas clases en la biblioteca BBCOCLS deberá ingresar un tiquete de la siguiente manera:
> - Proveedor: Servicios Regionales
> - Tipo de tiquete: Solicitud
> - Servicio: DICA Core Banco
> - Sub-Servicio: Solicitud VB Experto Arquitectura OO

#### 3.7.3 Como nombrar los procedimientos

Los nombres de los procedimientos deben conformarse con palabras en inglés según las reglas:

- Nombre la clase en MAYÚSCULAS
- Carácter `"_"`
- Acción en letras minúsculas
- Palabras siguientes en minúscula y que inicien en Mayúscula

Ejemplo — método para validar un estatus de cuenta para débito: `ACMSTTB_validateDebitStatus`

#### 3.7.4 Estructura de objetos de las clases

Las clases deben conformarse mediante un solo objeto tipo `*MODULE` dentro de un objeto `*SRVPGM`, no se permiten ensamblar varios módulos dentro de un programa de servicio.

---

## 4. Archivos de Control de Banco

Los siguientes son los archivos de control de Banco por Aplicación. El objetivo es mantener el conocimiento en la base de datos:

| Archivo   | Descripción                       |
|-----------|-----------------------------------|
| CNTRLLNS  | Préstamos                         |
| CNTRLDLS  | Certificados                      |
| CNTRLDD   | Cuentas de Detalle                |
| CNTRLBNK  | Parámetros Generales de Banco     |
| CNTRLSEG  | Control de Seguridad              |

---

## 5. Tips de Programación

### 5.1 Programas de Servicio

- Para la creación de programas de servicio, se utilizará el Binder Language que es un tipo de fuente `BND`. La utilización de este tipo de fuente ayuda al control de cambios y evita la recompilación masiva cada vez que se cambia el Signature.

  ```bnd
  STRPGMEXP PGMVAL(*CURRENT)
    EXPORT SYMBOL('...')
    :
    EXPORT SYMBOL('...')
  ENDPGMEXP

  STRPGMEXP PGMVAL(*PRV)
    EXPORT SYMBOL('...')
    :
    EXPORT SYMBOL('...')
  ENDPGMEXP
  ```

  > Las funciones nuevas van en el bloque `PGMVAL(*CURRENT)` junto con las funciones anteriores. Las funciones originales permanecen en el bloque `PGMVAL(*PRV)`.

- Para la enlazar a nuestro programa funciones de un programa de servicio, se recomienda incluir en un Directorio de Enlace el programa de servicio (Actualmente existen 2 BCOSERVICE y SERVICEBCO). NO se deben incluir en el directorio Módulos.

  ```rpgle
  H BndDir('SERVICEBCO')
  ```

### 5.2 Archivos de Despliegue

- Incluir en la definición de la pantalla la palabra clave `INDARA`.
- En la definición (Hoja F) de la pantalla incluir la definición de la estructura de indicadores:

  ```rpgle
  FADSP003FM CF  E        WORKSTN IndDs(DspIDS)
  ```

  Definir la estructura de datos (`DspIDS`):

  ```rpgle
  *: Definición Estructuras de Datos.
  D DspIDS        DS
  D  salir                  3       3N
  D  sflDsp                60      60N
  D  sflDspCtl             61      61N
  D  sflClr                62      62N
  D  sflEnd                63      63N
  D  sflNxtChg             64      64N
  D  pageDown              69      69N
  ```
