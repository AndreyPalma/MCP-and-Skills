## 💡 RESTRICCIONES EN EL DESARROLLO

### 1. Prohibición de BEANS (técnica de encapsulamiento de lógica de base de datos diseñado para imitar objetos de la programación orientada a objetos)

**❌ BEANS NO PERMITIDOS:**

- Queda **ESTRICTAMENTE PROHIBIDO** el uso de BEANS en cualquier componente del servicio
- Esta restricción aplica a todas las capas: Controlador, Respuesta y Lógica de Negocio