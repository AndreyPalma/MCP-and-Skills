# Estándares de Nombres para IBM i

## 1. Aplicaciones

Las aplicaciones se representan por un código de dos caracteres para las ya existentes, y de cuatro caracteres para las nuevas que se creen. En el caso de las ya existentes hay algunas excepciones debido a que fueron creadas antes de la existencia de un estándar.

### 1.1 Aplicaciones Existentes

El código está conformado de la siguiente manera:

```
AA
└─ Código representativo de la aplicación (dos caracteres)
```

**Ejemplos de aplicaciones existentes:**

| Código | Descripción |
|--------|-------------|
| AU | Autorizaciones |
| CA | Cargos automáticos |
| DE | Data Entry |
| WW | Interfaz con aplicaciones de Internet |

---

### 1.2 Aplicaciones Nuevas

Para las nuevas aplicaciones que se creen, el código está conformado de la siguiente manera:

```
A AAA
│  └─ Código representativo de la aplicación (tres caracteres)
└─ Área a la que pertenece la aplicación:
   B = Banca
   T = Tarjetas
   C = Corporativo
   W = Internet (Web)
```

**Ejemplos de aplicaciones nuevas:**

| Código | Descripción |
|--------|-------------|
| CBNX | Interfaz con Banco Banex, área tarjetas |
| BSEG | Sistema de Seguridad, área banca |

---

### 1.3 Catálogo Completo de Aplicaciones

> **Nota:** La lista completa de aplicaciones se encuentra en el archivo `APPMST` en la biblioteca `PDE400` del servidor de desarrollo.
>
> La lista completa de aplicaciones de Banca se encuentra en: [http://crl400f/BaseDeatos/index.html](http://crl400f/BaseDeatos/index.html)
>
> Seleccionar **"Listado de Aplicaciones"**, indicar usuario y contraseña de ingreso al CRI400F.

---

## Notas Importantes

- **Consistencia:** Todos los desarrollos nuevos deben seguir el formato de cuatro caracteres (A AAA).
- **Documentación:** Cualquier nueva aplicación debe ser registrada en el catálogo central para mantener la trazabilidad.
- **Excepciones:** Las aplicaciones existentes con dos caracteres son excepciones históricas y no deben usarse como base para nuevas creaciones.

---

## 2. Bibliotecas de Producción

Los nombres de las bibliotecas de producción nuevas varían dependiendo del tamaño del código de aplicación.

### 2.1 Para Aplicaciones con Código de Dos Caracteres

Si se va a crear una biblioteca nueva para una aplicación existente, cuyo código es de dos caracteres, el nombre de la biblioteca se conforma de la siguiente manera:

```
AA CM TTT PRO
│  │  │   │
│  │  │   └─ Constante PRO (producción)
│  │  └─ Tipo de biblioteca
│  └─ Constante CM
└─ Código de aplicación
```

**Ejemplos:**

- AUCMLIBRPRO
- AUCMDATPRO
- AUCMSRCPRO
- AUCMTSTPRO
- AUCMTESPRO

### 2.2 Para Aplicaciones con Código de Cuatro Caracteres

Si se va a crear una biblioteca nueva para una aplicación nueva, cuyo código es de cuatro caracteres, el nombre de la biblioteca se conforma de la siguiente manera:

```
A AAA TTT
│  │   │
│  │   └─ Tipo de biblioteca
│  └─ Código de aplicación
└─ Área a la que pertenece la aplicación:
   B = Banca
   T = Tarjetas
   C = Corporativo
   W = Internet (Web)
```

**Ejemplos:**

- BCIFLIB
- BCIFDAT
- BCIFSRC
- BCIFTST
- BCIFTES

#### Tipos de Biblioteca Permitidos

En ambos casos los tipos de biblioteca permitidos son:

| Tipo | Descripción |
|------|-------------|
| **LIB** | Para objetos no BD, incluyendo objetos de la arquitectura orientada a objetos |
| **DAT** | Para objetos BD (tablas, índices, vistas, triggers, store procedures, etc.) |
| **SRC** | Para fuentes (solo en CPU de desarrollo) |
| **TST** | Para pruebas objetos no BD |
| **TES** | Para pruebas objetos BD y triggers |

---

### 2.3 Bibliotecas Especiales para Desarrollo de Servicios

Para tener un mejor control de los componentes que implementan servicios de IBM i, los componentes Controlador y Respuesta de los servicios se crearán en estas bibliotecas específicas:

| Tipo de Servicio | Biblioteca Controlador y Respuesta | Biblioteca de Lógica de Negocio |
|------------------|----------------------------------|--------------------------------|
| Servicios Bancarios | BBCOSRV | BCOUSLIB |
| Servicios de Tarjetas | TCUMSRV | Biblioteca tipo LIB de la aplicación correspondiente |

De acuerdo con lo indicado en el Lineamiento Desarrollo Servicios IBM i, puede ver el lineamiento en este enlace: [Lineamientos para Desarrollo en Framework 7 - IBM i](https://sharepoint-url) en SharePoint.

---

### 2.4 Tipos de Biblioteca Deprecados

Ya **no está permitido** crear nuevas bibliotecas con los siguientes tipos:

- **APL:** Para almacenar el gestor principal y objetos utilizados exclusivamente por la aplicación en arquitectura Orientada a Objetos (OO)
- **SRV:** Para los objetos subsgesteros y paquetes o programas de servicio en arquitectura OO
- **CLS:** Para los componentes que encapsula la capa de acceso a datos (Beans) externalizados

#### Ejemplos de Bibliotecas Deprecadas (No Crear Nuevas)

- AUCMCLSPRO
- AUCMSRVPRO
- GECMAPLPRO
- TAFISRV
- CCORAPL
- CCORSRV
- CCORCLS

---

### 2.5 Gestión de Bibliotecas Existentes

Las bibliotecas ya creadas se mantienen en la aplicación. Por simplificación del sistema es permitido mover los objetos de esas bibliotecas a las bibliotecas tipo LIB correspondientes (ejemplo de AUCMCLSPRO a AUCMLIBPRO), pero **no es obligatorio**.

> **Nota:** Las migraciones de bibliotecas deprecadas a nuevas deben ser coordinadas con el Arquitecto de la aplicación para minimizar impactos en producción.

---

## 3. Bibliotecas de Trabajo

### 3.1 Nomenclatura General

Los nombres de estas bibliotecas de trabajo empiezan con la constante **LIB** y pueden tener de 2 a 7 caracteres adicionales:

- **Para personas:** Se usan las iniciales del nombre (2 a 4 caracteres)
- **Para equipos:** Se usa el nombre del equipo, hasta 7 caracteres
- **Tipo de biblioteca:** Las bibliotecas se crean con tipo `*TEST`

Si una persona o equipo necesita más de una biblioteca, se puede agregar un consecutivo opcional.

**Formato:**

```
AAA TTT nn
│   │   │
│   │   └─ Consecutivo opcional
│   └─ Sufijo (iniciales o nombre de equipo)
└─ Constantes LIB (de library, biblioteca)
```

**Ejemplos:**

| Biblioteca | Tipo | Descripción |
|-----------|------|-------------|
| LIBCRO | Personal | Camilo Rodríguez Quirós |
| LIBAACS | Personal | Abdiel Antonio Acosta Sevillano |
| LIBAACS2 | Personal | Abdiel Antonio Acosta Sevillano (segunda biblioteca) |
| LIBKARUNA | Equipo | Equipo KARUNA |

---

### 3.2 Bibliotecas Especiales Reservadas

Se tienen reservados estos nombres de bibliotecas. **No se pueden asignar** a personas, equipos, ni aplicaciones de producción:

| Biblioteca | Propósito |
|-----------|-----------|
| **LIBAYP** | Para pases de objetos de automatización de instalación de pases |
| **LIBOPTDOL** | Para utilitarios de operaciones |
| **LIBRESTORE** | Para restauración de objetos temporales en producción |

---

### 3.3 Catálogo de Bibliotecas de Trabajo

La lista completa de bibliotecas de producción catalogadas se puede consultar con esta sentencia SQL:

```sql
SELECT DISTINCT PDNAME
FROM PDE400.PRDMST
ORDER BY 1
```

---

## 4. Nombres de Objetos y Miembros Fuentes

### 4.1 Introducción

Los diferentes tipos de objetos o fuentes que se pueden crear en IBM i (AS/400) necesitan de un nombre único que indique su localización y que sea representativo.

La composición del nombre de objetos o fuentes nuevos cambia dependiendo de a cuál aplicación pertenece.

---

### 4.2 Composición del Nombre según Tipo de Aplicación

#### a) Para Aplicaciones con Código de Dos Caracteres

Si el objeto o fuente se crea en una biblioteca cuya aplicación es de dos caracteres, debe respetarse el siguiente formato:

```
AA T nnn SS
│  │ │   │
│  │ │   └─ Sufijo (puede extenderse hasta cuatro caracteres)
│  │ └─ Consecutivo
│  └─ Tipo de objeto o fuente
└─ Aplicación
```

**Ejemplos:**

- AUP105
- CAP012NI
- TCP102
- TCP102A

#### b) Para Aplicaciones con Código de Cuatro Caracteres

Si el objeto o fuente se crea en una biblioteca cuya aplicación es de cuatro caracteres, debe respetarse el siguiente formato:

```
A AAA T nnn SS
│ │   │ │   │
│ │   │ │   └─ Sufijo
│ │   │ └─ Consecutivo
│ │   └─ Tipo de objeto/fuente
│ └─ Aplicación
└─ Área a la que pertenece la aplicación
```

**Ejemplos:**

- BSEGP001
- BSEGF001
- CBNXC001
- CBNXF003

---

#### c) Detalle de la Composición del Nombre

##### Aplicación
Es el código de aplicación. Puede ser de dos o cuatro caracteres según se explicó antes.

##### Tipo de Objeto/Fuente
Contiene un carácter que indica el tipo de objeto o miembro fuente:

| Código | Tipo | Descripción |
|--------|------|-------------|
| **A** | Archivos físicos y lógicos | Tanto para fuentes en DDS como para fuentes en SQL. Los archivos lógicos deben tener el mismo consecutivo del archivo físico al que pertenecen, excepto cuando pertenecen a varios archivos físicos. Las excepciones para archivos lógicos nuevos se permiten cuando se trata de interfaz con software de terceros. |
| **R** | Formato de registro | Para archivos físicos y lógicos. Ver más detalles en la sección "Observaciones sobre archivos BD". |
| **T** | Triggers | Deben tener el mismo consecutivo que el archivo físico al que pertenecen y residir en la misma biblioteca. Se pueden hacer en SQL o en cualquier lenguaje de programación. |
| **C** | Programas CLP | Programas en lenguaje de control CLP. |
| **P** | Programas | En cualquier lenguaje, excepto CLP. Cuando es programa de mantenimiento (ABC) a un archivo, usar el consecutivo del archivo si está disponible. Las pantallas en SNAP se llaman igual que el programa (limitante de SNAP). |
| **V** | Programas de servicio ILE | Objetos tipo *SRVPGM, incluyendo procedimientos almacenados en SQL. |
| **O** | Módulos ILE | Objetos tipo *MODULE. Para módulos en diferentes lenguajes (RPGLE, CLLE, Cobol-LE, etc.) usar el sufijo para diferenciar (ej: CL, CB, C). |
| **F** | Archivos de pantalla | Excepto los creados en SNAP. Las pantallas deben tener el mismo consecutivo que el programa al que pertenecen. |
| **I** | Archivos de impresora | Reportes. Los archivos de imprensora deben tener el mismo consecutivo que el programa al que pertenecen. |
| **M** | Menús | Tipos *MENU o *PGM CLP/CLLE con FSTMNU. |
| **D** | Áreas de datos | Objetos tipo *DTAARA. |
| **Q** | Colas de datos | Objetos tipo *DTAQ. |
| **Y** | Queries | Objetos tipo *QRY o *QMQRY. |
| **L** | Paneles | Objetos tipo *PNL. |

##### Miembros sin Objeto

| Código | Tipo | Descripción |
|--------|------|-------------|
| **S** | Scripts SQL | Fuentes para integridad referencial y manipulación de datos (no incluye tablas, vistas, índices, triggers ni procedimientos almacenados). Fuentes SRT para "sorts" en FMTDTA. Fuentes OCL36. |
| **X** | Rutinas o definiciones | Fuentes a incluir en RPG, RPT, RPGLE, RPT36, etc., con /COPY o /INCLUDE. |

> **Nota:** Para objetos cuyo tipo no está definido aquí, hay libertad de nombrarlos, siempre que no choquen con estándares ya definidos.

##### Consecutivo

Es un número consecutivo único para cada objeto dentro de una biblioteca. La asignación se realiza por la Unidad de Apoyo al Desarrollo, registrada en la herramienta de administración de configuración (control de versiones).

##### Sufijo

Este sufijo se usa solo si se requiere. Son caracteres de la 'A' a la 'Z' y números del '0' al '9'. El mínimo es una posición y el máximo cuatro.

Se usa para diferenciar objetos relacionados con otro objeto o fuente. Ejemplos:
- Programas relacionados a un archivo físico
- Pantallas y archivos de impresora relacionados con un programa
- Áreas de datos y colas relacionadas con un programa

**Ejemplo de objetos relacionados:**

| Objeto | Descripción |
|--------|-------------|
| AEA001 | Archivo físico o tabla |
| AEA00101 | Archivo lógico de AEA001 |
| AEP001 | Programa de mantenimiento de AEA001 |
| AEF001 | Pantalla de AEP001 |
| AEI001 | Archivo de impresora |
| AEP001C | Programa de consulta |
| AEF001C | Pantalla de programa de consulta |

###### Sufijos por País

Para diferenciar copias de objeto/fuente por país (excepciones):

| Sufijo | País |
|--------|------|
| GU | Guatemala |
| HO | Honduras |
| SA | El Salvador |
| NI | Nicaragua |
| CR | Costa Rica |
| FL | Florida |
| PA | Panamá |

Estas copias deberían moverse a la biblioteca exclusiva de cada país (pero no es obligatorio). El nombre debe mantenerse con el estándar. Por ejemplo, en GUCLMIBPRO se puede tener DEP229GU.

###### Pruebas Unitarias con RPGUNIT

Los fuentes con sufijo **U** contienen código de pruebas unitarias con RPGUNIT. Cada RPGUNIT se crea para probar un programa determinado. Esta relación debe indicarse en la solicitud de retención de fuentes. 

**Ejemplo:** CMQAU001 prueba el componente CMQACCES

Para archivos lógicos usar esta excepción:

- **Para banca:** Ln (donde L es una constante y 'n' el consecutivo 'A' a 'Z' y/o '0' a '9')
- **Para tarjetas:** nn (del 01 al 99)

---

### 4.3 Nombres de Componentes de Arquitectura Orientada a Objetos

#### a) Gestor Principal

**Estándar de nombre:**

```
AAA GP
│   │
│   └─ Constante GP (Gestor Principal)
└─ Acrónimo de la aplicación
```

**Ejemplo:**

El gestor principal de la Aplicación Centro de Información de Clientes es: **CIFGP**

- CIF = Centro de Información de Clientes
- GP = Gestor Principal

**Objetivo:**
Recibir todas las peticiones HTTP del usuario, además determina el SubGestor que atenderá dicha petición.

---

#### b) SubGestor

**Estándar de nombre:**

```
AAA SG CCCCC
│   │  │
│   │  └─ Acrónimo de la Clase
│   └─ Constante SG (SubGestor)
└─ Acrónimo de la aplicación
```

**Ejemplos:**

| SubGestor | Concepto |
|-----------|----------|
| BCOSGACC | Sub Gestor de Cuentas |
| BCOSGCUS | Sub Gestor de Clientes |
| BCOSGMTCUS | Sub Gestor de Multi Clientes |

**Objetivo:**
Recuperar parámetros para invocación del servicio, verificar niveles de seguridad (autorización) y hacer la invocación del servicio. El SubGestor es la puerta de entrada a servicios relacionados, exponiendo servicios de un único concepto de negocio. Se debe implementar un SubGestor distinto según la naturaleza del canal de acceso.

---

#### c) Objeto o Clase

**Estándar de nombre:**

```
AAA CCCCC
│   │
│   └─ Acrónimo de la Clase
└─ Acrónimo de la aplicación
```

**Ejemplos de Clases:**

- BCOCUS
- BCOMULTCUS
- BCOACC

> **Nota:** El acrónimo de la clase no debe exceder 5 letras.

**Ejemplos de abreviaturas:**

| Concepto | Acrónimo |
|----------|----------|
| Cuenta | ACC |
| Cliente | CUS |
| Seguridad | SEC |
| Usuario | USER |
| Tarjeta | CARD |

**Objetivo:**
Implementar cada uno de los servicios relacionados con el concepto de negocio (Clase). Cada servicio está implementado en un método accedido desde un SubGestor respectivo. La llamada a cada método se realiza utilizando parámetros RPG.

---

#### d) BEAN o Tabla Externalizada

**Estándar de nombre:**

Mismo nombre que el archivo o tabla externalizado*

*Técnica que encapsula el acceso a los archivos, derivada del paradigma orientado a objetos.

**Objetivo:**
Encapsular el acceso a la base de datos.

---

#### e) Programas de Servicio o Paquetes

**Estándar de nombre:**

```
AAA CCCCC
│   │
│   └─ Acrónimo de la Clase
└─ Acrónimo de la aplicación
```

**Ejemplos:**

- BCOCUS
- BCOMULTCUS
- BCOACC

Para programas de servicio de archivos externalizados, la nomenclatura debe ser: **nombre de la tabla**.

**Objetivo:**
Contener y exponer todos los servicios disponibles de una clase.

---

#### f) Nombres de Tablas en Paradigma de Objetos

**Estándar de nombre:**

```
AAA TTTTT CC
│   │     │
│   │     └─ Consecutivo numérico
│   └─ Acrónimo significativo del contenido
└─ Acrónimo de la aplicación
```

Composición: Acrónimo de aplicación + Acrónimo significativo + consecutivo.

**Ejemplos:**

- CNTUSERS01
- CNTSRVS01
- CNTAPL02

---

### 4.4 Estándares de CORE de Banco

Las aplicaciones de CORE de Banco se encuentran distribuidas en las bibliotecas BCO, ISS, RL, BPA, COMUSR, EIBS, TFBS, BSI y PYM

---

## 5. Guía de Consulta de Nombres Estándar mediante Procedimientos Almacenados

Para componer correctamente el nombre de cualquier objeto nuevo (tabla, índice, trigger, procedure, función, programa, etc.), BAC Credomatic cuenta con **procedimientos almacenados oficiales** en la biblioteca `LIBMHV` que exponen el catálogo de AVPs (códigos de aplicación) y las 867 abreviaturas oficiales registradas.

> **Regla fundamental:** NUNCA hardcodear abreviaturas ni AVPs. Siempre consultarlos dinámicamente antes de componer un nombre.

---

### 5.1 Consultar el AVP (Código de Aplicación)

El AVP identifica a qué aplicación pertenece un objeto. Se consulta con:

```sql
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'nombre_aplicacion');
```

**Parámetros:**
| Posición | Tipo | Descripción |
|----------|------|-------------|
| 1 | VARCHAR | Código AVP directo (si ya lo conocés, pasá el código y dejá el segundo vacío) |
| 2 | VARCHAR | Nombre o descripción parcial de la aplicación para búsqueda |

**Ejemplos de uso:**

```sql
-- Buscar por nombre de aplicación
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'bridger');
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'seguridad');
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'tarjetas');

-- Buscar por código AVP directo
CALL LIBMHV.UBDP_CONSULTA_AVP('BBRI', '');
CALL LIBMHV.UBDP_CONSULTA_AVP('BSEG', '');
```

#### Regla de Truncamiento del AVP (4 → 3 caracteres)

El AVP completo tiene 4 caracteres, pero para la composición de nombres de objetos se trunca a 3 omitiendo el **primer carácter** (que indica el área):

| AVP Completo (4) | Primer Char (Área) | AVP Truncado (3) | Uso |
|-------------------|--------------------|--------------------|-----|
| **B**BRI | B = Banca | BRI | Nombres de objetos |
| **T**BRI | T = Tarjetas | BRI | Nombres de objetos |
| **C**ENB | C = Corporativo | ENB | Nombres de objetos |
| **B**BAC | B = Banca | BAC | Nombres de objetos |
| **B**SEG | B = Banca | SEG | Nombres de objetos |

> **Nota:** El primer carácter del AVP indica el área (B=Banca, T=Tarjetas, C=Corporativo, W=Web) y coincide con el esquema documentado en la sección 1.2 de este documento para aplicaciones nuevas.

---

### 5.2 Consultar Abreviaturas Oficiales

BAC mantiene un catálogo de **867 abreviaturas oficiales** para la composición de nombres. Se consultan por concepto de negocio:

```sql
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'termino_de_negocio');
```

**Parámetros:**
| Posición | Tipo | Descripción |
|----------|------|-------------|
| 1 | VARCHAR | Abreviatura directa (si ya la conocés) |
| 2 | VARCHAR | Término de negocio a buscar (nombre descriptivo) |

**Ejemplos de uso:**

```sql
-- Buscar abreviatura por concepto de negocio
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'cliente');
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'cuenta');
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'transaccion');
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'moneda');
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'parametro');
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'bitacora');
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'estado');

-- Buscar por abreviatura directa
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('MST', '');
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('TRN', '');
```

> **Importante:** Las abreviaturas oficiales se almacenan en la tabla `LIBMHVTMP.HBDAABRDID`. No usar la tabla `LIBMHV.ABREVIA` ya que está desactualizada.

#### Abreviaturas Comunes de Referencia

Estas son algunas abreviaturas frecuentes. **Siempre verificar con el procedimiento almacenado** antes de usarlas:

| Concepto | Abreviatura | Concepto | Abreviatura |
|----------|-------------|----------|-------------|
| Cliente | CLI | Cuenta | CTA |
| Transacción | TRN | Moneda | MON |
| Parámetro | PAR | Maestro | MST |
| Bitácora | BIT | Estado | EST |
| Código | COD | Tipo | TIP |
| Monto | MTO | Saldo | SLD |
| Usuario | USR | Fecha | FEC |
| Descripción | DSP | Canal | CAN |

---

### 5.3 Validar el Nombre Compuesto

Una vez compuesto el nombre con AVP + Tipo + Abreviaturas, se **valida** con:

```sql
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('AVP', 'TIPO', 'ABR1', 'ABR2');
```

**Parámetros:**
| Posición | Tipo | Descripción |
|----------|------|-------------|
| 1 | VARCHAR | AVP truncado (3 caracteres) |
| 2 | CHAR(1) | Tipo de objeto: A=Tabla, I=Índice, T=Trigger, P=Procedure, F=Función |
| 3 | VARCHAR | Primera abreviatura (3 caracteres) |
| 4 | VARCHAR | Segunda abreviatura (3 caracteres) |

**Ejemplos de uso:**

```sql
-- Validar nombre para una tabla de maestro de transacciones (app Bridger)
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('BRI', 'A', 'MST', 'TRN');
-- Resultado esperado: BRIAMSTTRN (válido/inválido)

-- Validar nombre para un índice de cuentas de clientes
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('BRI', 'I', 'CTA', 'CLI');
-- Resultado esperado: BRIICTACLI

-- Validar nombre para un stored procedure de consulta de saldos
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('BAC', 'P', 'CON', 'SLD');
-- Resultado esperado: BACPCONSLD

-- Validar nombre para un trigger de bitácora de estados
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('SEG', 'T', 'BIT', 'EST');
-- Resultado esperado: SEGTBITEST
```

#### Tipos de Objeto Soportados por UBDP_VALIDAR_NOMBRES

| Tipo | Descripción | Fórmula Resultante |
|------|-------------|--------------------|
| A | Tabla (Archivo Físico) | [AVP(3)][A][ABR1(3)][ABR2(3)] |
| I | Índice | [AVP(3)][I][ABR1(3)][ABR2(3)] |
| T | Trigger | [AVP(3)][T][ABR1(3)][ABR2(3)] |
| P | Procedure (SQL o RPG) | [AVP(3)][P][ABR1(3)][ABR2(3)] |
| F | Función / UDF | [AVP(3)][F][ABR1(3)][ABR2(3)] |

> **Nota:** Vistas SQL, secuencias y campos **NO** pasan por `UBDP_VALIDAR_NOMBRES`. Su nomenclatura se rige por reglas distintas (ver sección 4.2).

---

### 5.4 Verificar Existencia en el Catálogo DB2

Antes de crear un objeto nuevo, verificá que el nombre no esté en uso:

```sql
-- Para tablas, vistas y archivos físicos
SELECT TABLE_NAME, TABLE_SCHEMA, TABLE_TEXT, TABLE_TYPE
FROM QSYS2.SYSTABLES
WHERE TABLE_SCHEMA = 'BIBLIOTECA_PRODUCCION'
  AND TABLE_NAME = 'NOMBRE_COMPUESTO';

-- Para índices
SELECT INDEX_NAME, TABLE_SCHEMA, TABLE_NAME
FROM QSYS2.SYSINDEXES
WHERE TABLE_SCHEMA = 'BIBLIOTECA_PRODUCCION'
  AND INDEX_NAME = 'NOMBRE_COMPUESTO';
```

#### Buscar Objetos Similares por Descripción

Para evitar crear objetos duplicados, buscá por descripción antes de diseñar:

```sql
SELECT TABLE_NAME, TABLE_SCHEMA, TABLE_TEXT, TABLE_TYPE
FROM QSYS2.SYSTABLES
WHERE TABLE_TEXT IS NOT NULL
  AND (UPPER(TABLE_TEXT) LIKE UPPER('%keyword1%')
    OR UPPER(TABLE_TEXT) LIKE UPPER('%keyword2%'))
  AND TABLE_TYPE IN ('T', 'V', 'P')
  AND TABLE_SCHEMA NOT LIKE 'Q%'
ORDER BY TABLE_NAME
FETCH FIRST 10 ROWS ONLY;
```

---

### 5.5 Flujo Completo: Ejemplo Paso a Paso

**Requerimiento:** Crear una tabla de bitácora de transacciones para la aplicación Bridger en la biblioteca `BBRIDAT`.

#### Paso 1 — Obtener AVP

```sql
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'bridger');
-- Resultado: BBRI (Banca - Bridger)
-- AVP truncado: BRI (se omite la B de Banca)
```

#### Paso 2 — Obtener Abreviaturas

```sql
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'bitacora');
-- Resultado: BIT

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'transaccion');
-- Resultado: TRN
```

#### Paso 3 — Componer y Validar Nombre

```
Fórmula: [AVP(3)][TIPO(1)][ABR1(3)][ABR2(3)]
Resultado: BRI + A + BIT + TRN = BRIABITTRN
```

```sql
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('BRI', 'A', 'BIT', 'TRN');
-- Valida que BRIABITTRN cumple con las reglas de nomenclatura
```

#### Paso 4 — Verificar que No Exista

```sql
SELECT TABLE_NAME FROM QSYS2.SYSTABLES
WHERE TABLE_SCHEMA = 'BBRIDAT'
  AND TABLE_NAME = 'BRIABITTRN';
-- Si no retorna filas: el nombre está disponible
```

#### Paso 5 — Buscar Similares (Opcional pero Recomendado)

```sql
SELECT TABLE_NAME, TABLE_SCHEMA, TABLE_TEXT
FROM QSYS2.SYSTABLES
WHERE TABLE_TEXT IS NOT NULL
  AND (UPPER(TABLE_TEXT) LIKE '%BITACORA%'
    OR UPPER(TABLE_TEXT) LIKE '%TRANSACCION%')
  AND TABLE_SCHEMA = 'BBRIDAT'
ORDER BY TABLE_NAME;
```

---

### 5.6 Resumen de Procedimientos Disponibles en LIBMHV

| Procedimiento | Propósito | Ejemplo |
|---------------|-----------|---------|
| `UBDP_CONSULTA_AVP` | Buscar código de aplicación (AVP) | `CALL LIBMHV.UBDP_CONSULTA_AVP('', 'bridger')` |
| `UBDP_CONSULTA_ABREVIATURAS` | Buscar abreviaturas oficiales por concepto | `CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'cliente')` |
| `UBDP_VALIDAR_NOMBRES` | Validar nombre compuesto antes de crear | `CALL LIBMHV.UBDP_VALIDAR_NOMBRES('BRI', 'A', 'MST', 'TRN')` |

> **Regla:** Los tres procedimientos deben ejecutarse **SIEMPRE** antes de crear cualquier objeto nuevo. Primero se obtiene el AVP, luego las abreviaturas, y finalmente se valida el nombre compuesto.

