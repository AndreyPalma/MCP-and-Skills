# Guía de Directivas de Compilación ILE RPG
## `/include`, `/define`, `/undefine`, `/if`, `/eof`

---

## 1. ¿Qué hace el compilador con un `/include`?

El compilador **copia y pega** el contenido del archivo en ese punto del fuente,
antes de iniciar el análisis sintáctico. No es una referencia en tiempo de
ejecución — es sustitución de texto literal en tiempo de compilación.

```
Módulo A (lo que escribís)          Lo que el compilador VE
────────────────────────────        ────────────────────────────
Dcl-S miVar Char(10);               Dcl-S miVar Char(10);
/include MILIB/QSRCTXT,ESTRUCTURAS  Dcl-DS dsRequest Qualified template;
Dcl-Proc MiProcedimiento;             campo1 Char(20) Inz;
  ...                               End-DS;
End-Proc;                           Dcl-Proc MiProcedimiento;
                                      ...
                                    End-Proc;
```

**Consecuencia directa:** si el mismo archivo se incluye dos veces dentro del
mismo módulo (directa o indirectamente), el compilador verá cada declaración
dos veces y fallará con:

```
RNF7031: The definition of <nombre> duplicates a previous definition.
```

---

## 2. Las directivas disponibles

| Directiva | Función | Disponible desde |
|-----------|---------|-----------------|
| `/include` | Inserta el contenido de otro archivo en este punto | V3R6+ |
| `/define NOMBRE` | Activa un símbolo lógico (interruptor = ON) | V3R6+ |
| `/undefine NOMBRE` | Desactiva un símbolo (interruptor = OFF) | V3R6+ |
| `/if defined(NOMBRE)` | Compila el bloque solo si el símbolo está activo | V3R6+ |
| `/if not defined(NOMBRE)` | Compila el bloque solo si el símbolo NO está activo | V3R6+ |
| `/else` | Bloque alternativo del `/if` | V3R6+ |
| `/elseif defined(NOMBRE)` | Condición adicional en cascada | V3R6+ |
| `/endif` | Cierra un bloque `/if` | V3R6+ |
| `/eof` | Detiene la compilación del archivo en ese punto | V3R6+ |

---

## 3. Los tres patrones principales

### Patrón A — Include Guard (protección propia)

El archivo se protege a sí mismo contra doble inclusión.

```rpg
**FREE
// ── BADI05.TXT ──────────────────────────────────────────────────────────

/if defined(BADI05_defined)   // ¿Ya fui incluido antes?
/eof                          // Sí → detener aquí, no compilar nada más
/else
/define BADI05_defined        // No → marcarme como "ya incluido"
/endif

// A partir de aquí, el contenido siempre se compila completo:
Dcl-DS serviceParmsT Qualified template;
  accountNumber Zoned(9) Inz;
End-DS;

Dcl-Pr BADI05_ConsultaParticipantes Ind;
  pServiceParms LikeDS(serviceParmsT);
End-Pr;
```

**¿Cuándo usarlo?**
- El archivo siempre se necesita **completo** (no hay partes opcionales).
- El archivo puede ser incluido desde **múltiples rutas** dentro del mismo módulo
  (inclusión transitiva: A incluye B, A incluye C, C también incluye B).
- Es el patrón más simple y menos propenso a errores.

**Diagrama de flujo en compilación:**
```
Primera inclusión:           Segunda inclusión:
──────────────────           ──────────────────
/if defined(BADI05)?         /if defined(BADI05)?
  → NO                         → SÍ
/define BADI05_defined         /eof  ← compilador para aquí
[compila todo el archivo]      [no compila nada]
```

---

### Patrón B — Activación Selectiva (el módulo elige qué necesita)

El archivo tiene secciones opcionales. El módulo que lo incluye activa
previamente solo las secciones que necesita.

```rpg
// ── BEMP01.rpgleinc ─────────────────────────────────────────────────────
**FREE

/if defined(dsEstructuraEntrada)
Dcl-DS dsRequestData Qualified template;
  numeroCIF     Packed(15:0) Inz;
  rubro         Packed(5:0)  Inz;
End-DS;
/endif

/if defined(dsEstructuraRespuesta)
Dcl-DS dsResponseData Qualified template;
  codigoResultado      Char(7)      Inz;
  descripcionResultado Varchar(500) Inz;
End-DS;
/endif

/if defined(prototipoCapaNegocio)
Dcl-Pr Logica_Negocio_BEMP01 Ind;
  pServiceParms  LikeDS(dsRequestData);
  pResponse      LikeDS(dsResponseData);
  pError         Char(7);
End-Pr;
/endif
```

```rpg
// ── BEMP01CNTL.sqlrpgle — El controlador activa lo que necesita ──────────
/define dsEstructuraEntrada     // ← necesito la DS de entrada
/define dsEstructuraRespuesta   // ← necesito la DS de salida
/define prototipoCapaNegocio    // ← necesito el prototipo
// NO define dsBitacoraServicio // ← no necesito la DS de bitácora
/include BBCOSRC/QSRCTXT,BEMP01
```

```rpg
// ── BITAR99999.sqlrpgle — El DAO de bitácora activa solo su sección ──────
/define dsBitacoraServicio      // ← solo necesito la DS de bitácora
/include BBCOSRC/QSRCTXT,BEMP01
```

**¿Cuándo usarlo?**
- El archivo contiene **estructuras o prototipos opcionales** que no todos los
  módulos necesitan.
- Distintos módulos (controlador, lógica, DAO) consumen **subconjuntos distintos**
  del mismo archivo.
- Se quiere evitar declarar múltiples archivos include, uno por cada combinación.

**Limitación importante:** este patrón **no protege contra doble inclusión**.
Si un módulo incluye el mismo archivo dos veces con `/define` activo en ambas,
habrá error de símbolo duplicado.

---

### Patrón C — Combinado (Guard + Selectivo)

Combina la protección del include guard con la activación selectiva.
Es el patrón más robusto y recomendado para proyectos que crecen.

```rpg
// ── BEMP01.rpgleinc — Versión robusta ───────────────────────────────────
**FREE

// ── Guard global: protege contra doble inclusión del archivo completo ──
/if defined(BEMP01_INC)
/eof
/endif
/define BEMP01_INC

// ── Secciones opcionales: el módulo elige qué necesita ─────────────────

/if defined(dsEstructuraEntrada)
Dcl-DS dsRequestData Qualified template;
  numeroCIF     Packed(15:0) Inz;
  rubro         Packed(5:0)  Inz;
End-DS;
/endif

/if defined(dsEstructuraRespuesta)
Dcl-DS dsResponseData Qualified template;
  codigoResultado      Char(7)      Inz;
  descripcionResultado Varchar(500) Inz;
End-DS;
/endif

/if defined(prototipoCapaNegocio)
Dcl-Pr Logica_Negocio_BEMP01 Ind;
  pServiceParms  LikeDS(dsRequestData);
  pResponse      LikeDS(dsResponseData);
  pError         Char(7);
End-Pr;
/endif
```

**¿Cuándo usarlo?**
- El archivo es grande y tiene secciones opcionales **Y** es referenciado
  por includes transitivos (un include que a su vez incluye este archivo).
- Proyectos con arquitecturas de varios niveles (controlador → lógica → DAO →
  beans) donde la misma estructura base puede llegar por múltiples rutas.

---

## 4. ¿Para qué sirve `/undefine`?

`/undefine` apaga un símbolo que estaba encendido. Su único caso de uso real
es cuando necesitás incluir el **mismo archivo dos veces** en el mismo módulo
con distinto comportamiento en cada inclusión.

```rpg
// Caso REAL donde /undefine tiene sentido:
// Necesito declarar la misma estructura para dos contextos distintos
// usando el mismo archivo template.

/define dsEstructuraEntrada
/include BBCOSRC/QSRCTXT,BEMP01     // Primera inclusión → dsRequestData v1
/undefine dsEstructuraEntrada        // Apagar el interruptor

/define dsEstructuraEntrada          // Volver a encender
/include BBCOSRC/QSRCTXT,BEMP02     // Segunda inclusión → dsRequestData v2
```

**En la práctica esto es extremadamente raro.** En el 99% de los proyectos
de servicios RPG, `/undefine` no cumple ninguna función y solo agrega ruido
visual al código.

---

## 5. Tabla comparativa de patrones

| Criterio | Patrón A: Guard | Patrón B: Selectivo | Patrón C: Combinado |
|----------|----------------|---------------------|---------------------|
| Protege contra doble inclusión | ✅ Sí | ❌ No | ✅ Sí |
| Permite incluir solo partes | ❌ No | ✅ Sí | ✅ Sí |
| Complejidad de implementación | Baja | Media | Media |
| Complejidad para el módulo consumidor | Baja (solo `/include`) | Alta (requiere `/define` previos) | Alta (requiere `/define` previos) |
| Seguro ante inclusión transitiva | ✅ Sí | ❌ No | ✅ Sí |
| Recomendado cuando... | Siempre se necesita todo | Distintos módulos necesitan partes distintas | Arquitecturas complejas con includes transitivos |

---

## 6. Árbol de decisión — ¿Qué patrón usar?

```
¿El archivo tiene secciones opcionales
(no todos los módulos necesitan todo)?
│
├─ NO → Patrón A (Include Guard con /eof)
│       Simple, seguro, sin riesgo de doble inclusión.
│
└─ SÍ → ¿El proyecto tiene inclusión transitiva?
         (un include que incluye este mismo archivo)
         │
         ├─ NO → Patrón B (Activación Selectiva)
         │        Cada módulo activa con /define lo que necesita.
         │        Sin /undefine.
         │
         └─ SÍ → Patrón C (Guard + Selectivo)
                  Include guard al inicio + secciones /if defined.
                  Máxima seguridad y flexibilidad.
```

---

## 7. Reglas de oro

```
1. NUNCA uses /undefine a menos que incluyas el mismo archivo
   dos veces intencionalmente en el mismo módulo.

2. Si el archivo siempre se consume completo → Patrón A (/eof).
   Es el más simple y el más seguro.

3. Si distintos módulos necesitan partes distintas del mismo archivo
   → Patrón B o C. Activa con /define ANTES del /include.

4. En arquitecturas de múltiples capas (controlador/lógica/DAO/beans)
   → Patrón C. La inclusión transitiva es solo cuestión de tiempo.

5. Nunca dependas de "el orden de los includes evitará el problema".
   El día que refactorices, el orden puede cambiar.

6. Un símbolo /define persiste durante toda la compilación del módulo.
   No se resetea entre /include.
```

---

## 8. Ejemplo real de inclusión transitiva (el problema silencioso)

Este es el escenario que más frecuentemente causa problemas inesperados en
proyectos que crecen sin include guards:

```
BEMP01.sqlrpgle (Lógica de negocio)
  ├─ /include BBCOSRC/QSRCTXT,BEMP01           ← incluye dsRequestData
  └─ /include BBCOSRC/QSRCTXT,CUMAINFEMP        ← incluye CUMAINFEMP.rpgleinc
                                                     └─ (adentro) /include BBCOSRC/QSRCTXT,BEMP01
                                                              ↑
                                                   Segunda vez → ERROR RNF7031
```

Con **Patrón A** en BEMP01.rpgleinc, la segunda inclusión llega al `/eof`
y se detiene silenciosamente sin error.

Con **Patrón B puro** (sin guard), el compilador falla con símbolo duplicado
solo cuando el proyecto crece y aparece esa inclusión transitiva — no
cuando se desarrolló originalmente.

---

## 9. Resumen aplicado por tipo de archivo

| Tipo de archivo | Patrón recomendado | Justificación |
|---|---|---|
| Include con estructuras únicas (DS, PR simples) | **A — Guard** `/eof` | Siempre se necesita completo, riesgo de transitiva |
| Include con múltiples secciones opcionales para capas distintas | **C — Combinado** | Flexibilidad + seguridad |
| Include de utilitarios externos (YAJLH, CEXCEPTION, PGMSTSH) | **A — Guard** `/eof` | Siempre completo, definitivamente transitivo |
| Include pequeño de un solo bloque | **A — Guard** `/eof` | Simplicidad, overhead mínimo |
