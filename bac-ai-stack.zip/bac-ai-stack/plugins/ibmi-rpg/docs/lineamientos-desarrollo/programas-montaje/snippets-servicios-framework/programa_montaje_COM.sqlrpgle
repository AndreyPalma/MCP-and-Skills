**free

//============================================================================*
// @name.....:  Nombre del fuente                                        
// @objective:  Descripción del programa de montaje                      
// @changes..:  Cambios que se hicieron en la programación               
// @version..:  Numero de pase                                           
// @team.....:  Nombre del equipo                                         
// @author...:  Nombre del autor                                          
// @since....:  Fecha                                                     
//============================================================================*

dcl-pr qCmdExc extpgm('QCMDEXC');
    @i_command char(200) const Options(*varSize);
    @i_commandLength packed(15:5) const;
end-pr ;

// Variables, constantes y estructuras de datos globales.
dcl-c  INSTALL  const('I');
dcl-c  UNINSTALL  const('D');
dcl-s command char(500) inz(*blanks);
dcl-s message char(50) inz(*blanks);

// Prototipo principal.
dcl-pi  *n;
    inp_process  char(1)  const;
end-pi;

//Lógica del programa.
if inp_process = INSTALL;

    // MATRICULA DE MENSAJES NUEVOS DE ERROR
    command = 'ADDMSGD MSGID(ID Mensaje de error ) MSGF(Biblioteca mensaje de error/Nombre archivo de mensajes de error) ' +
          'MSG(''Texto de mensaje de error'')';
    monitor;
        qCmdExc(command :%len(command));
    on-Error;
        message = 'Error al agregar el mensaje GES0076';
        dsply (message);
    endMON;

    // MATRICULA DEL SERVICIO
    exec sql
    INSERT INTO cmqmdat.MQA034
            (CODIGO_OPERACION,NOMBRE_SERVICIO,DESCRIPCION,ALCANCE,ESTADO,
             TIPO_SERVICIO,
             TIEMPO_EXPIRACION_MENSAJE,PRIORIDAD,CONTROLADOR,
             BIBLIOTECA_CONTROLADOR,GUARDA_REQUEST,GUARDA_RESPUESTA,
             RESPONDE_CON_LLAVE,SOLO_REQUEST,FECHA_CREACION)
VALUES      ('Codigo servicio','Nombre del servicio',
             'Nombre largo del servicio',
             'REGIONAL','1','BASIC',50,0,'Nombre controlador servicio','Biblioteca producción controlador ','1','1','1',
             '0',CURRENT DATE);


    // REGISTRO DE BIBLIOTECA DECMLIBPRO EN LA TABLA TCA063
    exec sql
    INSERT INTO tccmdatpro.TCA063
            (TCAAPL,TCAOPC,TCASE2,TCABIB,TCAC03)
VALUES      ('Nombre job','Opcion',(SELECT Max(TCASE2) + 10
                              FROM   tccmdatpro.TCA063
                              WHERE  TCAAPL = 'Nombre job'
                AND TCAOPC = 'Opcion'),'Nombre biblioteca','Descripción del agregado'
            );


    // REGISTRO DE BITÁCORA EN HOUSEKEEPING
    exec sql
    insert into CHSKPDAT.CHSKPA003(
           HSKPLIBT, HSKPTAB, HSKPFRE, HSKPNEXTEX, HSKPMISSTM, HSKPDELSTM)
    values('TBITDAT', 'Nombre bitacora', 1, CURRENT DATE, ' ',
           'WHERE DATE(FECREQ) <= (CURRENT_DATE - 1 MONTH) AND CODAPL = Codigo servicio');


elseif inp_process = UNINSTALL;

    // ELIMINA LOS MENSAJES DE ERROR
    command = 'RMVMSGD MSGID(ID Mensaje de error) MSGF(Biblioteca mensaje de error/Nombre archivo de mensajes de error)';
    monitor;
        qCmdExc(command :%len(command));
    on-Error;
        message = 'Error al remover el mensaje ID Mensaje de error';
        dsply (message);
    endMON;

    // ELIMINA LA MATRÍCULA DEL SERVICIO
    exec sql
    delete CMQMDAT.MQA034
    where OPCODE = 'Codigo servicio';

    // ELIMINA LA BIBLIOTECA DECMLIBPRO DE LA TABLA TCA063
    exec sql
    delete TCCMDATPRO.TCA063
    where TCAAPL = 'Nombre job'
      and TCAOPC = 'Opcion'
      and TCABIB = 'Nombre biblioteca';

    // ELIMINA EL REGISTRO DE BITÁCORA EN HOUSEKEEPING
    exec sql
  delete CHSKPDAT.CHSKPA003
  where HSKPLIBT = 'TBITDAT'
    and HSKPTAB = 'Nombre bitacora';

endif;

*inlr = *on;