# Lineamientos: Manejo de Excepciones en RPG ILE

## Introducción

Todo desarrollo nuevo en RPG ILE **debe** implementar el patrón corporativo de manejo de excepciones basado en el servicio `CEXCEPTION`. Este patrón garantiza que los errores sean comunicados de forma explícita y consistente entre las capas de la aplicación, eliminando la ambigüedad de los códigos de retorno booleanos.

---

## Problema que resuelve

Cuando un procedimiento retorna `*OFF`, el código que lo invoca no puede determinar la causa del fallo. Ejemplo:

```rpgle
if CEXCEPAL_GETRECORD(opcode);
  dsply 'Registro existe en la tabla';
else;
  // ¿Registro no encontrado? ¿Tabla inexistente? ¿Error de SQL? Imposible saberlo.
  dsply 'Registro no encontrado';
endif;
```

El patrón de excepciones resuelve esto lanzando una excepción descriptiva desde la capa de acceso a datos, de modo que el consumidor pueda capturarla e inspeccionarla con precisión.

---

## Componentes del patrón

### `CEXCEPTION` — SRVPGM corporativo

Requiere el binding directory `CEXCEPBNDD` y los includes:

```rpgle
/INCLUDE CSYSTSRC/QSRCTXT,CEXCEPTION
```

| Procedimiento | Rol |
|---|---|
| `CEXCEPTION_throwNewException(msgId : msgFile)` | Lanza una excepción identificada por un mensaje |
| `CEXCEPTION_catchException()` | Captura la excepción activa dentro de un bloque `ON-ERROR` |
| `CEXCEPTION_getMessageId()` | Retorna el ID del mensaje de la excepción capturada |
| `CEXCEPTION_getMessageText()` | Retorna el texto descriptivo de la excepción capturada |

### Message Files

Los mensajes de error deben estar registrados en un message file dedicado al programa o servicio. El message file debe registrarse en la tabla `CSYSTDAT/CTOOLSA001`:

```sql
INSERT INTO CSYSTDAT.CTOOLSA001(NOMMSGFILE, CODCLASIF, BIBMSGFILE, DESMSGFILE, COMENT, ESTATUS)
VALUES('NOMBRE_MSGFILE', '00002', 'BIBLIOTECA', 'Descripción del message file',
       'Comentario adicional', 'H');
```

Si la clasificación no existe, agregarla primero en `CSYSTDAT/CTOOLSA002`:

```sql
INSERT INTO CSYSTDAT.CTOOLSA002(CODCLASIF, DESCCLASIF)
VALUES('00002', 'NOMBRE_CLASIFICACION');
```

---

## Lineamiento 1: Lanzar excepciones desde la capa de acceso a datos

Cuando un procedimiento detecta una condición de error, **no debe retornar `*OFF` en silencio**. Debe lanzar una excepción con `CEXCEPTION_throwNewException` indicando el message ID y el message file correspondiente.

**Patrón obligatorio para procedimientos con SQL:**

```rpgle
dcl-proc ObtenerRegistro;
  dcl-pi *n ind;
    pOpCode char(5) const;
  end-pi;
  dcl-s recordFound ind inz(*off);

  exec sql
    select 1
      into :recordFound
      from MQA017
     where OPCODE = :pOpCode;

  select;
    when SQLSTATE = '00000';
      return *on;
    when SQLSTATE = '02000';
      CEXCEPTION_throwNewException('MSG0002' : 'CMSGFILE');
      return *off;
    other;
      CEXCEPTION_throwNewException('MSG0001' : 'CMSGFILE');
      return *off;
  endsl;

end-proc;
```

> Cada `SQLSTATE` posible debe tener su propio mensaje descriptivo. `'02000'` indica que no se encontró el registro; cualquier otro código indica un error de SQL (tabla inexistente, permisos, etc.).

---

## Lineamiento 2: Capturar excepciones en la capa consumidora

El bloque `MONITOR / ON-ERROR` es el único mecanismo aprobado para capturar excepciones. Dentro del `ON-ERROR` se debe llamar a `CEXCEPTION_catchException()` antes de consumir el mensaje.

**Patrón obligatorio:**

```rpgle
monitor;
  if ObtenerRegistro(opcode);
    // lógica cuando el registro existe
  endif;
on-error;
  CEXCEPTION_catchException();
  idError          = CEXCEPTION_getMessageId();
  descripcionError = %trim(CEXCEPTION_getMessageText());
  // comunicar el error al consumidor o a la bitácora
endmon;
```

> **Prohibido** dejar el bloque `ON-ERROR` vacío. Siempre debe ejecutar al menos `CEXCEPTION_catchException()`.

---

## Lineamiento 3: Propagar el error hacia arriba

En arquitecturas de servicio (controlador + lógica de negocio), la lógica de negocio captura la excepción y la propaga como parámetros de salida (`pError`, `pErrorDescription`) al controlador. El controlador es el responsable de construir la respuesta de error.

```rpgle
// Capa de lógica de negocio
monitor;
  // lógica del servicio
on-error;
  CEXCEPTION_catchException();
  pError            = CEXCEPTION_getMessageId();
  pErrorDescription = %trim(CEXCEPTION_getMessageText());
  return *off;
endmon;
```

```rpgle
// Capa controladora
status = LogicaNegocio(pServiceParms : pResponse : idError : errorDescription);

if not status;
  writeServiceErrorResponse(idError : errorDescription);
endif;
```

---

## Lineamiento 4: Usar constantes para los IDs de error

Los IDs de mensaje **no deben escribirse como literales** dispersos en el código. Deben declararse como constantes con nombre descriptivo.

```rpgle
// ✅ Correcto
dcl-c ERROR_TABLA_NO_ENCONTRADA  const('MSG0001');
dcl-c ERROR_REGISTRO_NO_EXISTE   const('MSG0002');

CEXCEPTION_throwNewException(ERROR_REGISTRO_NO_EXISTE : 'CMSGFILE');

// ❌ Incorrecto
CEXCEPTION_throwNewException('MSG0002' : 'CMSGFILE');
```

---

## Lineamiento 5: No manejar excepciones que no se pueden resolver

Un bloque `ON-ERROR` solo debe existir si el código tiene una acción real que tomar frente al error. Si la única acción posible es propagar el error, hacerlo explícitamente. No swallowear excepciones silenciosamente.

```rpgle
// ❌ Prohibido — exception swallowing
on-error;
endmon;

// ❌ Prohibido — mensaje genérico sin contexto
on-error;
  dsply 'Error';
endmon;

// ✅ Correcto — captura, registra y propaga
on-error;
  CEXCEPTION_catchException();
  pError = CEXCEPTION_getMessageId();
  pErrorDescription = %trim(CEXCEPTION_getMessageText());
  return *off;
endmon;
```

---

## Referencia rápida

| Situación | Acción |
|---|---|
| SQL no encuentra registro (`SQLSTATE 02000`) | `CEXCEPTION_throwNewException(ERROR_REGISTRO_NO_EXISTE : msgFile)` |
| Error de SQL inesperado | `CEXCEPTION_throwNewException(ERROR_FALLO_CONSULTA : msgFile)` |
| Validación de negocio falla | `CEXCEPTION_throwNewException(ERROR_VALIDACION : msgFile)` |
| Capturar en consumidor | `MONITOR / ON-ERROR + CEXCEPTION_catchException()` |
| Obtener ID del error capturado | `CEXCEPTION_getMessageId()` |
| Obtener texto del error capturado | `CEXCEPTION_getMessageText()` |
