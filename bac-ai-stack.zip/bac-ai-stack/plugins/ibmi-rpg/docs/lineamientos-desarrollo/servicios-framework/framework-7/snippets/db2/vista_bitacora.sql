--==============================================================================
-- Nombre de la Tabla: Nombre tabla
-- Descripción:
--     Descripción de la tabla
-- Objetivo:
--     Objetivo de la tabla
-- Tipo de Tabla:
--     Bitácora
-- Origen de los datos:
--     Se ingresan por el llamado del servicio a travez de canales digitales
-- Permanencia de los datos:
--     3 Meses
-- Uso de los datos:
--     Tener trazabilidad del uso del servicio Código servicio
-- Flujo o proceso de la información:
--     Los valores de los campos de la tabla vienen por parametro en el
--     Servicio Web
-- Restricciones o consideraciones:
--     Ningunca.
--=============================================================================

CREATE VIEW Nombre tabla (
--CAMPOS ESTANDAR
IDNREQ,
FECREQ,
CODAPL,
NOMJOB,
USRJOB,
NUMJOB,
NOMPRG,
CANREQ,
NOMSVD,
UUIDEN,
FECRPT,
CODERR,
MSGERR,
--CAMPOS ESPECIFICOS
MCGCOD
) AS SELECT
  ID_PETICION,
  TIMESTAMP_PETICION,
  CODIGO_APLICACION,
  NOMBRE_TRABAJO,
  USUARIO_TRABAJO,
  NUMERO_TRABAJO,
  PROGRAMA_INVOCADO,
  CANAL_CONSUMIDOR,
  SERVIDOR,
  ID_UNIVERSAL,
  TIMESTAMP_RESPUESTA,
  CODIGO_ERROR,
  MENSAJE_ERROR,
--CAMPOS ESPECIFICOS
  DAT2_1
FROM BITAREGTAR WHERE CODIGO_APLICACION = 'Código servicio'
RCDFMT BITRCódigo servicio;

COMMENT ON TABLE Nombre tabla IS 'VISTA BITACORA SERVICIO Código servicio';

LABEL ON TABLE Nombre tabla IS 'VISTA BITACORA SERVICIO Código servicio';
COMMENT ON COLUMN Nombre tabla (
  MCGCOD  IS 'MCG CODE'
);

LABEL ON COLUMN Nombre tabla (
  MCGCOD  IS 'MCG CODE'
);

LABEL ON COLUMN Nombre tabla (
  MCGCOD TEXT IS 'MCG CODE'
);