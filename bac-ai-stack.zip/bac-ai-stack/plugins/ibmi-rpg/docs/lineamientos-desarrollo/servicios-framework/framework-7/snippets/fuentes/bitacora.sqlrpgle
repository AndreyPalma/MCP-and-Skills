**free
// Acceso de datos para la vista: Nombre bitácora
ctl-opt nomain bnddir('CEXCEPBNDD');

/INCLUDE CSYSTSRC/QSRCTXT,CEXCEPSQLH
/Ruta de archivo txt de la bitacora

// Private attributes
dcl-ds Nombre bitácora_ds qualified template;
    IDNREQ int(10) inz;
    FECREQ timestamp inz;
    CODAPL char(10) inz;
    NOMJOB char(10) inz;
    USRJOB char(10) inz;
    NUMJOB packed(6) inz;
    NOMPRG char(10) inz;
    CANREQ char(30) inz;
    NOMSVD char(10) inz;
    UUID char(100) inz;
    FECRPT timestamp inz;
    CODERR char(7) inz;
    MSGERR char(132) inz;
    MCGCOD char(2) inz;
    Ingresar los parámetros del request del servicio
    s Tipo dato 1(Tamaño variable 1) inz;
    Campo parámetro 2 Tipo dato 2(Tamaño variable 2) inz;
    Campo parámetro 3 Tipo dato 3(Tamaño variable 3) inz;
    Campo parámetro 4 Tipo dato 4(Tamaño variable 4) inz;
    Campo parámetro 5 Tipo dato 5(Tamaño variable 5) inz;
end-ds;

// Default constructor
dcl-proc Nombre bitácora_new export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
    end-pi;

    exec sql set option datfmt=*iso,datsep='-',
                      timfmt=*iso,timsep='.';
    clear pNombre bitácora;
    return;
end-proc;

// Get single record
dcl-proc Nombre bitácora_getRecord export;
    dcl-pi *n ind;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pIDNREQ int(10) const;
    end-pi;

    dcl-s exists ind inz(*off);

    clear pNombre bitácora;

    exec sql
    SELECT
      IDNREQ,
      FECREQ,
      CODAPL,
      NOMJOB,
      USRJOB,
      NUMJOB,
      NOMPRG,
      CANREQ,
      NOMSVD,
      UUID,
      FECRPT,
      CODERR,
      MSGERR,
      MCGCOD,
      Campo parámetro 1,
      Campo parámetro 2,
      Campo parámetro 3,
      Campo parámetro 4,
      Campo parámetro 5
    INTO :pNombre bitácora
    FROM Nombre bitácora
    WHERE IDNREQ = :pIDNREQ;

    CEXCEPSQL_testStatement(sqlCode:sqlState);

    if sqlCode = 0;
        exists = *on;
    endif;

    return exists;
end-proc;

// Insert record
dcl-proc Nombre bitácora_insert export;
    dcl-pi *n ind;
        pNombre bitácora likeds(Nombre bitácora_ds);
    end-pi;

    dcl-s success ind inz(*off);

    exec sql
    INSERT INTO Nombre bitácora (
      FECREQ,
      CODAPL,
      NOMJOB,
      USRJOB,
      NUMJOB,
      NOMPRG,
      CANREQ,
      NOMSVD,
      UUID,
      FECRPT,
      CODERR,
      MSGERR,
      MCGCOD,
      Campo parámetro 1,
      Campo parámetro 2,
      Campo parámetro 3,
      Campo parámetro 4,
      Campo parámetro 5
    )
    VALUES(
      :pNombre bitácora.FECREQ,
      :pNombre bitácora.CODAPL,
      :pNombre bitácora.NOMJOB,
      :pNombre bitácora.USRJOB,
      :pNombre bitácora.NUMJOB,
      :pNombre bitácora.NOMPRG,
      :pNombre bitácora.CANREQ,
      :pNombre bitácora.NOMSVD,
      :pNombre bitácora.UUID,
      :pNombre bitácora.FECRPT,
      :pNombre bitácora.CODERR,
      :pNombre bitácora.MSGERR,
      :pNombre bitácora.MCGCOD,
      :pNombre bitácora.Campo parámetro 1,
      :pNombre bitácora.Campo parámetro 2,
      :pNombre bitácora.Campo parámetro 3,
      :pNombre bitácora.Campo parámetro 4,
      :pNombre bitácora.Campo parámetro 5,    
      );

    CEXCEPSQL_testStatement(sqlCode:sqlState);

    if sqlCode = 0;
        success = *on;
        exec sql
        VALUES IDENTITY_VAL_LOCAL() INTO :pNombre bitácora.IDNREQ;
    endif;

    return success;
end-proc;

// Update record
dcl-proc Nombre bitácora_update export;
    dcl-pi *n ind;
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;

    dcl-s success ind inz(*off);

    exec sql
    UPDATE Nombre bitácora
      SET
      FECRPT = :pNombre bitácora.FECRPT,
      CODERR = :pNombre bitácora.CODERR,
      MSGERR = :pNombre bitácora.MSGERR,
      Campo parámetro 1 = :pNombre bitácora.Campo parámetro 1,
      Campo parámetro 2 = :pNombre bitácora.Campo parámetro 2,
      Campo parámetro 3 = :pNombre bitácora.Campo parámetro 3,
      Campo parámetro 4 = :pNombre bitácora.Campo parámetro 4,
      Campo parámetro 5 = :pNombre bitácora.Campo parámetro 5,
    WHERE
      IDNREQ = :pNombre bitácora.IDNREQ;

    CEXCEPSQL_testStatement(sqlCode:sqlState);

    if sqlCode = 0;
        success = *on;
    endif;

    return success;
end-proc;

// Delete record
dcl-proc Nombre bitácora_delete export;
    dcl-pi *n ind;
        pIDNREQ int(10) const;
    end-pi;

    dcl-s success ind inz(*off);

    exec sql
    DELETE FROM Nombre bitácora
    WHERE IDNREQ = :pIDNREQ;

    CEXCEPSQL_testStatement(sqlCode:sqlState);

    if sqlCode = 0;
        success = *on;
    endif;

    return success;
end-proc;

// SETTERS
// ****************************************
dcl-proc Nombre bitácora_setIDNREQ export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pIDNREQ int(10) const;
    end-pi;
    pNombre bitácora.IDNREQ = pIDNREQ;
end-proc;

dcl-proc Nombre bitácora_setFECREQ export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pFECREQ timestamp const;
    end-pi;
    pNombre bitácora.FECREQ = pFECREQ;
end-proc;

dcl-proc Nombre bitácora_setCODAPL export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pCODAPL char(10) const;
    end-pi;
    pNombre bitácora.CODAPL = pCODAPL;
end-proc;

dcl-proc Nombre bitácora_setNOMJOB export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pNOMJOB char(10) const;
    end-pi;
    pNombre bitácora.NOMJOB = pNOMJOB;
end-proc;

dcl-proc Nombre bitácora_setUSRJOB export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pUSRJOB char(10) const;
    end-pi;
    pNombre bitácora.USRJOB = pUSRJOB;
end-proc;

dcl-proc Nombre bitácora_setNUMJOB export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pNUMJOB packed(6) const;
    end-pi;
    pNombre bitácora.NUMJOB = pNUMJOB;
end-proc;

dcl-proc Nombre bitácora_setNOMPRG export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pNOMPRG char(10) const;
    end-pi;
    pNombre bitácora.NOMPRG = pNOMPRG;
end-proc;

dcl-proc Nombre bitácora_setCANREQ export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pCANREQ char(30) const;
    end-pi;
    pNombre bitácora.CANREQ = pCANREQ;
end-proc;

dcl-proc Nombre bitácora_setNOMSVD export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pNOMSVD char(10) const;
    end-pi;
    pNombre bitácora.NOMSVD = pNOMSVD;
end-proc;

dcl-proc Nombre bitácora_setUUID export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pUUID char(100) const;
    end-pi;
    pNombre bitácora.UUID = pUUID;
end-proc;

dcl-proc Nombre bitácora_setFECRPT export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pFECRPT timestamp const;
    end-pi;
    pNombre bitácora.FECRPT = pFECRPT;
end-proc;

dcl-proc Nombre bitácora_setCODERR export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pCODERR char(7) const;
    end-pi;
    pNombre bitácora.CODERR = pCODERR;
end-proc;

dcl-proc Nombre bitácora_setMSGERR export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pMSGERR char(132) const;
    end-pi;
    pNombre bitácora.MSGERR = pMSGERR;
end-proc;

dcl-proc Nombre bitácora_setMCGCOD export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pMCGCOD char(2) const;
    end-pi;
    pNombre bitácora.MCGCOD = pMCGCOD;
end-proc;

// Procedimientos SET de los campos propios del servicio
dcl-proc Nombre bitácora_setCampo parámetro 1 export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pCampo parámetro 1 char(1) const;
    end-pi;
    pNombre bitácora.Campo parámetro 1 = pCampo parámetro 1;
end-proc;

dcl-proc Nombre bitácora_setCampo parámetro 2 export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pCampo parámetro 2 char(19) const;
    end-pi;
    pNombre bitácora.Campo parámetro 2 = pCampo parámetro 2;
end-proc;

dcl-proc Nombre bitácora_setCampo parámetro 3 export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pCampo parámetro 3 char(3) const;
    end-pi;
    pNombre bitácora.Campo parámetro 3 = pCampo parámetro 3;
end-proc;

dcl-proc Nombre bitácora_setCampo parámetro 4 export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pCampo parámetro 4 packed(15:2) const;
    end-pi;
    pNombre bitácora.Campo parámetro 4 = pCampo parámetro 4;
end-proc;

dcl-proc Nombre bitácora_setCampo parámetro 5 export;
    dcl-pi *n;
        pNombre bitácora likeds(Nombre bitácora_ds);
        pCampo parámetro 5 packed(15:2) const;
    end-pi;
    pNombre bitácora.Campo parámetro 5 = pCampo parámetro 5;
end-proc;

// GETTERS
// ****************************************
dcl-proc Nombre bitácora_getIDNREQ export;
    dcl-pi *n int(10);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.IDNREQ;
end-proc;

dcl-proc Nombre bitácora_getFECREQ export;
    dcl-pi *n timestamp;
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.FECREQ;
end-proc;

dcl-proc Nombre bitácora_getCODAPL export;
    dcl-pi *n char(10);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.CODAPL;
end-proc;

dcl-proc Nombre bitácora_getNOMJOB export;
    dcl-pi *n char(10);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.NOMJOB;
end-proc;

dcl-proc Nombre bitácora_getUSRJOB export;
    dcl-pi *n char(10);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.USRJOB;
end-proc;

dcl-proc Nombre bitácora_getNUMJOB export;
    dcl-pi *n packed(6);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.NUMJOB;
end-proc;

dcl-proc Nombre bitácora_getNOMPRG export;
    dcl-pi *n char(10);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.NOMPRG;
end-proc;

dcl-proc Nombre bitácora_getCANREQ export;
    dcl-pi *n char(30);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.CANREQ;
end-proc;

dcl-proc Nombre bitácora_getNOMSVD export;
    dcl-pi *n char(10);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.NOMSVD;
end-proc;

dcl-proc Nombre bitácora_getUUID export;
    dcl-pi *n char(100);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.UUID;
end-proc;

dcl-proc Nombre bitácora_getFECRPT export;
    dcl-pi *n timestamp;
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.FECRPT;
end-proc;

dcl-proc Nombre bitácora_getCODERR export;
    dcl-pi *n char(7);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.CODERR;
end-proc;

dcl-proc Nombre bitácora_getMSGERR export;
    dcl-pi *n char(132);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.MSGERR;
end-proc;

dcl-proc Nombre bitácora_getMCGCOD export;
    dcl-pi *n char(2);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.MCGCOD;
end-proc;

// Procedimientos GET de los campos propios del servicio
dcl-proc Nombre bitácora_getCampo parámetro 1 export;
    dcl-pi *n char(1);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.Campo parámetro 1;
end-proc;

dcl-proc Nombre bitácora_getCampo parámetro 2 export;
    dcl-pi *n char(19);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.Campo parámetro 2;
end-proc;

dcl-proc Nombre bitácora_getCampo parámetro 3 export;
    dcl-pi *n char(3);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.Campo parámetro 3;
end-proc;

dcl-proc Nombre bitácora_getCampo parámetro 4 export;
    dcl-pi *n packed(15:2);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.Campo parámetro 4;
end-proc;

dcl-proc Nombre bitácora_getCampo parámetro 5 export;
    dcl-pi *n packed(15:2);
        pNombre bitácora likeds(Nombre bitácora_ds) const;
    end-pi;
    return pNombre bitácora.Campo parámetro 5;
end-proc;