# 📋 Lineamientos para Desarrollo en Framework 7 - IBM i

## 📌 Introducción

Este documento establece los lineamientos y mejores prácticas para el desarrollo de servicios utilizando el **Framework 7 de IBM i**. Estos estándares aseguran la consistencia, mantenibilidad y robustez de los servicios implementados siguiendo la arquitectura de componentes **Controlador → Respuesta → Lógica de Negocio** específica del Framework 7.

---
## Diagrama General

flowchart TD
    %% Nodos
    Controlador[Controlador]
    Parseo[Parseo]
    Respuesta[Respuesta]
    Formateo[Formateo]
    Logica[Lógica de negocio]
    Procesamiento[Procesamiento]
    Transformacion[Transformación]
    Controlador -->|1- Recibe petición JSON| Parseo
    Parseo -->|2- Llama Respuesta| Respuesta

    Respuesta -->|4- Analiza petición| Formateo
    Formateo -->|5- Solicita datos| Logica
    Logica -->|6- Aplica reglas| Procesamiento
    Procesamiento -->|7- Retorna datos| Respuesta

    Respuesta -->|8- Formatea JSON| Transformacion
    Transformacion --> Respuesta

    Respuesta -->|9- Entrega respuesta| Controlador

---

## 🎯 Beneficios del Desacoplamiento de Arquitectura

La separación de responsabilidades en tres capas (Controlador → Respuesta → Lógica de Negocio) proporciona ventajas significativas para el desarrollo y mantenimiento de servicios:

### 📦 **1. Mantenibilidad**
- **Modificaciones aisladas**: Los cambios en una capa no afectan directamente a las otras
- **Código más limpio**: Cada componente tiene una responsabilidad única y bien definida
- **Facilidad de debugging**: Los problemas se pueden localizar rápidamente en la capa correspondiente

### 🔄 **2. Reutilización de Componentes**
- **Lógica de negocio reutilizable**: La misma lógica puede servir a múltiples interfaces (REST, SOAP, MQ, etc.)
- **Respuestas estandarizadas**: Formateo consistente independientemente del origen de la petición
- **Reducción de código duplicado**: Evita reimplementar la misma lógica en diferentes servicios

### 🧪 **3. Facilidad de Pruebas**
- **Testing unitario**: Cada capa puede probarse de forma independiente
- **Cobertura de pruebas**: Mayor granularidad en las pruebas automatizadas

### 🔒 **4. Robustez y Seguridad**
- **Validación en capas**: Múltiples puntos de validación (Controlador, reglas de negocio en Lógica)
- **Manejo centralizado de errores**: Tanto el controlador como la lógica de negocio maneja sus propios errores de forma controlada
- **Aislamiento de fallos**: Un error en una capa no compromete necesariamente todo el servicio

---

## 🎯 REQUISITOS

### 1. Estructura de Arquitectura Obligatoria (Framework 7)

La implementación **DEBE** seguir estrictamente el patrón de arquitectura de tres capas definido por Framework 7 mediante el uso de [plantillas o snippets](./snippets/):

#### 🎯 **CONTROLADOR (Controller)**
**✅ RESPONSABILIDADES:**
- Recibir y parsear requests JSON entrantes
- Implementar validaciones de estructura y formato
- Monitor para controlador (para errores de framework):
  - Valida que la trama no esté en blanco (FSC4004)
  - Errores de formato de JSON (FSC4003)

**❌ RESTRICCIONES:**
- Contener lógica de negocio específica
- Acceso directo a bases de datos
- Control de compromiso
- Grabado en bitácora
- Llamados a CLs ni PGMs
- No realizar cambio de lista de bibliotecas

**🔧 FUNCIONALIDAD:**
- **Punto de entrada único** para un servicio específico de framework 7

#### 📋 **RESPUESTA (Response)**
**✅ RESPONSABILIDADES:**
- Formatear datos para salida JSON como estándar
- Llamado a una única lógica de negocio centralizada
- Grabado en bitácora
- Manejo de control de compromiso en caso de ser requerido(Transaccional)
- Un solo monitor por respuesta utilizando la clase CEXCEPTION (para errores de lógica controlados)

**❌ RESTRICCIONES:**
- Contener lógica de negocio
- Acceso directo a datos o bases de datos (a excepción del bitácoreo)
- Llamados a CLs ni PGMs
- No realizar cambio de lista de bibliotecas


**🔧 FUNCIONALIDAD:**
- **Generador de respuestas** formato JSON estándar


#### 🧠 **LÓGICA DE NEGOCIO (Business Logic)**
**✅ RESPONSABILIDADES:**
- Aplicar validaciones y cáculculos de negocio
- Acceso a datos y módulos externos
- Atiende a múltiples interfaces si es necesario (reutilizable)
- Manejar códigos de error controlados con la clase CEXCEPTION_throwNewException 


**❌ RESTRICCIONES:**
- Formateo directo de respuestas JSON
- Control de compromiso
- Llamados a CLs ni PGMs
- No realizar cambio de lista de bibliotecas

**🔧 FUNCIONALIDAD:**
- **Procesador central** de reglas de negocio



**🔧 Propósito:**

- **Trazabilidad**: Permite rastrear el flujo completo de cada petición procesada
- **Auditoría**: Facilita la revisión de operaciones ejecutadas
- **Debugging**: Ayuda en la identificación y resolución de problemas

**⚠️ Consideraciones:**

- El registro en bitácora **NO** debe afectar el rendimiento del servicio
- Solo registrar información relevante, no guardar datos sensibles o excesivos
- No leer de la bitácora, solo es para escritura

---

## 💡 RESTRICCIONES EN EL DESARROLLO

### 1. Restricciones de Llamadas Externas

**❌ PROHIBICIONES ESTRICTAS:**

- **No llamados a programas externos**: Los servicios de Framework 7 **NO DEBEN** realizar llamadas a programas externos (pgms o CLs) desde ninguna de sus capas, se recomienda en su lugar utilizar procedimientos exportables en módulos, SRVPGM con grupo de activación ILE
- **Justificación**: 
  - Rendimiento: evitar levantar programas en cada request, en lugar de que el código quede cargado en memoria en un grupo de activación
  - Diseño modular: cada endpoint llama a procedimientos y no a programas monolitos

### 3. Estándar de Formato de Código

**📝 Formato Obligatorio:**

- **Full Free Format**: Todos los programas **DEBEN** estar escritos en formato **Full Free SQLRPGLE**
- **Sin especificaciones F**: Queda **PROHIBIDO** el uso de declaración de archivos en la hoja F (F-specs)
- **Beneficios**: Código más legible, mantenible y alineado con las prácticas modernas de desarrollo RPG

### 4. Uso Obligatorio de Bitácora

**📝 Registro de Operaciones:**

- **Implementación obligatoria**: Todos los servicios de Framework 7 **DEBEN** implementar el registro en bitácora
- **Ubicación del registro**: La bitácora **DEBE** implementarse en la capa de **Respuesta**
- **Información a registrar para tarjetas**: Se deberá de registrar los campos estandar de la **BITAREGTAR** más los únicos del servicio.
- **Información a registrar para banco**: Se deberá de registrar los campos estandar de la **BITAREG** más los únicos del servicio.
- **Formato de bitácora**: Seguir el estándar definido en la documentación de plantillas o snippets en el siguiente [plantillas o snippets](./snippets/bitacora.sqlrpgle).
- **Retener vista de bitacora en tarjetas**: **Aplicación:** TBIT, **Versión:** 1, **Biblioteca:** TBITDAT
- **Retener vista de bitacora en banco**: **Aplicación:** BCO, **Versión:** REG, **Biblioteca:** BCOCYFILES



### 5. Estándar de Bibliotecas por Tipo de Servicio

Los componentes **DEBEN** estar ubicados en las bibliotecas correspondientes según el tipo de servicio:

#### 🏛️ **Servicios Bancarios**

| Componente | Biblioteca Estándar |
|------------|-------------------|
| **Controlador** | `BBCOSRV` |
| **Respuesta** | `BBCOSRV` |
| **Lógica de Negocio** | `BCOUSRLIB` o `depende de la aplicación` |

#### 💳 **Servicios de Tarjetas**

| Componente | Biblioteca Estándar |
|------------|-------------------|
| **Controlador** | `TCOMSRV` |
| **Respuesta** | `TCOMSRV` |
| **Lógica de Negocio** | `depende de la aplicación` |

#### 📚 **Tablas MQ en biblioteca CMQMDAT a considerar**

```
MQA034     - Inventario dónde se matriculan los servicios
MQA032     - Logs de JOBS
MQA033     - Logs de mensajes de peticiones procesadas
MQA011     - Logs de erroes a nivel de framework
```


### 6. No está permitido el cambio de listas de bibliotecas del framework en tiempo de ejecución

**❌ ESTRICTAMENTE PROHIBIDO:**

- Uso del método `prepara_ambiente` o similares dentro de los servicios para el cambio dinámico de bibliotecas durante la ejecución del servicio
- Uso de comandos `ADDLIBLE`, `RMVLIBLE`, `CHGLIBL` dentro del código del servicio
- Tampoco se permiten bibliotecas quemadas en el código fuente

## 🔗 Estándares y Documentación

### 📚 Estándares y Buenas Practicas de Programación 
**Habilidades (Skills)**

- [rpg-best-practices](/plugins/ibmi-rpg/skills/rpg-best-practices/)


---
