**free

ctl-opt nomain bnddir('BNDDIR que utilice');
//----------------------------------------------------------------------------
//@name.....: Nombre fuente
//@objective: Objetivo del fuente
//@version..: Numero de pase
//@team.....: Nombre Equipo
//@author...: Autor
//@since....: Fecha
//@comments.: Resumen del contenido del fuente
//@----------------------------------------------------------------------------

/INCLUDE ccgitsrc/qsrctxt,usec
/INCLUDE CSYSTSRC/QSRCTXT,PGMSTSH
/INCLUDE CMQASRC/QSRCTXT,CFWUTIL7
/INCLUDE CAJLSRC/QSRCTXT,YAJLH
/INCLUDE CSYSTSRC/QSRCTXT,CEXCEPTION

Importaciones necesarias de lógica de negocio o módulos

//-------------------------------------------
//  VARIABLES GLOBALES
//-------------------------------------------
DCL-S atLeastOneRegisterShown ind;

Declaración de variables globales si son necesarias

//-------------------------------------------------------------------------
//@name.....: Nombre procedimiento
//@objective: Construye la respuesta en formato JSON
//            Realiza el manejo de errores
//@version..: Numero de pase
//@team.....: Nombre Equipo
//@author...: Autor
//@since....: Fecha
//@paramin..: Parámetros de entrada si los hay
//@paramout.: *on: Exitoso
//            *off: Error
//-------------------------------------------------------------------------
Dcl-Proc Nombre procedimiento export;
  Dcl-Pi *n ind;
    Parámetros de entrada
    isFirstRegister ind const;
    isLastRegister ind const;
  End-Pi;
  
  Variables si se necesitan
  
  IF (isFirstRegister);
      yajl_beginObj('Nombre objeto a listarList');
      yajl_beginArray('Nombre detalle objeto a listarDetail');
  ENDIF;
  
  Monitor;
  
  //Se setea en ON cuando se ha hecho la validación de que haya al menos 1 registro
  atLeastOneRegisterShown = *on;
  
    //Llamados a la lógica de negocio o módulos necesarios
    Nombre fuente_insertNombre bitácora();
    successResponse = *on;
  
  on-error;
    IF (isLastRegister = *on and atLeastOneAccountShown = *off);
        CEXCEPTION_catchException();
        Nombre bitácora_setCODERR(serviceLog:CEXCEPTION_getMessageId());
        Nombre bitácora_setMSGERR(serviceLog:CEXCEPTION_getMessageText());
        CFWUTIL7_addError(CEXCEPTION_getMessageId():%trim(CEXCEPTION_getMessageText()));
        Nombre fuente_insertNombre bitácora();
        successResponse = *off;
    ELSE;
    //En caso de no encontrar el registro edita los datos de BITAR para su insercion
        CEXCEPTION_catchException();
        Nombre bitácora_setCODERR(serviceLog:CEXCEPTION_getMessageId());
        Nombre bitácora_setMSGERR(serviceLog:CEXCEPTION_getMessageText());
        Nombre fuente_insertNombre bitácora();
    ENDIF;
  endmon;

  IF (isLastRegister);
     //Finalización de construcción de respuesta
     yajl_endArray();
     yajl_endObj();
  ENDIF;
  return successResponse;
End-Proc;

//-------------------------------------------------------------------------
//@name.....: Nombre fuente_cargaNombre bitácora
//@objective: Carga la información inicial en la bitácora del servicio
//@version..: Numero de pase
//@team.....: Nombre Equipo
//@author...: Autor
//@since....: Fecha
//@paramin..: i_pServiceParms: Parámetros de entrada del servicio
//@paramout.: N/A
//-------------------------------------------------------------------------
Dcl-Proc Nombre fuente_cargaNombre bitácora;
  Dcl-Pi *n;
    @i_pServiceParms LikeDs(serviceParmsT) Const;
  End-Pi;

  Dcl-S sysName Char(8) inz;

  clear @Nombre bitácora;

  exec sql VALUES CURRENT_SERVER INTO :sysName ;

  Nombre bitácora_new(@Nombre bitácora);
  Nombre bitácora_setFECREQ(@Nombre bitácora:%Timestamp);
  Nombre bitácora_setCODAPL(@Nombre bitácora:CFWUTIL7_GETSERVICECODE());
  Nombre bitácora_setNOMJOB(@Nombre bitácora:PgmJob);
  Nombre bitácora_setUSRJOB(@Nombre bitácora:PgmUsr);
  Nombre bitácora_setNUMJOB(@Nombre bitácora:PgmJobNbr);
  Nombre bitácora_setNOMPRG(@Nombre bitácora:PgmNam);
  Nombre bitácora_setCANREQ(@Nombre bitácora:%Trim(CFWUTIL7_GETORIGINCHANNEL()));
  Nombre bitácora_setNOMSVD(@Nombre bitácora:sysName);
  Nombre bitácora_setUUID(@Nombre bitácora:CFWUTIL7_GETUUIDVALUE());
  // Datos del Request

End-Proc;

//-------------------------------------------------------------------------
//@name.....: Nombre fuente_insertNombre bitácora
//@objective: Inserta la bitácora del servicio
//@version..: Numero de pase
//@team.....: Nombre Equipo
//@author...: Autor
//@since....: Fecha
//@paramin..: N/A
//@paramout.: N/A
//-------------------------------------------------------------------------
Dcl-Proc Nombre fuente_insertNombre bitácora;
  Dcl-Pi *n;
  End-Pi;

  Nombre bitácora_setFECRPT(@Nombre bitácora:%Timestamp);
  Nombre bitácora_insert(@Nombre bitácora);

End-Proc;