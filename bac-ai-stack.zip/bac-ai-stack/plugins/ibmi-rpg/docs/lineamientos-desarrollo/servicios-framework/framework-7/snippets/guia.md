# 📘 Guía de Uso

## 📌 Introducción

Plantillas o snippets de código estandarizadas para el desarrollo de microservicios en Framework 7.

---

## ✨ Características

- ✅ Generación de prototipos para archivos TXT/RPGLEINC
- ✅ Creación de vistas SQL para bitácoras
- ✅ Código estandarizado que cumple con los lineamientos del framework

---

## 📝 Snippets Disponibles

Los siguientes snippets están organizados según el tipo de archivo donde se utilizan.

### 1. Snippets para Código RPGLE (archivos `.sqlrpgle`)

Estos snippets generan código en el lenguaje de programación RPGLE:

#### **`controlador`**
Genera el código necesario para un controlador de un microservicio en RPGLE de Framework 7.
[fuentes/controlador.sqlrpgle](fuentes/controlador.sqlrpgle)

#### **`controlador_con_lista`**
Genera el código necesario para un controlador con manejo de listas de un microservicio en RPGLE de Framework 7.
[fuentes/controlador_con_lista.sqlrpgle](fuentes/controlador_con_lista.sqlrpgle)

#### **`respuesta`**
Genera el código base de la respuesta de un microservicio, incluyendo una base para el manejo de errores y registro en bitácoras.
[fuentes/respuesta.sqlrpgle](fuentes/respuesta.sqlrpgle)

#### **`respuesta_control_compromiso`**
Genera el código base de la respuesta de un microservicio, incluyendo lo mencionado anteriormente, con el añadido de la estructura base para el control de compromiso si se requiere, por ejemplo en servicios transaccionales.
[fuentes/respuesta_control_compromiso.sqlrpgle](fuentes/respuesta_control_compromiso.sqlrpgle)

#### **`respuesta_con_listas`**
Genera el código base de la respuesta con manejo de listas de un microservicio, incluyendo una base para el manejo de errores y registro en bitácoras.
[fuentes/respuesta_con_listas.sqlrpgle](fuentes/respuesta_con_listas.sqlrpgle)

#### **`bitacora`**
Genera el código del módulo de la bitácora, donde se deben ingresar los parámetros únicamente que el servicio en el que estemos trabajando utilice como parámetros de entrada u otros parámetros necesarios para el rastreo correcto del servicio.
[fuentes/bitacora.sqlrpgle](fuentes/bitacora.sqlrpgle)

---

### 2. Snippets para Prototipos (archivos `.txt`, `.rpgleinc`)

Estos snippets generan los prototipos bases de la creación de microservicios en el archivo de TXT/RPGLEINC correspondiente:

#### **`processParms`**
Genera el prototipo del procedimiento **processParms** del controlador, donde debemos añadir los parámetros de entrada de nuestro servicio.
[prototipos/processParms.rpgleinc](prototipos/processParms.rpgleinc)

#### **`serviceParamsList`**
Genera los prototipos del procedimiento **processParms** del controlador con manejo de listas, donde debemos añadir los parámetros de entrada de nuestro servicio.
[prototipos/serviceParamsList.rpgleinc](prototipos/serviceParamsList.rpgleinc)

#### **`prototipoBitacora`**
Genera el prototipo del módulo de la bitácora, donde debemos añadir los procedimientos **getters** y **setters** correspondientes a los parámetros de entrada de nuestro servicio u otro parámetro que querramos rastrear por medio de la bitácora.
[prototipos/prototipoBitacora.rpgleinc](prototipos/prototipoBitacora.rpgleinc)

---

### 3. Snippets para SQL (archivos `.sql`)

Estos snippets generan el código fuente de la creación de la vista de bitácora de un servicio en un archivo SQL:

#### **`vista_bitacora`**
Genera la estructura base de la creación de la vista de bitácora.
[db2/vista_bitacora.sql](db2/vista_bitacora.sql)

---

## 📂 Estructura de la Carpeta de Snippets

```
snippets/
├── guia.md                          # Este archivo
├── fuentes/                         # Snippets de código RPGLE
│   ├── controlador.sqlrpgle
│   ├── controlador_con_lista.sqlrpgle
│   ├── respuesta.sqlrpgle
│   ├── respuesta_control_compromiso.sqlrpgle
│   ├── respuesta_con_listas.sqlrpgle
│   └── bitacora.sqlrpgle
├── prototipos/                      # Snippets de prototipos RPGLEINC
│   ├── processParms.rpgleinc
│   ├── serviceParamsList.rpgleinc
│   └── prototipoBitacora.rpgleinc
└── db2/                             # Snippets de SQL
    └── vista_bitacora.sql
```

---