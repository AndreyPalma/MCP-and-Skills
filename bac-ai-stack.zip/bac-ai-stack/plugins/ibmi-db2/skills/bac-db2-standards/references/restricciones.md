# Restricciones Técnicas y Arquitectónicas

Esta referencia cubre las limitaciones, restricciones y políticas técnicas que deben respetarse.

## Tabla de Contenido

1. [Restricciones de Tipos de Datos](#1-restricciones-de-tipos-de-datos)
2. [Restricciones de Objetos](#2-restricciones-de-objetos)
3. [Política de Idiomas](#3-política-de-idiomas)
4. [Restricciones de Modificación](#4-restricciones-de-modificación)

---

## 1. Restricciones de Tipos de Datos

### Campos en Llaves Primarias

❌ **EVITAR tipos complejos en PRIMARY KEY:**

**Tipos NO recomendados en PK:**
- VARCHAR (cualquier longitud)
- CHAR > 25 posiciones
- DECIMAL (cualquier precisión)
- BIGINT (solo si es necesario)
- CLOB, BLOB, XML
- TIMESTAMP

**Razón:** Impacto severo en rendimiento debido a:
- Mayor espacio en índices
- Comparaciones más lentas
- Mayor I/O en joins
- Overhead en FK que referencian la PK

❌ **INCORRECTO:**
```sql
-- Rendimiento muy pobre
CREATE TABLE CLIENTES (
    nombre_completo     VARCHAR(200) NOT NULL,  -- ❌ Muy largo
    direccion           VARCHAR(150) NOT NULL,  -- ❌ VARCHAR en PK
    PRIMARY KEY (nombre_completo, direccion)
);

CREATE TABLE PRODUCTOS (
    descripcion_larga   VARCHAR(500) NOT NULL,  -- ❌ Campo largo
    PRIMARY KEY (descripcion_larga)
);

CREATE TABLE TRANSACCIONES (
    monto_exacto        DECIMAL(15,8) NOT NULL, -- ❌ DECIMAL en PK
    PRIMARY KEY (monto_exacto)
);
```

✓ **CORRECTO - Usar surrogados simples:**
```sql
CREATE TABLE CLIENTES (
    cliente_id          INT NOT NULL,           -- ✓ Simple y eficiente
    nombre_completo     VARCHAR(200) NOT NULL,
    direccion           VARCHAR(150) NOT NULL,
    PRIMARY KEY (cliente_id),
    CONSTRAINT uq_clientes_nombre_dir UNIQUE (nombre_completo, direccion)
);

CREATE TABLE PRODUCTOS (
    producto_id         INT NOT NULL,           -- ✓ INTEGER simple
    descripcion_larga   VARCHAR(500) NOT NULL,
    PRIMARY KEY (producto_id)
);

CREATE TABLE TRANSACCIONES (
    transaccion_id      BIGINT NOT NULL,        -- ✓ BIGINT cuando necesario
    monto_exacto        DECIMAL(15,8) NOT NULL,
    PRIMARY KEY (transaccion_id)
);
```

### NVARCHAR y NCHAR

⚠ **Uso regulado de tipos Unicode:**

**Consideraciones de NVARCHAR/NCHAR:**
1. **Permite códigos Unicode** (símbolos internacionales: €, ñ, 中文, العربية)
2. **Ocupa más espacio** (puede duplicar el tamaño vs VARCHAR/CHAR)
3. **Puede impactar performance** (más datos a mover en queries)

❌ **NO usar por defecto:**
```sql
-- EVITAR sin justificación
nombre  NVARCHAR(100),  -- ¿Realmente necesita Unicode extendido?
```

✓ **Usar solo cuando se justifique:**
```sql
-- JUSTIFICADO - Comentarios de clientes internacionales
comentario_cliente  NVARCHAR(500),  -- Puede contener caracteres de cualquier idioma

-- JUSTIFICADO - Nombres con caracteres especiales
nombre_internacional NVARCHAR(100),  -- Para clientes con nombres en otros alfabetos

-- NO JUSTIFICADO - Datos estándar en español
apellido VARCHAR(50),  -- Español no requiere Unicode extendido
```

**Alternativa más eficiente:**
```sql
-- Si solo necesitas caracteres latinos con acentos
-- VARCHAR con codificación UTF-8 es suficiente
nombre VARCHAR(100) NOT NULL  -- Soporta á, é, í, ó, ú, ñ, etc.
```

---

## 2. Restricciones de Objetos

### Archivos Prohibidos

❌ **NO implementar:**

```sql
-- PROHIBIDO - Archivos planos (S/36)
-- No crear archivos tipo S/36

-- PROHIBIDO - Archivos DDS
-- No crear nuevos archivos DDS

-- PROHIBIDO - Archivos multiformato sin justificación
-- Evitar diseños complejos de múltiples formatos de registro
```

✓ **Alternativa moderna:**
```sql
-- USAR tablas SQL estándar
CREATE TABLE datos (
    campo1 VARCHAR(100),
    campo2 INTEGER,
    ...
);
```

### Archivos Temporales

❌ **NO crear archivos permanentes como "temporales":**
```sql
-- INCORRECTO
CREATE TABLE PROD_DATA.TEMP_PROCESO (...);  -- En biblioteca de producción
```

✓ **Usar declaración de temporales:**
```sql
-- CORRECTO - Tabla temporal de sesión
DECLARE GLOBAL TEMPORARY TABLE temp_calculos (
    campo1 INT,
    campo2 DECIMAL(11,2),
    campo3 VARCHAR(50)
) WITH DATA
ON COMMIT PRESERVE ROWS;

-- CORRECTO - En biblioteca temporal
CREATE TABLE QTEMP.TEMP_PROCESO AS (
    SELECT ...
) WITH DATA;
```

### Restricción de Modificación

❌ **NO modificar:**
- Archivos propios de sistemas core (ej. IBS)
- Tablas con restricción explícita de cambios
- Objetos de terceros sin autorización
- Estructuras deprecadas en proceso de migración

**Validar con Arquitectura de Datos antes de modificar:**
- Tablas core del banco
- Estructuras compartidas entre aplicaciones
- Objetos históricos o legacy

---

## 3. Política de Idiomas

### Español por Defecto

✓ **Regla General: Todo en español**

**La base de datos pertenece a BAC Credomatic** y opera en países latinos:

```sql
-- CORRECTO - Español
CREATE TABLE CUENTAS (
    cuenta_numero       BIGINT NOT NULL,
    fecha_apertura      DATE NOT NULL,
    saldo_disponible    DECIMAL(15,2) NOT NULL,
    estatus_cuenta      CHAR(1) NOT NULL,
    PRIMARY KEY (cuenta_numero)
);

COMMENT ON TABLE CUENTAS IS 
    'Registro maestro de cuentas de ahorro y corrientes';

COMMENT ON COLUMN CUENTAS.saldo_disponible IS 
    'Saldo actual disponible para retiros y transacciones';
```

❌ **EVITAR mezcla innecesaria:**
```sql
-- INCORRECTO - Mezcla de idiomas sin razón
CREATE TABLE ACCOUNTS (  -- ❌ Inglés
    account_number  BIGINT,  -- ❌ Inglés
    fecha_apertura  DATE,    -- Mezcla inconsistente
    saldoDisponible DECIMAL  -- Mezcla de camelCase
);
```

### Excepción 1: Términos de Negocio

✓ **Permitido cuando el término es estándar en otro idioma:**

```sql
-- PERMITIDO - SWIFT es término internacional
codigo_swift    VARCHAR(11) NOT NULL,
referencia_ach  VARCHAR(20),  -- ACH es término estándar

-- PERMITIDO - ATM es universalmente usado
tipo_terminal   CHAR(3) NOT NULL,  -- ATM, POS, MOB

COMMENT ON COLUMN transacciones.codigo_swift IS 
    'Código SWIFT internacional de la transacción (Society for Worldwide Interbank Financial Telecommunication)';
```

### Excepción 2: Tablas Existentes en Producción

⚠ **Si la tabla YA está en producción con otro idioma:**

```sql
-- Tabla existente en producción (en inglés)
-- PERMITIDO continuar con el idioma original para nuevos campos
ALTER TABLE CUSTOMER_ACCOUNTS  -- Tabla existente en inglés
    ADD COLUMN credit_limit DECIMAL(15,2);  -- Continuar en inglés

-- PERO metadata y documentación siempre en español
COMMENT ON COLUMN CUSTOMER_ACCOUNTS.credit_limit IS 
    'Límite de crédito asignado a la cuenta en moneda local';
```

### Documentación Siempre en Español

✓ **100% de metadata en español, independientemente del nombre del objeto:**

```sql
-- Objeto con nombre en inglés (legacy)
COMMENT ON TABLE LEGACY_ACCOUNTS IS 
    'Tabla legacy de cuentas del sistema anterior. En proceso de migración al nuevo modelo de datos';  -- ✓ Español

COMMENT ON COLUMN LEGACY_ACCOUNTS.CUST_ID IS 
    'Identificador único de cliente heredado del sistema anterior';  -- ✓ Español
```

---

## 4. Restricciones de Modificación

### Estrategia de Modernización

⚠ **Considerar estrategia corporativa de modernización:**

- No crear objetos que contrarresten la modernización
- Validar alineación con roadmap de arquitectura
- Considerar migración planificada de objetos legacy
- No perpetuar deuda técnica

**Consultar antes de:**
- Crear nuevas tablas DDS (prohibido)
- Modificar estructuras en deprecación
- Diseñar integraciones con sistemas legacy
- Implementar workarounds para limitaciones de objetos antiguos

### Impacto de Types de Dato Complejos

⚠ **Considerar impacto en:**

**1. Performance:**
```sql
-- Alto costo en joins
SELECT *
FROM TABLA_A A
JOIN TABLA_B B 
    ON A.campo_varchar_largo = B.campo_varchar_largo  -- Costoso
WHERE ...;

-- Mejor performance
SELECT *
FROM TABLA_A A
JOIN TABLA_B B 
    ON A.id_simple = B.id_simple  -- Eficiente
WHERE ...;
```

**2. Índices:**
```sql
-- Índice grande y lento
CREATE INDEX ix_grande ON TABLA(campo_varchar_200, campo_varchar_150);

-- Índice compacto y rápido  
CREATE INDEX ix_compacto ON TABLA(id_numerico, codigo_corto);
```

**3. Foreign Keys:**
```sql
-- FK sobre PK compleja = overhead en todas las operaciones
ALTER TABLE DETALLE
    ADD CONSTRAINT fk_detalle_maestro
    FOREIGN KEY (campo_largo_1, campo_largo_2)  -- Costoso
    REFERENCES MAESTRO(campo_largo_1, campo_largo_2);
```

---

## Ejemplo: Decisiones de Diseño Considerando Restricciones

### Caso: Tabla de Transacciones Internacionales

```sql
-- DISEÑO CONSIDERANDO RESTRICCIONES

CREATE TABLE TRANSACCIONES_SWIFT (
    -- PK simple para eficiencia (no usar campos complejos)
    transaccion_id          BIGINT NOT NULL,  -- ✓ Simple
    
    -- Campos en español (regla general)
    pais_origen             CHAR(2) NOT NULL,
    pais_destino            CHAR(2) NOT NULL,
    fecha_transaccion       DATE NOT NULL,
    fecha_valor             DATE NOT NULL,
    
    -- Término internacional permitido
    codigo_swift_origen     VARCHAR(11) NOT NULL,  -- SWIFT es estándar
    codigo_swift_destino    VARCHAR(11) NOT NULL,
    
    -- Montos con tipos apropiados
    monto_transaccion       DECIMAL(18,2) NOT NULL,
    moneda_codigo           CHAR(3) NOT NULL,
    
    -- Descripción puede requerir Unicode si es internacional
    descripcion             NVARCHAR(200),  -- Justificado: mensajes internacionales
    
    -- Campos estándar en VARCHAR (español)
    banco_intermediario     VARCHAR(100),
    referencia_cliente      VARCHAR(50),
    
    -- Estatus en español
    estatus_proceso         CHAR(2) NOT NULL,
    
    -- PK en campo simple
    CONSTRAINT pk_transacciones_swift PRIMARY KEY (transaccion_id),
    
    -- Check constraints
    CONSTRAINT ck_swift_estatus 
        CHECK (estatus_proceso IN ('PE', 'PR', 'CO', 'RE', 'CA'))
);

-- Metadata 100% en español
COMMENT ON TABLE TRANSACCIONES_SWIFT IS 
    'Registro de transacciones internacionales procesadas mediante red SWIFT entre instituciones financieras';

COMMENT ON COLUMN TRANSACCIONES_SWIFT.codigo_swift_origen IS 
    'Código SWIFT (BIC) de la institución financiera origen de la transferencia';

COMMENT ON COLUMN TRANSACCIONES_SWIFT.descripcion IS 
    'Descripción o concepto de la transacción. Puede contener caracteres de cualquier idioma según estándar SWIFT';

-- Índice en campos simples y cortos
CREATE INDEX ix_swift_fecha_pais 
    ON TRANSACCIONES_SWIFT(fecha_transaccion, pais_origen);

-- No crear índice sobre descripción (campo largo y NVARCHAR)
```

---

## Checklist de Restricciones

- [ ] No usar tipos complejos en PRIMARY KEY (VARCHAR, DECIMAL, campos largos)
- [ ] Justificar uso de NVARCHAR/NCHAR (Unicode)
- [ ] No crear archivos planos (S/36)
- [ ] No crear archivos DDS nuevos
- [ ] No archivos multiformato sin justificación excepcional
- [ ] Usar tablas temporales correctamente (QTEMP, DECLARE TEMP)
- [ ] No modificar archivos con restricción de cambios (IBS, core, etc.)
- [ ] Nombres de objetos en español (salvo excepciones)
- [ ] Términos internacionales justificados (SWIFT, ACH, ATM)
- [ ] Tablas existentes: continuar idioma pero metadata en español
- [ ] Metadata y documentación 100% en español
- [ ] Alineado con estrategia de modernización
- [ ] No perpetuar deuda técnica
- [ ] Considerar impacto de performance en tipos de datos
- [ ] Consultar con Arquitectura para cases dudosos

---

**Fuente**: Sección 6 - Check List de Revisión de Base de Datos BAC Credomatic
