# Nomenclaturas Oficiales BAC Credomatic

Esta referencia documenta las **políticas oficiales de nomenclatura** para todos los objetos de base de datos en BAC Credomatic.

> **📌 Importante**: Las nomenclaturas deben validarse usando los stored procedures oficiales de LIBMHV.
> 
> - **UBDP_CONSULTA_AVP**: Obtener AVP a la que pertenece el objeto (por código o nombre de aplicación)
> - **UBDP_CONSULTA_ABREVIATURAS**: Obtener abreviatura correspondiente **POR CONCEPTO DE NEGOCIO** (867 códigos oficiales)
> - **UBDP_VALIDAR_NOMBRES**: Validar que el nombre del objeto sea correcto
>
> **Tabla de abreviaturas**: `LIBMHVTMP.HBDAABRDID` (no usar LIBMHV.ABREVIA)

⚠️ **CRÍTICO**: 
- **NO usar abreviaturas hardcodeadas** - todas deben obtenerse dinámicamente consultando los SPs
- Las abreviaturas se consultan por **concepto de negocio**, NO por código directo
- Ejemplo: Para "maestro de transacciones" → buscar `UBDP_CONSULTA_ABREVIATURAS('', 'maestro')` y `UBDP_CONSULTA_ABREVIATURAS('', 'transacción')`
- Si hay múltiples resultados, seleccionar automáticamente la opción más apropiada según contexto

**Referencias visuales**: Ver imágenes en `docs/images/nomenclatura_*.jpg`

---

## Tabla de Contenido

1. [Estructura General](#estructura-general)
2. [Nomenclatura de Tablas](#1-nomenclatura-de-tablas)
3. [Nomenclatura de Campos](#2-nomenclatura-de-campos)
4. [Nomenclatura de Vistas](#3-nomenclatura-de-vistas)
5. [Nomenclatura de Vistas Lógicas](#4-nomenclatura-de-vistas-lógicas)
6. [Nomenclatura de Índices](#5-nomenclatura-de-índices)
7. [Nomenclatura de Stored Procedures](#6-nomenclatura-de-stored-procedures)
8. [Nomenclatura de Funciones](#7-nomenclatura-de-funciones)
9. [Nomenclatura de Triggers](#8-nomenclatura-de-triggers)
10. [Nomenclatura de Secuencias](#9-nomenclatura-de-secuencias)
11. [Nomenclatura de Constraints](#10-nomenclatura-de-constraints)
12. [Nomenclatura de Scripts](#11-nomenclatura-de-scripts)
13. [Catálogo de Abreviaturas](#catálogo-de-abreviaturas)
14. [Validación con Stored Procedures](#validación-con-stored-procedures)

---

## Estructura General

### Patrón Base: AVP + Tipo + Abreviaturas

La nomenclatura de BAC Credomatic sigue el patrón:

```
[AVP][TIPO_OBJETO][ABR1][ABR2]
```

**Componentes**:
- **AVP**: Application Version Production (3-4 caracteres) - Aplicación a la que pertenece
- **TIPO_OBJETO**: Tipo del objeto (A=Tabla, I=Índice, T=Trigger, P=Procedure, F=Función)
- **ABR1, ABR2**: Abreviaturas oficiales de 3 caracteres que describen el propósito

**Ejemplo Real**:
```
CRMARPTRERR      -- CRM + A (Tabla) + RPT (Respuesta) + ERR (Error)
COREACTASAL      -- CORE + A (Tabla) + CTA (Cuenta) + SAL (Saldo)
TCAAATMLOG       -- TCA + A (Tabla) + ATM (Cajero) + LOG (Registro)
```

**Nota**: El tipo de objeto puede estar implícito o ser parte del nombre, pero siempre se valida con `UBDP_VALIDAR_NOMBRES`.

### ⚠️ Truncamiento AVP (4→3 Caracteres)

**REGLA CRÍTICA**: El nombre corto del objeto **NO PUEDE SUPERAR 10 CARACTERES**.

Cuando el AVP tiene 4 caracteres, se debe **truncar a 3 caracteres** para el nombre del objeto, omitiendo el primer carácter que indica la categoría:

| Primer Carácter | Significado | Ejemplo AVP | Truncado |
|-----------------|-------------|-------------|----------|
| **B** | BANCO | BBRI (Bridger Banca) | BRI |
| **T** | TARJETAS | TBRI (Bridger Tarjetas) | BRI |
| **C** | CORPORATIVO | CENB (Envío Bridger) | ENB |

**Proceso de Truncamiento**:

1. **Validar con AVP COMPLETO** (4 caracteres):
   ```sql
   CALL LIBMHV.UBDP_VALIDAR_NOMBRES('BBRI', 'A', 'MST', 'TRN');
   -- Usa BBRI (4 chars) para validación oficial
   ```

2. **Crear objeto con AVP TRUNCADO** (3 caracteres):
   ```sql
   CREATE TABLE BRIAMSTTRN (...)  -- BRI + A + MST + TRN = 10 chars
   -- Omitido primer char 'B' de BBRI
   ```

**Ejemplos de Truncamiento**:

| AVP Original | Descripción | Omitir | AVP Truncado | Ejemplo Tabla |
|--------------|-------------|--------|--------------|---------------|
| BBRI (4) | Bridger Banca | B | BRI | BRIAMSTTRN |
| CBRI (4) | Objetos Bridger | C | BRI | BRIAMSTTRN |
| TBRI (4) | Bridger Tarjetas | T | BRI | BRIAMSTTRN |
| CENB (4) | Envío Bridger | C | ENB | ENBAMSTTRN |
| CRM (3) | Siebel CRM | - | CRM | CRMARPTRERR |
| CORE (4) | Core Bancario | C | ORE | OREACTASAL |

**Cálculo de Longitud**:
```
AVP (3) + TIPO (1) + ABR1 (3) + ABR2 (3) = 10 caracteres máximo
Ejemplo: BRI (3) + A (1) + MST (3) + TRN (3) = BRIAMSTTRN (10 chars) ✓
```

### Reglas AS400

**IMPORTANTE**: Todos los objetos se ejecutan en AS400 (IBM i), por lo que deben cumplir:

| Regla | Descripción | Ejemplo |
|-------|-------------|---------|
| **Límite línea** | Máximo 80 caracteres por línea | Partir líneas largas con continuación |
| **Nombres largos** | Siempre en MAYÚSCULAS | `MAESTRO_TRANSACCION` ✓ |
| **Referencias** | Siempre por nombre corto | `BRIAMSTTRN` no `MAESTRO_TRANSACCION` |
| **Nombre archivo** | Igual al nombre corto (≤10 chars) | `BRIAMSTTRN.table` |
| **RCDFMT** | Reemplazar tipo objeto por R | `RCDFMT BRIRMSTTRN;` (BRIA→BRIR) |
| **RENAME** | Asignar nombre largo al crear | Ver ejemplos abajo |
| **LABEL ON** | 3 tipos obligatorios | TABLE, COLUMN (IS), COLUMN (TEXT IS) |

**Ejemplo Completo AS400**:

```sql
---
-- BRIAMSTTRN: Maestro de transacciones
--
-- @author Luis Fernández
-- @date 2026-03-04
-- @project BRIDGER-001
---


CREATE TABLE BRIAMSTTRN
(
-- DATOS PRINCIPALES
  TRANSACCION_CODIGO     FOR TRNCOD CHAR(5) NOT NULL,
  TRANSACCION_DESCRIPCION 
                         FOR TRNDES VARCHAR(100) 
                         NOT NULL WITH DEFAULT '',
  TRANSACCION_ESTADO     FOR TRNEST CHAR(1) 
                         NOT NULL WITH DEFAULT 'A',
-- AUDITORIA
  USUARIO_CREACION       FOR USRCRE CHAR(18) 
                         NOT NULL WITH DEFAULT USER,
  FECHA_CREACION         FOR FECCRE TIMESTAMP 
                         NOT NULL WITH DEFAULT 
                         CURRENT TIMESTAMP,
  
  CONSTRAINT BRIAMSTTRN_PK 
    PRIMARY KEY (TRNCOD),
  
  CONSTRAINT BRIAMSTTRN_TRNEST_CST 
    CHECK(TRNEST IN('A','I'))
)
RCDFMT BRIRMSTTRN;

RENAME TABLE BRIAMSTTRN TO
BRIDGER_MAESTRO_TRANSACCIONES FOR SYSTEM NAME BRIAMSTTRN;

COMMENT ON TABLE BRIAMSTTRN 
        IS 'MAESTRO DE TRANSACCIONES DE BRIDGER';

COMMENT ON COLUMN BRIAMSTTRN ( 
  TRNCOD IS 'CODIGO DE TRANSACCION',
  TRNDES IS 'DESCRIPCION DE TRANSACCION',  
  TRNEST IS 'ESTADO: A=ACTIVO, I=INACTIVO',
  USRCRE IS 'USUARIO CREACION',
  FECCRE IS 'FECHA CREACION'
);

LABEL ON TABLE BRIAMSTTRN 
      IS 'MAESTRO TRANSACCIONES';

LABEL ON COLUMN BRIAMSTTRN (
  TRNCOD IS 'CODIGO',
  TRNDES IS 'DESCRIPCION',
  TRNEST IS 'ESTADO',
  USRCRE IS 'USUARIO CRE',
  FECCRE IS 'FECHA CRE'
);

LABEL ON COLUMN BRIAMSTTRN (
  TRNCOD TEXT IS 'CODIGO TRANSACCION',
  TRNDES TEXT IS 'DESCRIPCION',
  TRNEST TEXT IS 'ESTADO',
  USRCRE TEXT IS 'USUARIO CREACION',
  FECCRE TEXT IS 'FECHA CREACION'
);
```

**Nomenclatura de CONSTRAINT**:

| Tipo | Formato | Ejemplo |
|------|---------|---------|
| **PRIMARY KEY** | `[NOMBRE_TABLA]_PK` | `BRIAMSTTRN_PK` |
| **FOREIGN KEY** | `[NOMBRE_TABLA]_[CAMPO]_FK` | `BRIAMSTTRN_TRNCOD_FK` |
| **CHECK** | `[NOMBRE_TABLA]_[CAMPO]_CST` | `BRIAMSTTRN_TRNEST_CST` |
| **UNIQUE** | `[NOMBRE_TABLA]_[CAMPO]_UK` | `BRIAMSTTRN_TRNCOD_UK` |

### AVPs Comunes

| AVP | Descripción | Ejemplo Tabla |
|-----|-------------|---------|
| **CORE** | Core Bancario | `COREACTASAL` (CORE + A + CTA + SAL) |
| **CRM** | Customer Relationship Management | `CRMACLICONT` (CRM + A + CLI + CONT) |
| **TCA** | Tarjetas de Crédito/Débito | `TCAATRXPOS` (TCA + A + TRX + POS) |
| **CAN** | Canales electrónicos | `CANAATMLOG` (CAN + A + ATM + LOG) |
| **DWH** | Data Warehouse | `DWHACLIDIM` (DWH + A + CLI + DIM) |
| **SEG** | Seguridad | `SEGAUSRROL` (SEG + A + USR + ROL) |
| **BPM** | Business Process Management | `BPMAPROCEST` (BPM + A + PROC + EST) |

### Longitud de Nombres

| Objeto | Máximo Caracteres | Recomendado |
|--------|-------------------|-------------|
| Tabla | 128 | 20-30 |
| Campo | 128 | 15-25 |
| Vista | 128 | 25-35 |
| Índice | 128 | 30-40 |
| SP | 128 | 30-40 |

---

## 1. Nomenclatura de Tablas

**Referencia visual**: `docs/images/nomenclatura_Tabla.jpg`

### Formato

```
[AVP]_[ABR1]_[ABR2]_[ABR3]
```

### Reglas

1. ✅ **Usar solo abreviaturas oficiales** de `LIBMHVTMP.HBDAABRDID` (867 códigos)
2. ✅ **Validar con `UBDP_VALIDAR_NOMBRES`** antes de crear (OBLIGATORIO)
3. ✅ **Formato**: AVP + Tipo + 2 abreviaturas
4. ✅ **Tipos de objeto válidos**: 
   - **A** = Tabla (Archivo)
   - **I** = Índice
   - **T** = Trigger
   - **P** = Stored Procedure
   - **F** = Función
5. ❌ **No inventar abreviaturas** no oficiales
6. ❌ **No usar caracteres especiales**
7. ❌ **No crear sin validar** con el SP oficial

### Ejemplos Correctos

```sql
-- Ejemplo validado con SP oficial
-- Paso 1: Validar
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'CRM',      -- AVP
    'A',        -- Tipo: A=Tabla
    'RPT',      -- Primera abreviatura: Respuesta
    'ERR'       -- Segunda abreviatura: Error
);
-- Resultado: "Nombre correcto"

-- Paso 2: Crear tabla
CREATE TABLE PRODUCCION.CRMARPTERR (  -- CRM + A + RPT + ERR
    RPT_ID      BIGINT NOT NULL,
    ERR_COD     CHAR(5),
    ...
);

-- Más ejemplos validados
CREATE TABLE PRODUCCION.COREACTASAL (...)   -- CORE + A + CTA + SAL
CREATE TABLE PRODUCCION.TCAATRXPOS (...)    -- TCA + A + TRX + POS
CREATE TABLE PRODUCCION.CANAATMLOG (...)    -- CAN + A + ATM + LOG
```

### Ejemplos Incorrectos

```sql
-- ❌ Abreviatura no oficial
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('CRM', 'A', 'CUS', 'ERR');
-- Resultado: "** Nombre Incorrecto **"
-- CUS no existe en LIBMHVTMP.HBDAABRDID

CREATE TABLE PRODUCCION.CRMAACUSERR (...)  -- ❌ FALLARÍA validación

-- ❌ No validar antes de crear
CREATE TABLE PRODUCCION.MI_TABLA (...)  -- Sin llamar UBDP_VALIDAR_NOMBRES

-- ❌ Crear sin AVP
CREATE TABLE PRODUCCION.TRANSACCIONES (...)  -- Falta AVP

-- ❌ Tipo de objeto incorrecto
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('CRM', 'X', 'RPT', 'ERR');
-- 'X' no es tipo válido (solo A, I, T, P, F)
```

### Validación Obligatoria

```sql
-- PASO 1: Consultar AVP válido
CALL LIBMHV.UBDP_CONSULTA_AVP('CRM', ?);

-- PASO 2: Consultar abreviaturas (de tabla LIBMHVTMP.HBDAABRDID)
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('RPT', ?);  -- Respuesta
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('ERR', ?);  -- Error

-- PASO 3: Validar nombre propuesto (OBLIGATORIO)
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'CRM',      -- PAVP: Application/AVP
    'A',        -- POBJ: Tipo (A=Tabla, I=Indice, T=Trigger, P=Procedure, F=Funcion)
    'RPT',      -- PABR1: Primera abreviatura
    'ERR'       -- PABR2: Segunda abreviatura
);

-- Resultado esperado (2 filas):
-- Fila 1: CRM | A | RPT | ERR | Nombre correcto
-- Fila 2: Programas Relativos a SIEBEL-CRM | Tabla | Respuesta | Error, Fallos | Nombre correcto

-- PASO 4: Si aprueba, crear tabla
CREATE TABLE PRODUCCION.CRMARPTRERR (
    RPT_ID          BIGINT NOT NULL,
    ERR_COD         CHAR(5),
    -- Campos...
);
```

---

## 2. Nomenclatura de Campos

**Referencia visual**: `docs/images/nomenclatura_Campo.jpg`

### Formato

```
[ABR1]_[ABR2]_[ABR3]
```

**Nota**: Los campos NO incluyen AVP, solo abreviaturas descriptivas.

### Reglas

1. ✅ **Usar abreviaturas oficiales** de 3 caracteres
2. ✅ **Descriptivo del contenido** del campo
3. ✅ **Consistencia en toda la BD**: Mismo concepto = Mismo nombre
4. ✅ **Nombres cortos estándar** para campos de auditoría (ver abajo)
5. ❌ **No repetir el nombre de la tabla** en el campo
6. ❌ **No usar nombres genéricos** (`CAMPO1`, `VALOR`, `DATO`)

### Abreviaturas Comunes para Campos

| Código | Descripción | Ejemplo de Uso |
|--------|-------------|----------------|
| **COD** | Código alfanumérico | COD_CLI, COD_TRX |
| **NUM** | Número | NUM_CTA, NUM_TAR |
| **FEC** | Fecha | FEC_CRE, FEC_MOD, FEC_TRX |
| **TIP** | Tipo | TIP_CTA, TIP_DOC, TIP_TRX |
| **EST** | Estatus/Estado | EST_CTA, EST_TRX |
| **IND** | Indicador | IND_ACT, IND_VIG |
| **MTO** | Monto | MTO_TRX, MTO_SAL |
| **DES** | Descripción | DES_CTA, DES_TRX |
| **USR** | Usuario | USR_CRE, USR_MOD |
| **NOM** | Nombre | NOM_CLI, NOM_BAN |

### Campos de Auditoría Estándar (Obligatorios)

**TODOS los objetos deben incluir estos 4 campos**:

```sql
-- Nomenclatura corta para auditoría
USUARIOCREACION   FOR USRCRE CHAR(18),
FECHACREACION     FOR FECCRE TIMESTAMP DEFAULT CURRENT TIMESTAMP,
USUARIOMODIFICA   FOR USRMOD CHAR(18),
FECHAMODIFICA     FOR FECMOD TIMESTAMP
```

**Características**:
- `FOR` define el nombre corto (máximo 10 caracteres)
- Nombres largos descriptivos para claridad
- Nombres cortos para compatibilidad con sistemas legacy

### Ejemplos Correctos

```sql
CREATE TABLE PRODUCCION.CRM_CLI_TRX (
    -- Identificadores
    transaccion_id      FOR TRXID BIGINT NOT NULL,
    cliente_id          FOR CLIID BIGINT NOT NULL,
    cuenta_numero       FOR CTANUM BIGINT NOT NULL,
    
    -- Datos de negocio
    tipo_transaccion    FOR TIPTRX CHAR(2) NOT NULL,
    estatus_transaccion FOR ESTTRX CHAR(1) NOT NULL,
    monto_transaccion   FOR MTOTRX DECIMAL(15,2) NOT NULL,
    fecha_transaccion   FOR FECTRX DATE NOT NULL,
    codigo_autorizacion FOR CODAUT CHAR(6),
    descripcion_transaccion FOR DESTRX VARCHAR(200),
    
    -- Indicadores
    indicador_reversada FOR INDREV CHAR(1) NOT NULL DEFAULT 'N',
    indicador_fraude    FOR INDFRAU CHAR(1) NOT NULL DEFAULT 'N',
    
    -- Auditoría (OBLIGATORIOS)
    USUARIOCREACION     FOR USRCRE CHAR(18),
    FECHACREACION       FOR FECCRE TIMESTAMP DEFAULT CURRENT TIMESTAMP,
    USUARIOMODIFICA     FOR USRMOD CHAR(18),
    FECHAMODIFICA       FOR FECMOD TIMESTAMP,
    
    CONSTRAINT pk_cli_trx PRIMARY KEY (transaccion_id)
);
```

### Ejemplos Incorrectos

```sql
-- ❌ Nombres genéricos sin significado
campo1              INT,
valor               VARCHAR(100),
dato                CHAR(10),

-- ❌ Nombres demasiado largos sin abreviaturas
codigo_identificador_unico_cliente        BIGINT,
fecha_de_la_transaccion_procesada         DATE,

-- ❌ Repetir nombre de la tabla
cli_trx_cliente_id          BIGINT,  -- Redundante "cli_trx_"
cli_trx_transaccion_fecha   DATE,    -- Redundante "cli_trx_"

-- ❌ Inconsistencia regional
cliente_codigo      -- En una tabla
cod_cliente         -- En otra tabla (DEBE ser consistente)
```

---

## 3. Nomenclatura de Vistas

**Referencia visual**: `docs/images/nomenclatura_Vista.jpg`

### Formato

```
V_[AVP]_[ABR1]_[ABR2]
```

**Prefijo**: `V_` indica que es una vista

### Reglas

1. ✅ **Prefijo obligatorio** `V_`
2. ✅ **Seguir mismo patrón** que tablas (AVP + abreviaturas)
3. ✅ **Nombre descriptivo** del propósito de la vista
4. ⚠️ **NOTA:** `UBDP_VALIDAR_NOMBRES` NO soporta tipo 'VISTA' - validar manualmente

### Ejemplos Correctos

```sql
-- Vistas de consulta
CREATE VIEW PRODUCCION.V_CRM_CLI_ACT AS
SELECT * FROM CRM_CLI_MAESTRO WHERE IND_ACT = 'S';

CREATE VIEW PRODUCCION.V_CORE_CTA_SAL AS
SELECT CTA_NUM, SUM(MTO_MOV) AS SALDO
FROM CORE_CTA_MOV
GROUP BY CTA_NUM;

-- Vistas de seguridad (ocultan datos sensibles)
CREATE VIEW PRODUCCION.V_CRM_CLI_PUB AS
SELECT CLI_ID, NOM_CLI, 
       CONCAT(LEFT(NUM_DOC, 4), '****') AS NUM_DOC_MASKED
FROM CRM_CLI_MAESTRO;
```

### Validación

⚠️ **IMPORTANTE**: El stored procedure `UBDP_VALIDAR_NOMBRES` NO soporta vistas.

```sql
-- Para vistas, validar manualmente:
-- 1. Verificar AVP con UBDP_CONSULTA_AVP
-- 2. Verificar abreviaturas con UBDP_CONSULTA_ABREVIATURAS
-- 3. Seguir convención de nomenclatura V_[AVP][ABR1][ABR2]
```

---

## 4. Nomenclatura de Vistas Lógicas

**Referencia visual**: `docs/images/nomenclatura_VistaLogica.jpg`

### Formato DB2 for i

```
L[Versión]_[TABLA_ORIGEN]
```

**Características**:
- `L` indica vista lógica
- Versión numérica incremental (1, 2, 3...)
- Nombre de la tabla origen

### Reglas

1. ✅ **Prefijo `L` + número de versión**
2. ✅ **Crear nueva versión** cada vez que se modifica la tabla origen
3. ✅ **Mantener versiones anteriores** para compatibilidad
4. ✅ **Mismo esquema/biblioteca** que la tabla origen

### Ejemplos Correctos

```sql
-- Tabla original
CREATE TABLE PRODUCCION.CRM_CLI_MAESTRO (
    CLI_ID      BIGINT,
    NOM_CLI     VARCHAR(100),
    TIP_CLI     CHAR(2)
);

-- Primera vista lógica
CREATE VIEW PRODUCCION.L1_CRM_CLI_MAESTRO AS
SELECT CLI_ID, NOM_CLI, TIP_CLI
FROM PRODUCCION.CRM_CLI_MAESTRO;

-- Se agrega campo a la tabla
ALTER TABLE PRODUCCION.CRM_CLI_MAESTRO
    ADD COLUMN FEC_NAC DATE;

-- Nueva vista lógica (L2) con el campo nuevo
CREATE VIEW PRODUCCION.L2_CRM_CLI_MAESTRO AS
SELECT CLI_ID, NOM_CLI, TIP_CLI, FEC_NAC
FROM PRODUCCION.CRM_CLI_MAESTRO;

-- L1 sigue existiendo para aplicativos legacy
```

### Importancia

- 📌 **Compatibilidad**: Aplicativos antiguos siguen funcionando con L1
- 📌 **Migración gradual**: Nuevos aplicativos usan L2
- 📌 **Sin recompilación**: No requiere recompilar programas

---

## 5. Nomenclatura de Índices

**Referencia visual**: `docs/images/nomenclatura_Indice.jpg`

### Tipos de Índices

#### A. Índices Funcionales

```
IXF_[TABLA]_[CAMPOS]
```

**Propósito**: Uso explícito por aplicativos (ORDER BY, accesos ordenados, etc.)

```sql
-- Índice para ORDER BY
CREATE INDEX PRODUCCION.IXF_CLI_TRX_FEC
    ON CRM_CLI_TRX (FEC_TRX DESC);

-- Índice compuesto
CREATE INDEX PRODUCCION.IXF_CLI_TRX_CLI_FEC
    ON CRM_CLI_TRX (CLI_ID, FEC_TRX);
```

#### B. Índices de Performance

```
IXP_[TABLA]_[CAMPOS]_[AÑO]_RFC[NUM]
```

**Propósito**: Mejora de rendimiento, no usado explícitamente por aplicativos

```sql
-- Índice de performance para optimizar consulta
CREATE INDEX PRODUCCION.IXP_CLI_TRX_EST_2026_RFC12345
    ON CRM_CLI_TRX (EST_TRX, FEC_TRX)
    WHERE EST_TRX = 'P';  -- Solo pendientes
```

### Reglas

1. ✅ **IXF** para funcionales (pase a producción normal)
2. ✅ **IXP** para performance (vía RFC con año y número)
3. ✅ **Nombres descriptivos** de los campos indexados
4. ✅ **NO usar atributo UNIQUE** en índice (usar CONSTRAINT UNIQUE en tabla)
5. ❌ **No crear índices** sin justificación técnica

### Validación

```sql
-- Validar nombre de índice funcional
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'CRM',       -- AVP
    'INDICE',    -- Tipo de objeto
    'CLI',       -- Tabla
    'TRX'        -- Campo o propósito
);
```

---

## 6. Nomenclatura de Stored Procedures

**Referencia visual**: `docs/images/nomenclatura_StoredProcedure.jpg`

### Formato

```
[AVP]_[VERBO]_[ABR1]_[ABR2]
```

**Verbos comunes**: `INS`, `UPD`, `DEL`, `SEL`, `PROC`, `CALC`, `VAL`

### Reglas

1. ✅ **Iniciar con AVP**
2. ✅ **Verbo de acción** claro
3. ✅ **Abreviaturas descriptivas**
4. ✅ **Validar con `UBDP_VALIDAR_NOMBRES`** tipo **'P'** (Stored Procedure)
5. ✅ **Documentar parámetros** con metadata

### Ejemplos Correctos

```sql
-- Procedimiento de inserción
CREATE PROCEDURE PRODUCCION.CRM_INS_CLI_TRX (
    IN p_cli_id         BIGINT,
    IN p_mto_trx        DECIMAL(15,2),
    OUT p_trx_id        BIGINT,
    OUT p_cod_error     CHAR(5),
    OUT p_msg_error     VARCHAR(200)
)
LANGUAGE SQL
BEGIN
    -- Lógica de inserción
END;

-- Procedimiento de cálculo
CREATE PROCEDURE PRODUCCION.CORE_CALC_CTA_SAL (
    IN p_cta_num        BIGINT,
    IN p_fec_corte      DATE,
    OUT p_saldo         DECIMAL(15,2)
)
LANGUAGE SQL
BEGIN
    -- Cálculo de saldo
END;

-- Procedimiento de validación
CREATE PROCEDURE PRODUCCION.TCA_VAL_TAR_LIM (
    IN p_tar_num        BIGINT,
    IN p_mto_trx        DECIMAL(15,2),
    OUT p_aprobado      CHAR(1),
    OUT p_motivo        VARCHAR(100)
)
LANGUAGE SQL
BEGIN
    -- Validación de límite
END;
```

### Verbos Estándar

| Verbo | Significado | Uso |
|-------|-------------|-----|
| **INS** | Insert | Insertar registros |
| **UPD** | Update | Actualizar registros |
| **DEL** | Delete | Eliminar registros |
| **SEL** | Select | Consultar datos |
| **PROC** | Process | Procesar lógica compleja |
| **CALC** | Calculate | Calcular valores |
| **VAL** | Validate | Validar datos |
| **GEN** | Generate | Generar archivos/reportes |

### Validación

```sql
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'CRM',              -- AVP
    'PROCEDURE',        -- Tipo
    'INS',              -- Verbo
    'CLI'               -- Objeto
);
```

---

## 7. Nomenclatura de Funciones

**Referencia visual**: `docs/images/nomenclatura_Funcion.jpg`

### Formato

```
FN_[AVP]_[ABR1]_[ABR2]
```

**Prefijo**: `FN_` indica función

### Reglas

1. ✅ **Prefijo obligatorio** `FN_`
2. ✅ **Nombre descriptivo** de lo que retorna
3. ✅ **Validar con `UBDP_VALIDAR_NOMBRES`** tipo **'F'** (Función)
4. ✅ **Determinística** cuando sea posible

### Ejemplos Correctos

```sql
-- Función de cálculo
CREATE FUNCTION PRODUCCION.FN_CORE_CALC_INTERES (
    p_monto         DECIMAL(15,2),
    p_tasa          DECIMAL(7,4),
    p_dias          INT
)
RETURNS DECIMAL(15,2)
LANGUAGE SQL
DETERMINISTIC
BEGIN
    RETURN (p_monto * p_tasa * p_dias) / 36000;
END;

-- Función de validación
CREATE FUNCTION PRODUCCION.FN_CRM_VAL_EMAIL (
    p_email         VARCHAR(100)
)
RETURNS CHAR(1)  -- 'S' o 'N'
LANGUAGE SQL
DETERMINISTIC
BEGIN
    IF p_email LIKE '%_@__%.__%' THEN
        RETURN 'S';
    ELSE
        RETURN 'N';
    END IF;
END;

-- Función de transformación
CREATE FUNCTION PRODUCCION.FN_CRM_MASK_DOC (
    p_documento     VARCHAR(20)
)
RETURNS VARCHAR(20)
LANGUAGE SQL
DETERMINISTIC
BEGIN
    RETURN CONCAT(LEFT(p_documento, 4), 
                  REPEAT('*', LENGTH(p_documento) - 6),
                  RIGHT(p_documento, 2));
END;
```

---

## 8. Nomenclatura de Triggers

**Referencia visual**: `docs/images/nomenclatura_Trigger.jpg`

### Formato

```
TR[Momento]_[AVP]_[TABLA]_[ACCION]
```

**Momento**: 
- `TRB` = BEFORE
- `TRA` = AFTER
- `TRI` = INSTEAD OF (para vistas)

**Acción**: `INS`, `UPD`, `DEL`

### Reglas

1. ✅ **Prefijo** según momento de ejecución
2. ✅ **Incluir tabla** afectada
3. ✅ **Especificar acción** (INSERT/UPDATE/DELETE)
4. ✅ **Validar con `UBDP_VALIDAR_NOMBRES`** tipo **'T'** (Trigger)
5. ⚠️ **Usar con precaución** (impacto en performance)

### Ejemplos Correctos

```sql
-- Trigger BEFORE INSERT para auditoría
CREATE TRIGGER PRODUCCION.TRB_CRM_CLI_TRX_INS
    BEFORE INSERT ON CRM_CLI_TRX
    REFERENCING NEW AS N
    FOR EACH ROW
    SET N.USRCRE = CURRENT USER,
        N.FECCRE = CURRENT TIMESTAMP;

-- Trigger AFTER UPDATE para bitácora
CREATE TRIGGER PRODUCCION.TRA_CRM_CLI_MAESTRO_UPD
    AFTER UPDATE ON CRM_CLI_MAESTRO
    REFERENCING OLD AS O NEW AS N
    FOR EACH ROW
    INSERT INTO CRM_CLI_MAESTRO_HIST
    VALUES (O.CLI_ID, O.NOM_CLI, ..., CURRENT TIMESTAMP);

-- Trigger INSTEAD OF para vistas
CREATE TRIGGER PRODUCCION.TRI_V_CRM_CLI_DEL
    INSTEAD OF DELETE ON V_CRM_CLI_ACT
    REFERENCING OLD AS O
    FOR EACH ROW
    UPDATE CRM_CLI_MAESTRO 
    SET IND_ACT = 'N' 
    WHERE CLI_ID = O.CLI_ID;
```

### Validación

```sql
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'CRM',         -- AVP
    'T',           -- Tipo = Trigger
    'CLI',         -- Tabla
    'INS'          -- Acción
);
```

---

## 9. Nomenclatura de Secuencias

**Referencia visual**: `docs/images/nomenclatura_Secuencia.jpg`

### Formato

```
SEQ_[AVP]_[TABLA]_[CAMPO]
```

**Prefijo**: `SEQ_` indica secuencia

### Reglas

1. ✅ **Prefijo obligatorio** `SEQ_`
2. ✅ **Relacionar con tabla** que usa la secuencia
3. ✅ **Especificar campo** que poblará
4. ⚠️ **NOTA:** `UBDP_VALIDAR_NOMBRES` NO soporta tipo 'SECUENCIA' - validar manualmente
5. ⚠️ **Coordinar con DBA** para replicación y contingencia

### Ejemplos Correctos

```sql
-- Secuencia para llave primaria
CREATE SEQUENCE PRODUCCION.SEQ_CRM_CLI_TRX_ID
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO CYCLE
    CACHE 20;

-- Uso en INSERT
INSERT INTO PRODUCCION.CRM_CLI_TRX (
    TRX_ID,
    CLI_ID,
    MTO_TRX,
    ...
)
VALUES (
    NEXT VALUE FOR SEQ_CRM_CLI_TRX_ID,
    123456,
    1000.00,
    ...
);

-- Secuencia para números de referencia
CREATE SEQUENCE PRODUCCION.SEQ_CORE_CTA_NUM
    START WITH 1000000
    INCREMENT BY 1
    MAXVALUE 9999999
    NO CYCLE
    CACHE 100;
```

### Validación

⚠️ **IMPORTANTE**: El stored procedure `UBDP_VALIDAR_NOMBRES` NO soporta secuencias.

```sql
-- Para secuencias, validar manualmente:
-- 1. Verificar AVP con UBDP_CONSULTA_AVP
-- 2. Verificar abreviaturas con UBDP_CONSULTA_ABREVIATURAS
-- 3. Seguir convención de nomenclatura SEQ_[AVP][TABLA][CAMPO]
```

---

## 10. Nomenclatura de Constraints

**Referencia visual**: `docs/images/nomenclatura_Constraint.jpg`

### Formatos según Tipo

```
pk_[TABLA]                          -- Primary Key
fk_[TABLA]_[TABLA_REF]              -- Foreign Key
ck_[TABLA]_[CAMPO]                  -- Check Constraint
uq_[TABLA]_[CAMPO(S)]               -- Unique Constraint
df_[TABLA]_[CAMPO]                  -- Default Constraint
```

### Reglas

1. ✅ **Nombres explícitos SIEMPRE** (no permitir generación automática)
2. ✅ **Prefijos estándar** según tipo
3. ✅ **Descriptivo** de la restricción
4. ❌ **NO permitir** nombres generados por el motor (SYS_C0012345)

### Ejemplos Correctos

```sql
CREATE TABLE PRODUCCION.CRM_CLI_TRX (
    TRX_ID              BIGINT          NOT NULL,
    CLI_ID              BIGINT          NOT NULL,
    CTA_NUM             BIGINT          NOT NULL,
    TIP_TRX             CHAR(2)         NOT NULL,
    EST_TRX             CHAR(1)         NOT NULL,
    MTO_TRX             DECIMAL(15,2)   NOT NULL,
    
    -- PRIMARY KEY
    CONSTRAINT pk_cli_trx 
        PRIMARY KEY (TRX_ID),
    
    -- CHECK CONSTRAINTS
    CONSTRAINT ck_cli_trx_tip 
        CHECK (TIP_TRX IN ('DB', 'CR', 'TF', 'PG')),
        
    CONSTRAINT ck_cli_trx_est 
        CHECK (EST_TRX IN ('P', 'A', 'R', 'C')),
        
    CONSTRAINT ck_cli_trx_mto 
        CHECK (MTO_TRX >= 0),
    
    -- UNIQUE CONSTRAINT
    CONSTRAINT uq_cli_trx_ref_ext 
        UNIQUE (REFERENCIA_EXTERNA)
);

-- FOREIGN KEYS (después de la tabla)
ALTER TABLE PRODUCCION.CRM_CLI_TRX
    ADD CONSTRAINT fk_cli_trx_cli
    FOREIGN KEY (CLI_ID)
    REFERENCES CRM_CLI_MAESTRO(CLI_ID)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;

ALTER TABLE PRODUCCION.CRM_CLI_TRX
    ADD CONSTRAINT fk_cli_trx_cta
    FOREIGN KEY (CTA_NUM)
    REFERENCES CORE_CTA_MAESTRO(CTA_NUM)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;
```

### Estándar de Prefijos

| Tipo | Prefijo | Ejemplo |
|------|---------|---------|
| Primary Key | `pk_` | `pk_cli_trx` |
| Foreign Key | `fk_` | `fk_cli_trx_cli` |
| Check | `ck_` | `ck_cli_trx_est` |
| Unique | `uq_` | `uq_cli_email` |
| Default | `df_` | `df_cli_est` |

---

## 11. Nomenclatura de Scripts

**Referencia visual**: `docs/images/nomenclatura_Scripts.jpg`

### Formato

```
[TIPO]_[AVP]_[DESCRIPCION]_[VERSION].sql
```

**Tipos comunes**:
- `CRE` = Create (creación de objetos)
- `ALT` = Alter (modificaciones)
- `DRP` = Drop (eliminaciones)
- `INS` = Insert (carga de datos)
- `UPD` = Update (actualización de datos)
- `MIG` = Migration (migraciones)
- `RBK` = Rollback (scripts de reversión)

### Reglas

1. ✅ **Prefijo de tipo** de operación
2. ✅ **Incluir AVP** o alcance
3. ✅ **Descripción breve** del propósito
4. ✅ **Versión o fecha** para control
5. ✅ **Extensión `.sql`**

### Ejemplos Correctos

```
-- Scripts de creación
CRE_CRM_CLI_TRX_V1.sql
CRE_CORE_CTA_MAESTRO_V2.sql

-- Scripts de alteración
ALT_CRM_CLI_MAESTRO_ADD_FEC_NAC_V1.sql
ALT_TCA_TAR_CONFIG_UPD_LIMITES_V3.sql

-- Scripts de migración
MIG_CRM_CLI_LEGACY_TO_NEW_2026Q1.sql
MIG_CORE_CUENTAS_UNIFICACION_V2.sql

-- Scripts de datos
INS_CAT_MONEDAS_INICIAL.sql
UPD_CAT_PAISES_CODIGOS_ISO.sql

-- Scripts de rollback
RBK_CRM_CLI_TRX_V1.sql
RBK_MIG_CORE_CUENTAS_V2.sql

-- Scripts de RFC
RFC_12345_UPD_CRM_CLI_SALDOS_2026.sql
RFC_12346_INS_CORE_CTA_AJUSTES_2026.sql
```

### Estructura Interna del Script

```sql
---
-- CRE_CRM_CLI_TRX_V1: Crear tabla de transacciones de clientes CRM
--
-- Script de creación para tabla de transacciones de clientes en
-- sistema CRM. Incluye validaciones de pre-requisitos, metadata
-- completa y verificación post-creación.
--
-- Pre-requisitos:
--   1. Tabla CRM_CLI_MAESTRO debe existir
--   2. Tabla CORE_CTA_MAESTRO debe existir
--   3. Usuario debe tener privilegios de CREATE en PRODUCCION
--
-- @author Arquitectura de Datos
-- @date 2026-03-04
-- @project CRM-1234
-- @version v1.0
---

-- Verificar pre-requisitos
SELECT COUNT(*) FROM QSYS2.SYSTABLES 
WHERE TABLE_SCHEMA = 'PRODUCCION' 
  AND TABLE_NAME = 'CRM_CLI_MAESTRO';

-- Crear tabla
CREATE TABLE PRODUCCION.CRM_CLI_TRX (
    -- Definición de campos
    ...
);

-- Metadata
COMMENT ON TABLE PRODUCCION.CRM_CLI_TRX IS '...';

-- Constraints
ALTER TABLE PRODUCCION.CRM_CLI_TRX
    ADD CONSTRAINT fk_cli_trx_cli ...;

-- Verificación post-creación
SELECT TABLE_NAME, CREATE_TIME 
FROM QSYS2.SYSTABLES
WHERE TABLE_SCHEMA = 'PRODUCCION'
  AND TABLE_NAME = 'CRM_CLI_TRX';
```

---

## Catálogo de Abreviaturas

⚠️ **IMPORTANTE**: Este skill NO debe contener abreviaturas hardcodeadas. Todas las abreviaturas deben obtenerse dinámicamente usando el stored procedure oficial.

### Cómo Consultar Abreviaturas

**Fuente oficial**: Tabla `LIBMHVTMP.HBDAABRDID` con **867 códigos oficiales**

⚠️ **NO usar** `LIBMHV.ABREVIA` - la tabla correcta es `LIBMHVTMP.HBDAABRDID`

**Método correcto**: Consultar por **concepto de negocio**, NO por código directo

```sql
-- ✅ CORRECTO: Buscar por concepto de negocio
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'maestro');
-- Retorna: MST | Maestro | Maestro

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'transacción');
-- Retorna: TRN | Transacción | Transacción

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'cliente');
-- Puede retornar múltiples opciones:
-- CIF | Customer Information File
-- CTE | Cliente
-- CLI | Cliente
-- Seleccionar automáticamente la más apropiada según contexto

-- ❌ INCORRECTO: NO hardcodear abreviaturas en el código
-- NO hacer: "usar CLI para cliente" sin consultar el SP
```

### Selección Automática de Abreviaturas

Cuando `UBDP_CONSULTA_ABREVIATURAS` retorna **múltiples resultados**:

1. **Analizar el contexto** del requerimiento
2. **Seleccionar automáticamente** la opción más apropiada
3. **Priorizar**:
   - Términos en español (CLI) sobre inglés (CIF)
   - Descripciones exactas sobre descripciones parciales
   - Abreviaturas de 3 caracteres (estándar)

**Ejemplo**:
```sql
-- Usuario dice: "maestro de clientes"
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'cliente');
-- Retorna: CLI | Cliente | ...
--          CIF | Customer Information File | ...
--          CTE | Cliente | ...
-- SELECCIONAR: CLI (término en español, descripción exacta)
```

### Consultar Catálogo Completo

```sql
-- Ver todas las 867 abreviaturas oficiales
SELECT CODABR, DESABR, NOTABR
FROM LIBMHVTMP.HBDAABRDID
ORDER BY CODABR;

-- Buscar abreviatura por descripción
SELECT CODABR, DESABR
FROM LIBMHVTMP.HBDAABRDID
WHERE UPPER(DESABR) LIKE '%CLIENTE%';

-- Buscar por código
SELECT CODABR, DESABR, NOTABR
FROM LIBMHVTMP.HBDAABRDID
WHERE CODABR = 'RPT';
```

---

## Validación con Stored Procedures

### 1. UBDP_CONSULTA_AVP

**Propósito**: Obtener la AVP (Application Version Production) a la que pertenece el objeto

**Parámetros**:
```sql
PCOD    CHAR(10)     IN      -- Código de AVP (vacío '' para búsqueda)
PNOM    VARCHAR(100) IN      -- Nombre de aplicación (cuando PCOD='')
```

**Retorna**: Tabla con columnas AVP, DESCRIPCION, TIPO

**Uso**:
```sql
-- Opción 1: Verificar AVP específico
CALL LIBMHV.UBDP_CONSULTA_AVP('CRM', '');
-- Retorna: CRM | Programas Relativos a SIEBEL-CRM | PDE

-- Opción 2: Buscar AVPs por nombre de aplicación
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'BRIDGER');
-- Retorna múltiples opciones:
-- BBRI | (Bridger Banca)                              | PDE
-- CBRI | (Objetos de interfaz Bridger)                | PDE
-- CENB | (Objetos de Base de Datos de Envio Bridger.) | PDE
-- TBRI | (Bridger Tarjetas)                           | PDE

CALL LIBMHV.UBDP_CONSULTA_AVP('', 'SIEBEL');
-- Retorna: CRM | Programas Relativos a SIEBEL-CRM | PDE
```

**Cuándo usar**: Al inicio del diseño, para confirmar que el AVP del proyecto existe en el catálogo oficial o para descubrir el código AVP cuando solo conoces el nombre de la aplicación.

---

### 2. UBDP_CONSULTA_ABREVIATURAS

**Propósito**: Obtener la abreviatura correspondiente del catálogo de **867 códigos oficiales** de la tabla `LIBMHVTMP.HBDAABRDID`

**Parámetros**:
```sql
PCOD    CHAR(3)      IN      -- Código de abreviatura (vacío '' para búsqueda)
PTERM   VARCHAR(100) IN      -- Término de búsqueda (cuando PCOD='')  
```

**Retorna**: Tabla con columnas CODIGO_ABREVIATURA, DESCRIPCION, NOTAS_VARIAS

**Uso**:
```sql
-- Opción 1: Consultar código específico
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('RPT', '');
-- Retorna: RPT | Respuesta | ...

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('ERR', '');
-- Retorna: ERR | Error, Fallos | ...

-- Opción 2: Buscar por término de negocio
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'Cliente');
-- Retorna múltiples opciones:
-- CIF | Customer Information File
-- CTE | Cliente
-- POS | POS (Maquina o terminal para clientes)
-- CEM | CoEmisor (Entidad con clientes)
-- ... más resultados relacionados

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'Respuesta');
-- Retorna: RPT | Respuesta | ...

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'Error');
-- Retorna: ERR | Error, Fallos | ...
```

**Cuándo usar**: Durante el diseño, cuando necesites identificar las abreviaturas oficiales para construir nombres de objetos.

---

### UBDP_VALIDAR_NOMBRES

**Propósito**: Validar que el nombre del objeto cumpla con los estándares BAC según formato **[AVP][TIPO][ABR1][ABR2]**

**Stored Procedure**: `LIBMHV.UBDP_VALIDAR_NOMBRES` (SPECIFIC_NAME: `UBDPVALNMB`)

**Parámetros**:
```sql
PAVP    CHAR(10)  IN   -- Aplicación/AVP (validado contra LIBMHV3.DD_APPBCO + PDE400.APPMST)
POBJ    CHAR(10)  IN   -- Tipo de objeto: 'A', 'I', 'T', 'P', 'F' (códigos de 1 letra)
PABR1   CHAR(10)  IN   -- Primera abreviatura (validada contra LIBMHVTMP.HBDAABRDID)
PABR2   CHAR(10)  IN   -- Segunda abreviatura (validada contra LIBMHVTMP.HBDAABRDID)
```

**Tipos de objeto válidos** (códigos de 1 letra):
- **'A'** = Tabla (Archivo)
- **'I'** = Índice
- **'T'** = Trigger
- **'P'** = Stored Procedure
- **'F'** = Función

⚠️ **NO soportados**: Vistas, Secuencias, Campos (validar manualmente)

**Retorno**: 2 filas con valores ingresados y sus descripciones traducidas
- Fila 1: PAVP | POBJ | PABR1 | PABR2 | Mensaje de validación
- Fila 2: Descripción AVP | Descripción tipo | Descripción ABR1 | Descripción ABR2 | Mensaje de validación

**Uso**:
```sql
-- ✅ EJEMPLO CORRECTO: Validar tabla CRMARPTRERR
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'CRM',      -- AVP: Customer Relationship Management
    'A',        -- Tipo: A=Tabla (Archivo)
    'RPT',      -- Primera abreviatura: Respuesta
    'ERR'       -- Segunda abreviatura: Error
);

-- Resultado:
-- Fila 1: CRM | A | RPT | ERR | Nombre correcto
-- Fila 2: Programas Relativos a SIEBEL-CRM | Tabla | Respuesta | Error, Fallos | Nombre correcto

-- Si válido, proceder a crear tabla CRMARPTRERR
CREATE TABLE PRODUCCION.CRMARPTRERR (
    RPT_ID          BIGINT NOT NULL,
    ERR_COD         CHAR(5) NOT NULL,
    MTO_RPT         DECIMAL(15,2) NOT NULL,
    ...
    CONSTRAINT pk_rpt_err PRIMARY KEY (RPT_ID)
);

-- ✅ EJEMPLO CORRECTO: Validar índice
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'CRM',       -- AVP
    'I',         -- Tipo: I=Índice
    'RPT',       -- Tabla/Componente
    'ERR'        -- Campo/Propósito
);

-- Si válido, crear índice:
CREATE INDEX PRODUCCION.IXF_RPTRERR_FEC
    ON CRMARPTRERR (FEC_ERR DESC);

-- ✅ EJEMPLO CORRECTO: Validar stored procedure
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'CRM',        -- AVP
    'P',          -- Tipo: P=Stored Procedure
    'INS',        -- Verbo: Insert
    'RPT'         -- Objeto: Respuesta
);

-- Si válido, crear SP: CRMAPINSRPT
CREATE PROCEDURE PRODUCCION.CRMAPINSRPT (...)

-- ❌ EJEMPLO INCORRECTO: Abreviatura no existe
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('CRM', 'A', 'CUS', 'ERR');
-- Resultado: ** Nombre Incorrecto ** (CUS no existe en LIBMHVTMP.HBDAABRDID)
```

**Cuándo usar**: **SIEMPRE** antes de ejecutar el CREATE del objeto. Es obligatorio validar nomenclatura antes de la creación.

---

## Workflow de Validación Completo

### Paso a Paso: Crear una Tabla

**Ejemplo Real**: Usuario solicita "tabla bac para maestro de transacciones para bridger"

```sql
-- FASE 1: Buscar y Verificar AVP
-- Si solo conoces el nombre de la aplicación (ej: "bridger"):
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'bridger');
-- Retorna múltiples opciones:
--   BBRI | (Bridger Banca)                              | PDE
--   CBRI | (Objetos de interfaz Bridger)                | PDE
--   CENB | (Objetos de Base de Datos de Envio Bridger.) | PDE
--   TBRI | (Bridger Tarjetas)                           | PDE

-- SELECCIONAR automáticamente la más apropiada según contexto
-- Para "maestro de transacciones" bancarias → BBRI (Bridger Banca)

-- Verificar AVP elegido:
CALL LIBMHV.UBDP_CONSULTA_AVP('BBRI', '');
-- Si retorna fila, AVP es válido

-- FASE 2: Buscar Abreviaturas por CONCEPTO DE NEGOCIO
-- Usuario dice: "maestro de transacciones"
-- Traducir a conceptos individuales: "maestro" + "transacción"

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'maestro');
-- Retorna: MST | Maestro | Maestro

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'transacción');
-- Retorna: TRN | Transacción | Transacción

-- Verificar códigos elegidos:
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('MST', '');
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('TRN', '');

-- Estructura del nombre: BBRI + A (Tabla) + MST + TRN = BBRIAMSTTRN

-- FASE 3: Validar Nombre Propuesto
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'BBRI',     -- PAVP: AVP validado en Fase 1
    'A',        -- POBJ: Tipo (A=Tabla, I=Indice, T=Trigger, P=Procedure, F=Funcion)
    'MST',      -- PABR1: Primera abreviatura validada en Fase 2
    'TRN'       -- PABR2: Segunda abreviatura validada en Fase 2
);

-- Resultado esperado:
-- Fila 1: BBRI | A | MST | TRN | Nombre correcto
-- Fila 2: (Bridger Banca) | Tabla | Maestro | Transacción | Nombre correcto

---
-- BBRIAMSTTRN: Maestro de transacciones de Bridger
--
-- Tabla que almacena el catálogo de transacciones de Bridger Banca.
-- Incluye código de transacción, descripción, tipo de operación,
-- restricciones de uso y campos de auditoría completa.
--
-- @author Arquitectura de Datos
-- @date 2026-03-04
-- @project BRIDGER-001
-- @version v1.0
---

-- FASE 4: Generar Archivo .sql (NO ejecutar CREATE directamente)
-- Archivo destino: docs/sql/CRE_BBRI_MST_TRN_V1.sql

CREATE TABLE PRODUCCION.BBRIAMSTTRN (
    MST_TRN_ID          BIGINT          NOT NULL,
    TRN_COD             CHAR(8)         NOT NULL,
    TRN_DES             VARCHAR(200),
    TRN_TIPO            CHAR(3)         NOT NULL,
    TRN_EST             CHAR(1)         NOT NULL DEFAULT 'A',
    
    -- Auditoría obligatoria
    USUARIOCREACION     FOR USRCRE CHAR(18),
    FECHACREACION       FOR FECCRE TIMESTAMP DEFAULT CURRENT TIMESTAMP,
    USUARIOMODIFICA     FOR USRMOD CHAR(18),
    FECHAMODIFICA       FOR FECMOD TIMESTAMP,
    
    CONSTRAINT pk_mst_trn PRIMARY KEY (MST_TRN_ID),
    CONSTRAINT uk_mst_trn_cod UNIQUE (TRN_COD)
);

-- FASE 5: Documentar
COMMENT ON TABLE PRODUCCION.BBRIAMSTTRN IS
    'Maestro de transacciones de Bridger Banca';

COMMENT ON COLUMN PRODUCCION.BBRIAMSTTRN.MST_TRN_ID IS
    'Identificador único del maestro de transacciones';

COMMENT ON COLUMN PRODUCCION.BBRIAMSTTRN.TRN_COD IS
    'Código de la transacción (8 caracteres)';

COMMENT ON COLUMN PRODUCCION.BBRIAMSTTRN.TRN_DES IS
    'Descripción de la transacción';
    
-- ... continuar con todos los campos

-- FASE 6: Validar Nombres de Índices
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'CRM',
    'I',        -- I=Índice
    'RPT',
    'ERR'
);

-- Crear índice funcional
CREATE INDEX PRODUCCION.IXF_RPTRERR_FEC
    ON CRMARPTRERR (FEC_ERR DESC);
```

---

## Resumen de Prefijos

| Objeto | Formato | Ejemplo Real |
|--------|---------|---------|
| **Tabla** | `[AVP][A][ABR1][ABR2]` | `CRMARPTRERR` (CRM + A + RPT + ERR) |
| **Vista** | `V_[AVP][ABR1][ABR2]` | `V_CRMRPTERR` |
| **Vista Lógica** | `L[num]_[AVP][ABR1][ABR2]` | `L2_CRMRPTERR` |
| **Índice Funcional** | `IXF_[ABR1][ABR2]_[CAMPO]` | `IXF_RPTRERR_FEC` |
| **Índice Performance** | `IXP_[ABR1][ABR2]_[DESC]` | `IXP_RPTRERR_EST_2026_RFC123` |
| **Stored Procedure** | `[AVP][P][VRB][ABR]` | `CRMPINSRPT` (CRM + P + INS + RPT) |
| **Función** | `FN_[AVP][ACT][ABR]` | `FN_CORECALCINT` |
| **Trigger Before** | `TRB_[AVP][ABR1][ABR2]_[ACT]` | `TRB_CRMRPTERR_INS` |
| **Trigger After** | `TRA_[AVP][ABR1][ABR2]_[ACT]` | `TRA_COREACTASAL_UPD` |
| **Trigger Instead Of** | `TRI_V_[AVP][ABR]_[ACT]` | `TRI_V_CRMRPT_DEL` |
| **Secuencia** | `SEQ_[AVP][ABR1][ABR2]_[ID]` | `SEQ_CRMARPTRERR_ID` |
| **Primary Key** | `pk_[abr1]_[abr2]` | `pk_rpt_err` |
| **Foreign Key** | `fk_[tabla]_[tabla_ref]` | `fk_rptrerr_rpt` |
| **Check** | `ck_[tabla]_[campo]` | `ck_rptrerr_est` |
| **Unique** | `uq_[tabla]_[campo]` | `uq_rpt_cod` |
| **Default** | `df_[tabla]_[campo]` | `df_rpt_est` |

---

## Checklist de Nomenclatura

Antes de enviar a revisión DBA, verificar:

- [ ] AVP válido consultado con `UBDP_CONSULTA_AVP`
- [ ] Abreviaturas consultadas con `UBDP_CONSULTA_ABREVIATURAS`
- [ ] Nombre validado con `UBDP_VALIDAR_NOMBRES`
- [ ] Prefijos correctos según tipo de objeto
- [ ] Longitud de nombres razonable (20-40 caracteres)
- [ ] Sin caracteres especiales (solo `_`)
- [ ] Sin guiones bajos dobles (`__`)
- [ ] Constraints con nombres explícitos
- [ ] Índices con nomenclatura IXF o IXP según corresponda
- [ ] Scripts con formato `TIPO_AVP_DESCRIPCION_VVERSION.sql`
- [ ] Campos de auditoría con nombres estándar (USRCRE, FECCRE, USRMOD, FECMOD)

---

**Fin de Nomenclaturas Oficiales BAC Credomatic**

**Última actualización**: Marzo 4, 2026  
**Fuente oficial**: `LIBMHVTMP.HBDAABRDID` (867 abreviaturas)  
**Stored Procedures**: `LIBMHV.UBDP_CONSULTA_AVP`, `UBDP_CONSULTA_ABREVIATURAS`, `UBDP_VALIDAR_NOMBRES`  
**Referencias visuales**: `docs/images/nomenclatura_*.jpg`
