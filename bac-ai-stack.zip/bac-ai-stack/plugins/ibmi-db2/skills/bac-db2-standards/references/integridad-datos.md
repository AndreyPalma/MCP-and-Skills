# Integridad y Calidad de Datos

Esta referencia cubre los mecanismos para asegurar la integridad, calidad y seguridad de los datos.

## Tabla de Contenido

1. [Llaves e Integridad](#1-llaves-e-integridad)
2. [Constraints de Validación](#2-constraints-de-validación)
3. [Datos Sensibles y Seguridad](#3-datos-sensibles-y-seguridad)
4. [Housekeeping y Retención](#4-housekeeping-y-retención)
5. [Monitoreo y Control](#5-monitoreo-y-control)

---

## 1. Llaves e Integridad

### Llave Primaria Obligatoria

✓ **Toda tabla SQL debe tener PRIMARY KEY:**

```sql
-- OBLIGATORIO
CREATE TABLE TRANSACCIONES (
    transaccion_id  FOR IDTRX BIGINT NOT NULL,
    -- ... campos
    CONSTRAINT pk_transacciones PRIMARY KEY (transaccion_id)
);
```

❌ **NO omitir llave primaria en tablas relacionales**

### Llaves Compuestas - Validar Unicidad

⚠ **Si PK tiene múltiples campos, validar que no habrá duplicados:**

```sql
CREATE TABLE MOVIMIENTOS_CUENTA (
    pais_codigo         FOR CODPAI CHAR(2) NOT NULL,
    cuenta_numero       FOR CTANUM BIGINT NOT NULL,
    fecha_movimiento    FOR FECMOV DATE NOT NULL,
    secuencia           FOR SECUEN INT NOT NULL,
    -- ...
    
    -- Validar que esta combinación será siempre única
    CONSTRAINT pk_movimientos 
        PRIMARY KEY (pais_codigo, cuenta_numero, fecha_movimiento, secuencia)
);

-- Asegurar que secuencia se genera correctamente para evitar duplicados
```

### Foreign Keys Explícitas

✓ **Definir como ALTER separado, no dentro de CREATE TABLE:**

```sql
-- CORRECTO
CREATE TABLE MI_TABLA (
    id          INT NOT NULL,
    padre_id    INT NOT NULL,
    PRIMARY KEY (id)
);

-- FK como ALTER separado
ALTER TABLE MI_TABLA
    ADD CONSTRAINT fk_mi_tabla_padre
    FOREIGN KEY (padre_id)
    REFERENCES TABLA_PADRE(id)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;
```

❌ **NO incluir dentro del CREATE TABLE:**
```sql
-- EVITAR
CREATE TABLE MI_TABLA (
    id INT PRIMARY KEY,
    padre_id INT REFERENCES TABLA_PADRE(id)  -- NO hacer así
);
```

---

## 2. Constraints de Validación

### Check Constraints para Listas Finitas

✓ **Listas de valores finitos → Check Constraint:**

```sql
CREATE TABLE CUENTAS (
    cuenta_id       FOR IDCTA BIGINT NOT NULL,
    estatus         FOR ESTATUS CHAR(1) NOT NULL,
    tipo_cuenta     FOR TIPCTA CHAR(2) NOT NULL,
    indicador_vip   FOR INDVIP CHAR(1) NOT NULL DEFAULT 'N',
    PRIMARY KEY (cuenta_id)
);

ALTER TABLE CUENTAS
    ADD CONSTRAINT ck_cuentas_estatus
    CHECK (estatus IN ('A', 'I', 'C', 'B', 'S'));

ALTER TABLE CUENTAS
    ADD CONSTRAINT ck_cuentas_tipo
    CHECK (tipo_cuenta IN ('AH', 'CC', 'DP', 'FI'));

ALTER TABLE CUENTAS
    ADD CONSTRAINT ck_cuentas_vip
    CHECK (indicador_vip IN ('S', 'N'));
```

### NO Espacios Vacíos en Check

❌ **NO incluir espacio vacío (' ') en lista de valores:**

```sql
-- INCORRECTO - Genera ambigüedad
CHECK (estatus IN ('A', 'I', ' '))  -- NO!

-- CORRECTO - Valores significativos solamente
CHECK (estatus IN ('A', 'I', 'X'))
-- Si se necesita "sin estatus", usar NULL o valor específico como 'X'
```

**Razón:** Espacio vacío genera:
- Ambigüedad con NULL
- Problemas de calidad de datos
- Dificultad en consultas
- Confusión en reportes

### Tablas de Referencia para Listas Flexibles

✓ **Listas que pueden crecer → Tabla de catálogo:**

```sql
-- Catálogo mantenible
CREATE TABLE CAT_TIPOS_TRANSACCION (
    tipo_codigo         FOR TIPCOD CHAR(2) NOT NULL,
    tipo_descripcion    FOR TIPDES VARCHAR(100) NOT NULL,
    categoria           FOR CATEG VARCHAR(30) NOT NULL,
    indicador_activo    FOR INDACT CHAR(1) NOT NULL DEFAULT 'S',
    fecha_creacion      FOR FECCRE DATE NOT NULL DEFAULT CURRENT DATE,
    
    CONSTRAINT pk_tipos_transaccion PRIMARY KEY (tipo_codigo),
    CONSTRAINT ck_tipos_activo CHECK (indicador_activo IN ('S', 'N'))
);

-- Uso con FK
CREATE TABLE TRANSACCIONES (
    transaccion_id      FOR IDTRX BIGINT NOT NULL,
    tipo_transaccion    FOR TIPTRX CHAR(2) NOT NULL,
    -- ...
    
    CONSTRAINT fk_transacciones_tipo
        FOREIGN KEY (tipo_transaccion)
        REFERENCES CAT_TIPOS_TRANSACCION(tipo_codigo)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
);
```

### Unique Constraints

✓ **Para campos que deben ser únicos (pero no son PK):**

```sql
CREATE TABLE USUARIOS (
    usuario_id          INT NOT NULL,
    username            VARCHAR(30) NOT NULL,
    email               VARCHAR(100) NOT NULL,
    numero_empleado     VARCHAR(15) NOT NULL,
    
    CONSTRAINT pk_usuarios PRIMARY KEY (usuario_id),
    
    -- Constraints de unicidad
    CONSTRAINT uq_usuarios_username UNIQUE (username),
    CONSTRAINT uq_usuarios_email UNIQUE (email),
    CONSTRAINT uq_usuarios_empleado UNIQUE (numero_empleado)
);
```

❌ **NO usar índices UNIQUE en lugar de constraint:**
```sql
-- INCORRECTO
CREATE UNIQUE INDEX ix_username ON USUARIOS(username);  -- NO!

-- CORRECTO
CONSTRAINT uq_usuarios_username UNIQUE (username)  -- Sí
```

### Contexto Único de Campos

❌ **NO campos "multipropósito":**

```sql
-- INCORRECTO - Campo usado para diferentes cosas
CREATE TABLE PARAMETROS_MAL (
    parametro_id    INT,
    codigo          VARCHAR(10),
    valor           VARCHAR(100)  -- A veces es monto, a veces texto, a veces fecha
);

-- CORRECTO - Campos específicos
CREATE TABLE CONFIGURACION_TASAS (
    configuracion_id    INT,
    codigo_tasa         VARCHAR(10),
    valor_tasa          DECIMAL(7,4),
    fecha_vigencia      DATE
);

CREATE TABLE CONFIGURACION_TEXTOS (
    configuracion_id    INT,
    codigo_texto        VARCHAR(10),
    valor_texto         VARCHAR(200)
);
```

---

## 3. Datos Sensibles y Seguridad

### Identificación de Datos Sensibles

⚠ **Coordinar con Gerencia de Datos Sensibles si la tabla contiene:**

- Números de identificación (CIF, cédulas, pasaportes)
- Números de tarjetas
- Números de cuentas
- Datos personales que permiten ubicación del cliente
- Información financiera sensible
- Datos de autenticación

### Evitar Exposición

❌ **NO exponer datos sensibles sin controles:**

```sql
-- CUIDADO - Exponer CIF + datos personales juntos
CREATE VIEW vw_clientes_publica AS  -- Riesgo de seguridad
SELECT 
    cif,
    nombre_completo,
    direccion_completa,
    telefono,
    email
FROM CLIENTES;
```

✓ **Aplicar controles según políticas:**

```sql
-- Mejor - Enmascarar o separar
CREATE VIEW vw_clientes_anonimo AS
SELECT 
    cliente_id,  -- ID interno, no CIF
    SUBSTR(nombre_completo, 1, 10) || '***' AS nombre_parcial,
    pais_codigo,
    ciudad
FROM CLIENTES;

-- Vista completa solo para roles autorizados
CREATE VIEW vw_clientes_completo AS
SELECT * FROM CLIENTES;

-- Aplicar permisos restrictivos
GRANT SELECT ON vw_clientes_completo TO ROLE_SEGURIDAD;
```

### Criterios de Seguridad

Consultar con área de Seguridad de Sistemas para:
- Cifrado de campos sensibles
- Enmascaramiento en logs
- Auditoría de accesos
- Controles de autorización
- Políticas de retención

---

## 4. Housekeeping y Retención

### Análisis de Retención Obligatorio

✓ **Toda tabla nueva debe definir proceso de housekeeping:**

```sql
-- Documentar en diseño
-- TABLA: TRANSACCIONES_ONLINE
-- HOUSEKEEPING: 
--   - Retener en línea: 90 días
--   - Archivar histórico: 7 años
--   - Eliminar definitivamente: Después de 7 años
--   - Frecuencia: Proceso mensual
--   - Tabla histórico: TRANSACCIONES_ONLINE_HIST

CREATE TABLE PARAM_HOUSEKEEPING (
    tabla_nombre        VARCHAR(128) NOT NULL,
    dias_retencion      INT NOT NULL,
    tipo_proceso        CHAR(1) NOT NULL,  -- A=Archivar, E=Eliminar
    frecuencia          VARCHAR(20) NOT NULL,
    tabla_historico     VARCHAR(128),
    indicador_activo    CHAR(1) NOT NULL DEFAULT 'S',
    
    CONSTRAINT pk_housekeeping PRIMARY KEY (tabla_nombre)
);

-- Registrar en producción
INSERT INTO PARAM_HOUSEKEEPING VALUES (
    'TRANSACCIONES_ONLINE',
    90,
    'A',
    'MENSUAL',
    'TRANSACCIONES_ONLINE_HIST',
    'S'
);
```

### Ejemplo de Proceso de Housekeeping

```sql
CREATE PROCEDURE sp_housekeeping_transacciones()
LANGUAGE SQL
BEGIN
    DECLARE v_fecha_corte DATE;
    DECLARE v_registros_archivados INT DEFAULT 0;
    
    -- Fecha de corte: hace 90 días
    SET v_fecha_corte = CURRENT DATE - 90 DAYS;
    
    -- 1. Archivar a histórico
    INSERT INTO TRANSACCIONES_ONLINE_HIST
    SELECT * 
    FROM TRANSACCIONES_ONLINE
    WHERE fecha_transaccion < v_fecha_corte;
    
    GET DIAGNOSTICS v_registros_archivados = ROW_COUNT;
    
    -- 2. Eliminar de tabla en línea
    DELETE FROM TRANSACCIONES_ONLINE
    WHERE fecha_transaccion < v_fecha_corte;
    
    -- 3. Log del proceso
    INSERT INTO LOG_HOUSEKEEPING VALUES (
        DEFAULT,  -- ID auto
        'TRANSACCIONES_ONLINE',
        v_fecha_corte,
        v_registros_archivados,
        CURRENT TIMESTAMP
    );
    
    COMMIT;
END;
```

---

## 5. Monitoreo y Control

### Análisis de Impacto

Para **estructuras a modificar**, generar análisis de impacto reciente:

```sql
-- Encontrar objetos que usan la tabla
SELECT 
    object_name,
    object_type,
    status
FROM SYSTEM_CATALOG
WHERE object_text LIKE '%TABLA_A_MODIFICAR%'
   OR dependencies LIKE '%TABLA_A_MODIFICAR%';
```

**Análisis debe incluir:**
- Vistas que referencian la tabla
- Stored procedures que la usan
- Triggers asociados
- Índices definidos
- Aplicaciones que la acceden
- Jobs programados
- Reportes

### Monitoreo de Excepciones

✓ **Monitorear errores del motor de BD:**

- Violaciones de integridad referencial
- Errores en cursores
- Datos inválidos rechazados
- Warnings de truncamiento
- Deadlocks
- Constraint violations

```sql
-- Tabla de log de errores
CREATE TABLE LOG_ERRORES_BD (
    log_id              BIGINT GENERATED ALWAYS AS IDENTITY,
    fecha_hora          TIMESTAMP NOT NULL DEFAULT CURRENT TIMESTAMP,
    tipo_error          VARCHAR(10) NOT NULL,
    codigo_sql          VARCHAR(10),
    mensaje             VARCHAR(500),
    tabla_afectada      VARCHAR(128),
    usuario             VARCHAR(30) NOT NULL,
    aplicacion          VARCHAR(50),
    
    PRIMARY KEY (log_id)
);

-- Ejemplo de captura en SP
CREATE PROCEDURE sp_procesar_transaccion(...)
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        INSERT INTO LOG_ERRORES_BD (
            tipo_error, codigo_sql, mensaje, tabla_afectada, usuario
        ) VALUES (
            'SQL_ERROR', SQLSTATE, SQLERRM, 'TRANSACCIONES', USER
        );
    END;
    
    -- Lógica del procedimiento
    ...
END;
```

### Selección de Objetos Correctos

⚠ **Verificar que se usa el objeto correcto:**

**Ejemplo: Tipos de Cambio**
```sql
-- ¿Cuál usar?
-- - TIPO_CAMBIO_CONTABLE (para contabilidad)
-- - TIPO_CAMBIO_OPERATIVO (para transacciones del día)
-- - TIPO_CAMBIO_CIERRE (para reportes de fin de día)

-- Documentar claramente cuál usar en cada caso
```

**Ejemplo: Códigos de Moneda**
```sql
-- ¿Cuál usar?
-- - CAT_MONEDAS (catálogo oficial ISO)
-- - MONEDAS_PAIS (monedas permitidas por país)
-- - MONEDAS_PRODUCTO (monedas aceptadas por producto)

-- Definir en el análisis cuál es el apropiado
```

---

## Ejemplo Completo: Tabla con Controles de Calidad

```sql
CREATE TABLE PRESTAMOS (
    -- IDENTIFICACIÓN
    prestamo_numero     BIGINT NOT NULL,
    pais_codigo         CHAR(2) NOT NULL,
    cliente_id          INT NOT NULL,
    
    -- DATOS DEL PRÉSTAMO
    tipo_prestamo       CHAR(2) NOT NULL,
    moneda_codigo       CHAR(3) NOT NULL,
    monto_otorgado      DECIMAL(15,2) NOT NULL,
    tasa_interes        DECIMAL(7,4) NOT NULL,
    plazo_meses         INT NOT NULL,
    fecha_desembolso    DATE,
    fecha_vencimiento   DATE,
    
    -- ESTATUS Y CONTROL
    estatus_prestamo    CHAR(2) NOT NULL DEFAULT 'SO',
    oficina_origen      VARCHAR(10) NOT NULL,
    
    -- AUDITORÍA
    usuario_creacion    VARCHAR(30) NOT NULL,
    fecha_creacion      TIMESTAMP NOT NULL DEFAULT CURRENT TIMESTAMP,
    usuario_modificacion VARCHAR(30),
    fecha_modificacion  TIMESTAMP,
    
    -- SEGURIDAD
    nivel_autorizacion  CHAR(1) NOT NULL DEFAULT '1',
    
    -- LLAVE PRIMARIA
    CONSTRAINT pk_prestamos PRIMARY KEY (prestamo_numero)
);

-- UNIQUE CONSTRAINTS
ALTER TABLE PRESTAMOS
    ADD CONSTRAINT uq_prestamos_pais_cliente
    UNIQUE (pais_codigo, cliente_id, fecha_desembolso);

-- CHECK CONSTRAINTS
ALTER TABLE PRESTAMOS
    ADD CONSTRAINT ck_prestamos_tipo
    CHECK (tipo_prestamo IN ('PE', 'HI', 'VE', 'EM', 'CO'));

ALTER TABLE PRESTAMOS
    ADD CONSTRAINT ck_prestamos_estatus
    CHECK (estatus_prestamo IN ('SO', 'AN', 'AP', 'DE', 'VI', 'MO', 'CA', 'LI'));

ALTER TABLE PRESTAMOS
    ADD CONSTRAINT ck_prestamos_monto
    CHECK (monto_otorgado > 0 AND monto_otorgado <= 99999999999.99);

ALTER TABLE PRESTAMOS
    ADD CONSTRAINT ck_prestamos_tasa
    CHECK (tasa_interes >= 0 AND tasa_interes <= 100);

ALTER TABLE PRESTAMOS
    ADD CONSTRAINT ck_prestamos_plazo
    CHECK (plazo_meses > 0 AND plazo_meses <= 360);

-- FOREIGN KEYS
ALTER TABLE PRESTAMOS
    ADD CONSTRAINT fk_prestamos_clientes
    FOREIGN KEY (cliente_id)
    REFERENCES CLIENTES(cliente_id)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE PRESTAMOS
    ADD CONSTRAINT fk_prestamos_monedas
    FOREIGN KEY (moneda_codigo)
    REFERENCES CAT_MONEDAS(moneda_codigo)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE PRESTAMOS
    ADD CONSTRAINT fk_prestamos_tipos
    FOREIGN KEY (tipo_prestamo)
    REFERENCES CAT_TIPOS_PRESTAMO(tipo_codigo)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

-- METADATA COMPLETA
COMMENT ON TABLE PRESTAMOS IS 
    'Registro maestro de préstamos otorgados a clientes. Incluye préstamos personales, hipotecarios, vehiculares y empresariales para toda la región';

COMMENT ON COLUMN PRESTAMOS.estatus_prestamo IS 
    'Estatus actual: SO=Solicitado, AN=En análisis, AP=Aprobado, DE=Desembolsado, VI=Vigente, MO=En mora, CA=Cancelado, LI=Liquidado';

-- HOUSEKEEPING
-- Retención: 10 años después de liquidado o cancelado
-- Proceso trimestral de archivo a PRESTAMOS_HISTORICO
```

---

## Checklist de Integridad y Calidad

- [ ] Toda tabla tiene PRIMARY KEY definida
- [ ] Llaves compuestas validadas para unicidad
- [ ] Foreign keys definidas como ALTER separado
- [ ] ON DELETE/UPDATE siempre RESTRICT
- [ ] Check constraints para listas finitas de valores
- [ ] No espacios vacíos (' ') en check constraints
- [ ] Tablas de referencia para listas flexibles con FK
- [ ] Unique constraints donde aplique (no índices UNIQUE)
- [ ] No campos multi-propósito
- [ ] Datos sensibles identificados y coordinados
- [ ] Cumple políticas de seguridad de la información
- [ ] Proceso de housekeeping definido y parametrizado
- [ ] Análisis de impacto para modificaciones
- [ ] Monitoreo de excepciones considerado
- [ ] Objeto correcto seleccionado (tipo cambio, monedas, etc.)
- [ ] Validación de que no existe objeto similar
- [ ] NOT NULL en todos los campos (salvo justificación)
- [ ] DEFAULT values apropiados

---

**Fuente**: Sección 5 - Check List de Revisión de Base de Datos BAC Credomatic
