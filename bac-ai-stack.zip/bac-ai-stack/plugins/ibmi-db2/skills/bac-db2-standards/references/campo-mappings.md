# Mapeo de Nombres Largos a Nombres Cortos para DB2 for i

⚠️ **ADVERTENCIA**: Este archivo es solo de REFERENCIA. 

**NO USAR DIRECTAMENTE** estas abreviaturas. Todas las abreviaturas deben obtenerse dinámicamente usando:

```sql
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', '[CONCEPTO_NEGOCIO]');
```

Las abreviaturas mostradas aquí pueden estar desactualizadas. Siempre consultar los stored procedures oficiales para obtener las abreviaturas más recientes del catálogo de 867 códigos oficiales en `LIBMHVTMP.HBDAABRDID`.

---

Este archivo documenta el mapeo estándar de campos largos (descriptivos) a nombres cortos (max 10 caracteres) para usar con la cláusula `FOR` en DB2 for i.

## Formato Estándar

```sql
NOMBRE_LARGO FOR NOMCOR TIPO_DATO
```

## Identificadores y Claves

| Nombre Largo | Nombre Corto | Tipo Común |
|--------------|--------------|------------|
| pais_codigo | CODPAI | CHAR(2) |
| banco_codigo | CODBCO | CHAR(3) |
| moneda_codigo | CODMON | CHAR(3) |
| transaccion_id | IDTRX | BIGINT |
| cuenta_numero | CTANUM | BIGINT |
| cliente_id | IDCLI | BIGINT |
| cuenta_id | IDCTA | BIGINT |
| prestamo_id | IDPRS | BIGINT |
| tarjeta_numero | NUMTDC | BIGINT |

## Tipos y Códigos

| Nombre Largo | Nombre Corto | Tipo Común |
|--------------|--------------|------------|
| tipo_cuenta | TIPCTA | CHAR(2) |
| tipo_transaccion | TIPTRX | CHAR(2-3) |
| tipo_cliente | TIPCLI | CHAR(2) |
| tipo_garantia | TIPGAR | CHAR(3) |
| codigo_autorizacion | CODAUT | CHAR(6-20) |
| codigo_rechazo | CODRCH | CHAR(3) |
| codigo_entidad | CODENT | CHAR(4) |
| codigo_error | CODERR | CHAR(5) |

## Montos y Valores Numéricos

| Nombre Largo | Nombre Corto | Tipo Común |
|--------------|--------------|------------|
| monto_transaccion | MTOTRX | DECIMAL(15,2) |
| monto_error | MTOERR | DECIMAL(15,2) |
| saldo_disponible | SLDDSP | DECIMAL(15,2) |
| saldo_contable | SLDCTB | DECIMAL(15,2) |
| porcentaje_iva | PRCIVA | DECIMAL(5,2) |
| cantidad_intentos | CNTINT | INTEGER |

## Estados e Indicadores

| Nombre Largo | Nombre Corto | Tipo Común |
|--------------|--------------|------------|
| estatus_cuenta | STCCTA | CHAR(1) |
| estatus_transaccion | STCTRX | CHAR(1) |
| estatus_prestamo | STCPRS | CHAR(2) |
| estatus_activo | STCACT | CHAR(1) |
| estatus_error | STCERR | CHAR(1) |
| indicador_bloqueada | INDBLQ | CHAR(1) |
| indicador_reversada | INDREV | CHAR(1) |
| indicador_fraude | INDFRAU | CHAR(1) |
| indicador_activo | INDACT | CHAR(1) |

## Fechas

| Nombre Largo | Nombre Corto | Tipo Común |
|--------------|--------------|------------|
| fecha_transaccion | FECTRX | DATE |
| fecha_apertura | FECAPE | DATE |
| fecha_error | FECERR | DATE |
| fecha_solicitud | FECSOL | TIMESTAMP |
| fecha_proceso | FECPRO | TIMESTAMP |
| fecha_aplicacion | FECAPL | DATE |
| fecha_ultimo_movimiento | FECULMOV | DATE |
| fecha_ingreso | FECING | TIMESTAMP |
| fecha_modificacion | FECMOD | TIMESTAMP |
| fecha_aprobacion | FECAPR | TIMESTAMP |

## Descripciones

| Nombre Largo | Nombre Corto | Tipo Común |
|--------------|--------------|------------|
| descripcion_transaccion | DESTRX | VARCHAR(200) |
| descripcion_error | DESERR | VARCHAR(200) |
| descripcion_cuenta | DESCTA | VARCHAR(100) |

## Cuentas Relacionadas

| Nombre Largo | Nombre Corto | Tipo Común |
|--------------|--------------|------------|
| cuenta_origen | CTAORG | BIGINT |
| cuenta_destino | CTADST | BIGINT |

## Usuarios (Auditoría)

| Nombre Largo | Nombre Corto | Tipo Común |
|--------------|--------------|------------|
| usuario_solicita | USRSOL | VARCHAR(30) |
| usuario_ingresa | USRING | CHAR(18) |
| usuario_modifica | USRMOD | CHAR(18) |
| usuario_aprueba | USRAPR | CHAR(18) |
| USUARIOCREACION | USRCRE | CHAR(18) |
| FECHACREACION | FECCRE | TIMESTAMP |
| USUARIOMODIFICA | USRMOD | CHAR(18) |
| FECHAMODIFICA | FECMOD | TIMESTAMP |

## Abreviaturas Comunes

- **COD** = Código
- **TIP** = Tipo
- **MTO** = Monto
- **SLD** = Saldo
- **DSP** = Disponible
- **CTB** = Contable
- **STC** = Estatus
- **IND** = Indicador
- **FEC** = Fecha
- **DES** = Descripción
- **USR** = Usuario
- **TRX** = Transacción
- **CTA** = Cuenta
- **CLI** = Cliente
- **PRS** = Préstamo
- **TDC** = Tarjeta
- **NUM** = Número
- **ID** = Identificador
- **BCO** = Banco
- **MON** = Moneda
- **PAI** = País
- **ORG** = Origen
- **DST** = Destino
- **BLQ** = Bloqueada
- **REV** = Reversada
- **FRAU** = Fraude
- **ACT** = Activo
- **APE** = Apertura
- **SOL** = Solicitud
- **PRO** = Proceso
- **APL** = Aplicación
- **ULMOV** = Último Movimiento
- **ING** = Ingreso
- **MOD** = Modificación
- **APR** = Aprobación
- **AUT** = Autorización
- **RCH** = Rechazo
- **ENT** = Entidad
- **ERR** = Error
- **GAR** = Garantía
- **IVA** = IVA
- **INT** = Intentos
- **CRE** = Creación

## Reglas de Nomenclatura

1. **Máximo 10 caracteres** por nombre corto
2. **Solo caracteres alfanuméricos** (sin guiones bajos ni espacios)
3. **Preferir mayúsculas** para consistencia
4. **Usar abreviaturas documentadas** de la tabla LIBMHVTMP.HBDAABRDID
5. **Mantener consistencia** entre campos similares en diferentes tablas
