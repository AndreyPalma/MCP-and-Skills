# Índices - Creación y Mantenimiento

Esta referencia cubre las políticas y mejores prácticas para la creación y gestión de índices.

## Tabla de Contenido

1. [Unicidad vs Performance](#1-unicidad-vs-performance)
2. [Índices para Funcionalidad](#2-índices-para-funcionalidad)
3. [Índices para Performance](#3-índices-para-performance)
4. [Mantenimiento de Índices](#4-mantenimiento-de-índices)
5. [Tipos Especiales de Índices](#5-tipos-especiales-de-índices)

---

## 1. Unicidad vs Performance

### UNIQUE es Constraint, No Índice

✓ **Para unicidad: Usar CONSTRAINT UNIQUE**

El constraint de unicidad debe ir en la **definición de la tabla**, NO como índice:

```sql
-- CORRECTO - Constraint de unicidad en la tabla
CREATE TABLE CUENTAS (
    cuenta_numero           FOR CTANUM BIGINT NOT NULL,
    numero_cuenta_externo   FOR NUMEXT VARCHAR(20) NOT NULL,
    email_notificacion      FOR EMLEML VARCHAR(100) NOT NULL,
    
    CONSTRAINT pk_cuentas PRIMARY KEY (cuenta_numero),
    CONSTRAINT uq_cuentas_externo UNIQUE (numero_cuenta_externo),
    CONSTRAINT uq_cuentas_email UNIQUE (email_notificacion)
);
```

❌ **INCORRECTO - Índice con UNIQUE:**
```sql
-- NO HACER ESTO
CREATE UNIQUE INDEX ix_cuentas_externo 
    ON CUENTAS(numero_cuenta_externo);  -- ❌ Usar CONSTRAINT en su lugar
```

**Razón:**
- Constraints son reglas de negocio centralizadas
- Aparecen en metadata y esquema formal
- Índices UNIQUE son considerados implementación física
- Mejora claridad del modelo de datos

### Índices sin UNIQUE

✓ **Para performance: Índices normales (sin UNIQUE)**

```sql
-- CORRECTO - Índice para búsquedas frecuentes
CREATE INDEX ix_transacciones_fecha
    ON TRANSACCIONES(fecha_transaccion);

CREATE INDEX ix_transacciones_cuenta
    ON TRANSACCIONES(cuenta_numero, fecha_transaccion);
```

---

## 2. Índices para Funcionalidad

### Definición

Índices que **impactan la funcionalidad** de aplicaciones:
- Usados explícitamente en código de aplicación
- Referenciados en hojas F de programas RPG
- Necesarios para ordenamiento específico de presentación
- Requeridos por lógica de negocio

### Proceso de Implementación

✓ **Índices funcionales = Pase a Producción completo:**

```sql
-- Índice usado explícitamente en aplicación
CREATE INDEX IXF_CTADEP_CLIFEC
    ON COREACTADEP (cliente_id, fecha_apertura DESC);

COMMENT ON INDEX IXF_CTADEP_CLIFEC IS
    'Índice utilizado por pantalla de consulta de cuentas por cliente. Orden descendente por fecha para mostrar cuentas más recientes primero';
```

**Requisitos:**
- Tratarlo como elemento **configurable**
- Seguir **proceso de pases** establecido
- **Catalogación** obligatoria
- **Resguardo de fuentes**
- **Nomenclatura estándar**: `IXF_<tabla>_<campos>`
- Documentación completa

**Ejemplo de nomenclatura:**
| Prefijo | Significado | Uso |
|---------|-------------|-----|
| `IXF_` | Index Functional | Índice usado por aplicación |
| `IXP_` | Index Performance | Índice solo para performance |

---

## 3. Índices para Performance

### Definición

Índices creados **únicamente para mejorar rendimiento**:
- NO usados explícitamente en código
- Creados por análisis de performance
- Basados en planes de ejecución
- Para optimizar queries de reportes

### Proceso Simplificado - RFC

✓ **Índices de performance = RFC (no pase completo):**

```sql
-- Índice creado solo para optimizar query lento
CREATE INDEX IXP_TRXPRO_FECTIP_2026_RFC789
    ON CRMATRXPRO (fecha_transaccion, tipo_transaccion);

COMMENT ON INDEX IXP_TRXPRO_FECTIP_2026_RFC789 IS
    'Índice de performance para optimizar reporte de transacciones por tipo. Creado en RFC-789-2026';
```

**Características:**
- Enviar por **RFC** (Request for Change)
- **Nomenclatura especial** para evitar colisiones: 
  - Prefijo `IXP_`
  - Sufijo con año y número de RFC
  - Ejemplo: `IXP_<tabla>_<campos>_<año>_RFC<número>`
- NO requiere pase completo
- Documentar justificación (query optimizado)

### Nomenclatura para Evitar Colisiones

```sql
-- Formato: IXP_<tabla>_<campos_descripción>_<año>_RFC<número>

-- Ejemplos:
IXP_TRANSACCIONES_FECHA_2026_RFC456
IXP_CUENTAS_ESTATUS_TIPO_2026_RFC789
IXP_PRESTAMOS_CLIENTE_MORA_2026_RFC1023
```

---

## 4. Mantenimiento de Índices

### Principio: Menos es Más

⚠ **Impacto de índices excesivos:**

- El motor debe **mantener todos los índices** en cada INSERT/UPDATE/DELETE
- Muchos índices → degradación de performance en escrituras
- Espacio en disco significativo
- Mayor tiempo de backup/restore

### Descartar Índices en Desuso

✓ **Monitorear y eliminar índices no utilizados:**

```sql
-- Consulta de uso de índices (ejemplo conceptual)
SELECT 
    index_name,
    table_name,
    last_used,
    num_accesses
FROM SYSTEM_CATALOG.INDEX_USAGE
WHERE num_accesses = 0
  AND days_since_creation > 90;

-- Eliminar índices no utilizados
DROP INDEX PROD_DATA.IXP_VIEJO_SIN_USO;
```

**Proceso recomendado:**
1. Analizar uso de índices mensualmente
2. Identificar índices con 0 accesos en 60+ días
3. Validar con aplicativos propietarios
4. Descartar índices confirmados en desuso
5. Documentar eliminación

### Balance de Índices

**Consideraciones:**
```sql
-- Tabla con escrituras muy frecuentes
CREATE TABLE TRANSACCIONES_ONLINE (...);

-- Minimizar índices, solo los esenciales:
CREATE INDEX ix_transacciones_cuenta ON TRANSACCIONES_ONLINE(cuenta_numero);  -- Esencial
CREATE INDEX ix_transacciones_fecha ON TRANSACCIONES_ONLINE(fecha_transaccion);  -- Esencial

-- NO crear índices "por si acaso"
-- Cada índice tiene costo en INSERT/UPDATE/DELETE
```

---

## 5. Tipos Especiales de Índices

### Encoded Vector Index (EVI)

⚠ **Uso restringido a casos muy específicos:**

Los EVI (DB2) son para situaciones especiales:
- Tablas con cardinalidad muy baja en columnas indexadas
- Queries con múltiples predicados en columnas de baja cardinalidad
- Data warehousing y analytics

❌ **NO usar por defecto:**
```sql
-- REQUIERE JUSTIFICACIÓN TÉCNICA
CREATE ENCODED VECTOR INDEX evi_transacciones_tipo
    ON TRANSACCIONES(tipo_transaccion, estatus);
```

✓ **Proceso para índices especiales:**
1. Documentar análisis de caso de uso
2. Evidencia de que NO afecta procesos actuales
3. Pruebas de performance comparativas
4. Aprobación de Arquitectura de Datos
5. Monitoreo post-implementación

### Radix Index (Estándar)

✓ **Usar por defecto:**

El índice clásico tipo Radix es apropiado para la mayoría de casos:

```sql
-- Índice estándar (Radix)
CREATE INDEX ix_cuentas_cliente
    ON CUENTAS(cliente_id);

CREATE INDEX ix_transacciones_fecha_cuenta
    ON TRANSACCIONES(fecha_transaccion, cuenta_numero);
```

---

## Ejemplo Completo: Estrategia de Índices para una Tabla

```sql
---
-- TRANSACCIONES_TARJETA: Tabla de transacciones con tarjetas
--
-- Almacena todas las transacciones realizadas con tarjetas de crédito
-- y débito. Incluye estrategia completa de indexación con índices
-- funcionales (para módulos específicos) y de performance (para
-- optimizar consultas lentas identificadas en producción).
--
-- @author Equipo Tarjetas
-- @date 2026-03-01
-- @project TARJETAS-2026
-- @version v1.0
---

CREATE TABLE TCAATRXTDC (
    transaccion_id          FOR IDTRX BIGINT NOT NULL,
    pais_codigo             FOR CODPAI CHAR(2) NOT NULL,
    tarjeta_numero          FOR NUMTDC CHAR(16) NOT NULL,
    fecha_transaccion       FOR FECTRX DATE NOT NULL,
    hora_transaccion        FOR HORATRX TIME NOT NULL,
    monto                   FOR MONTO DECIMAL(15,2) NOT NULL,
    moneda_codigo           FOR CODMON CHAR(3) NOT NULL,
    comercio_codigo         FOR CODCOM VARCHAR(15) NOT NULL,
    tipo_transaccion        FOR TIPTRX CHAR(2) NOT NULL,
    estatus                 FOR ESTATUS CHAR(1) NOT NULL,
    
    -- PK automáticamente crea índice
    CONSTRAINT pk_transacciones_tarjeta 
        PRIMARY KEY (transaccion_id),
    
    -- Constraint de unicidad (NO índice UNIQUE)
    CONSTRAINT uq_transacciones_referencia
        UNIQUE (pais_codigo, tarjeta_numero, fecha_transaccion, hora_transaccion)
);

-- Índices funcionales (requeridos por módulos específicos)
-- Índice 1: Usado por pantalla de consulta de transacciones de tarjeta
CREATE INDEX IXF_TRXTDC_TARFEC
    ON TCAATRXTDC(tarjeta_numero, fecha_transaccion DESC);

COMMENT ON INDEX PROD_DATA.IXF_TRANSTARJ_TARJETA_FECHA IS
    'Índice funcional usado por módulo de consulta de transacciones (TCONS001). Ordenamiento descendente por fecha para mostrar transacciones más recientes primero';

-- Índice 2: Usado por proceso de conciliación diaria
CREATE INDEX IXF_TRXTDC_FECCOM
    ON TCAATRXTDC(fecha_transaccion, comercio_codigo, estatus);

COMMENT ON INDEX IXF_TRXTDC_FECCOM IS
    'Índice funcional requerido por proceso batch de conciliación con comercios (JOB_CONC_COMERCIO)';

-- Índices de performance (creados mediante RFC por necesidad comprobada)
-- Índice 3: Performance para reporte gerencial
CREATE INDEX IXP_TRXTDC_PAIFEC_2026_RFC456
    ON TCAATRXTDC(pais_codigo, fecha_transaccion, moneda_codigo);

COMMENT ON INDEX PROD_DATA.IXP_TRANSTARJ_PAIS_FECHA_2026_RFC456 IS
    'Índice de performance para optimizar reporte gerencial de transacciones por país. Creado en RFC-456-2026. Query optimizado reducido de 45 seg a 3 seg';

-- Ejemplos de índices que NO deben crearse
-- ❌ NO crear "por si acaso":
-- CREATE INDEX ix_por_si_acaso ON TRANSACCIONES_TARJETA(tipo_transaccion);

-- ❌ NO índice UNIQUE (usar constraint):
-- CREATE UNIQUE INDEX ix_unique_ref ON TRANSACCIONES_TARJETA(referencia);

-- ❌ NO índices redundantes:
-- Si ya existe (A, B, C), NO crear (A, B)

-- ❌ NO índices en campos de alta cardinalidad que no se consultan:
-- CREATE INDEX ix_monto ON TRANSACCIONES_TARJETA(monto);  -- Ineficiente
```

---

## Estrategia de Índices: Decision Tree

```
¿Se necesita garantizar unicidad de valores?
│
├─ SÍ → Usar CONSTRAINT UNIQUE (no CREATE UNIQUE INDEX)
│
└─ NO → ¿El índice es usado explícitamente por la aplicación?
         │
         ├─ SÍ → Índice FUNCIONAL (IXF_)
         │        → Pase a producción completo
         │        → Catalogar y resguardar fuente
         │        → Nomenclatura: IXF_<tabla>_<campos>
         │
         └─ NO → ¿Es solo para optimizar performance?
                  │
                  ├─ SÍ → Índice PERFORMANCE (IXP_)
                  │        → Enviar por RFC
                  │        → Nomenclatura: IXP_<tabla>_<campos>_<año>_RFC<num>
                  │        → Justificar mejora de rendimiento
                  │
                  └─ NO → Tipo especial de índice (EVI, etc.)
                           → Documentar caso de uso
                           → Evidenciar no afecta procesos actuales
                           → Aprobación de Arquitectura
                           → Pruebas exhaustivas
```

---

## Checklist de Índices

- [ ] Constraint UNIQUE para unicidad (no índice UNIQUE)
- [ ] Índices funcionales con nomenclatura IXF_
- [ ] Índices funcionales enviados por pase completo
- [ ] Índices funcionales catalogados y respaldados
- [ ] Índices de performance con nomenclatura IXP_<>_<año>_RFC<num>
- [ ] Índices de performance enviados por RFC
- [ ] Justificación documentada (query optimizado, mejora cuantificada)
- [ ] Minimizar cantidad de índices (solo necesarios)
- [ ] Índices tipo Radix por defecto
- [ ] Índices especiales (EVI) justificados y probados
- [ ] Evidencia de no afectar procesos actuales (índices especiales)
- [ ] Monitoreo de uso de índices
- [ ] Eliminación de índices en desuso
- [ ] Balance entre performance de lecturas vs escrituras
- [ ] No índices redundantes (si existe (A,B,C) no crear (A,B))

---

**Fuente**: Sección 8 - Check List de Revisión de Base de Datos BAC Credomatic
