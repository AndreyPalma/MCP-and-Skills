# Completitud - Diseño General y Alcance

Esta referencia cubre los aspectos generales que todo diseño de base de datos debe cumplir antes de ser sometido a revisión.

## Tabla de Contenido

1. [Principios de Diseño General](#1-principios-de-diseño-general)
2. [Requisitos de Presentación](#2-requisitos-de-presentación)
3. [Proceso de Revisión](#3-proceso-de-revisión)
4. [Revisión de RFCs](#4-revisión-de-rfcs)

---

## 1. Principios de Diseño General

### Multi-Regional y Escalable

Todo diseño debe considerar los siguientes factores:
- ✓ **Multi País**: Diseño flexible para operar en diferentes países de la región
- ✓ **Multi Moneda**: Soporte para múltiples monedas sin rediseño
- ✓ **Multi Banco**: Aplicable a diferentes entidades bancarias del grupo
- ✓ **Normalizado**: Cumplir formas normales (mínimo 3FN)
- ✓ **Orientado a Negocio**: Alineado con requerimientos reales de negocio
- ✓ **Escalable**: Diseño que crezca con el tiempo sin reestructuración

**Ejemplo de diseño Multi-Regional:**
```sql
-- CRMATRXPRO: CRM + A (Tabla) + TRX (Transacción) + PRO (Proceso)
CREATE TABLE CRMATRXPRO (
    pais_codigo         FOR CODPAI CHAR(2) NOT NULL,      -- GT, SV, CR, PA, etc.
    banco_codigo        FOR CODBCO CHAR(3) NOT NULL,      -- BAC, CRE, etc.
    moneda_codigo       FOR CODMON CHAR(3) NOT NULL,      -- USD, GTQ, CRC, etc.
    transaccion_id      FOR IDTRX BIGINT NOT NULL,
    -- más campos...
    
    CONSTRAINT pk_trxpro 
        PRIMARY KEY (pais_codigo, banco_codigo, transaccion_id)
);
```

### Evitar Redundancia

⚠ **SIEMPRE verificar antes de crear:**
- ¿Existe un objeto (tabla, vista, índice, lógico) con funcionalidad similar?
- ¿Se puede extender o usar un objeto existente?
- ¿Se están utilizando datos "core" del sistema?

❌ **No crear "silos" de información:**
```sql
-- INCORRECTO: Crear un maestro de clientes específico con datos duplicados
CREATE TABLE CRMACLIBTDC (  -- CRM + A + CLI + TDC (Cliente Tarjeta)
    cif             CHAR(12),
    nombre          VARCHAR(100),
    apellido        VARCHAR(100),
    -- duplicación de datos del core
);

-- CORRECTO: Usar el maestro existente del core
SELECT * FROM COREACLIMST WHERE ...  -- CORE + A + CLI + MST
```

---

## 2. Requisitos de Presentación

### Documentación Obligatoria

Cada historia de revisión DEBE incluir:

1. **Código SQL explícito** de todos los cambios
2. **Justificaciones** del diseño propuesto
3. **Todos los adjuntos** necesarios (modelo, análisis de impacto, etc.)
4. **Congruencia** entre requerimiento y propuesta

### Límites de Revisión

- ✓ **Una historia en la pizarra** de "Los Magníficos" por revisión
- ✓ **Máximo 10 cambios** por historia
- ✓ Si excede 10 cambios, dividir en múltiples historias

### Objetos Sujetos a Revisión

Consultar página oficial: **"Alcance Revisión de Base de Datos"** del equipo de Arquitectura de Datos.

Incluye típicamente:
- Tablas
- Vistas
- Índices
- Stored Procedures
- Triggers
- Functions
- Sequences
- Aliases
- Constraints

---

## 3. Proceso de Revisión

### Niveles de Análisis

El equipo de Arquitectos de Datos realiza revisión en 4 niveles:

#### 1. Análisis de Forma
Verificación de buenas prácticas en la definición del objeto:
- Nomenclatura correcta
- Tipos de datos apropiados
- Constraints definidos
- Documentación completa

#### 2. Análisis de Fondo
Consistencia del requerimiento de negocio con la implementación:
- ¿El diseño resuelve el problema planteado?
- ¿Es la solución óptima?
- ¿Se alinea con objetivos de negocio?

#### 3. Análisis de Arquitectura
Validación sobre la arquitectura actual:
- ¿Se integra correctamente con sistemas existentes?
- ¿Respeta la arquitectura de datos corporativa?
- ¿Afecta otros componentes?

#### 4. Análisis de Datos Sensibles
Verificación de riesgos de seguridad:
- ¿Contiene información sensible?
- ¿Cumple políticas de seguridad de la información?
- ¿Requiere cifrado, enmascaramiento, o controles especiales?

---

## 4. Revisión de RFCs

Los RFCs (Request for Change) para cambios de datos en producción tienen requisitos especiales.

### Alcance de Revisión de RFCs

✓ **Se revisarán:**
- Cambios de datos en producción (UPDATE, DELETE, INSERT masivos)
- Código SQL únicamente

❌ **No se revisarán:**
- Cambios de estructura (usar proceso de pase normal)
- Código en otros lenguajes

### Requisitos Obligatorios para RFCs

1. **Script de Cambio**
```sql
---
-- RFC-2026-123: Corrección de estatus inválidos
--
-- Script de cambio de datos en producción para corregir registros
-- con estatus inválidos en tabla TRANSACCIONES.
--
-- @author Equipo XYZ
-- @date 2026-03-03
-- @project RFC-2026-123
-- @version v1.0
---

-- CAMBIO PRINCIPAL - Usar llave primaria
UPDATE TRANSACCIONES
SET estatus = 'ACTIVO'
WHERE pais_codigo = 'CR'
  AND banco_codigo = 'BAC'
  AND transaccion_id = 123456;  -- Llave primaria
  
-- Registros afectados: 1
```

2. **Script de Rollback**
```sql
-- ROLLBACK - RFC-2026-123
UPDATE TRANSACCIONES
SET estatus = 'PENDIENTE'  -- Valor original
WHERE pais_codigo = 'CR'
  AND banco_codigo = 'BAC'
  AND transaccion_id = 123456;
```

### Reglas Críticas para RFCs

⚠ **Uso de Llave Primaria**
- UPDATE/DELETE DEBEN usar la llave primaria
- Si no es posible, justificar y demostrar control sobre registros afectados

⚠ **Tablas Temporales**
- Crear en bibliotecas NO oficiales
```sql
-- CORRECTO
CREATE TABLE QTEMP.TEMP_DATOS AS (...) WITH DATA;

-- INCORRECTO
CREATE TABLE PROD_DATA.TEMP_DATOS AS (...) WITH DATA;
```

⚠ **Control de Compromiso**
- Validar impacto de transacciones grandes
- Considerar bloqueos en aplicativo
- Evaluar ventanas de mantenimiento

⚠ **Validación Obligatoria**
- Scripts deben probarse en ambiente de pruebas
- Si no es posible probar, elevar el caso
- No se revisan scripts no probados

### Ejemplo Completo de RFC

```sql
---
-- RFC-2026-123: Corrección masiva de códigos de moneda
--
-- Script de cambio masivo para corregir códigos de moneda erróneos
-- en cuentas de Costa Rica. Se corrige de 'COL' a 'CRC' para cuentas
-- abiertas después del 2026-01-01.
--
-- Ambiente: Producción
-- Ventana de mantenimiento: Sábado 15/03/2026 02:00-04:00 AM
-- Registros estimados: 47
--
-- @author Equipo Contabilidad
-- @date 2026-03-03
-- @project RFC-2026-123
-- @version v1.0
---

-- PASO 1: Crear tabla temporal con datos a cambiar
CREATE TABLE QTEMP.CUENTAS_A_CORREGIR AS (
    SELECT pais_codigo, cuenta_numero, moneda_codigo
    FROM PROD_DATA.CUENTAS
    WHERE moneda_codigo = 'COL'  -- Código erróneo
      AND pais_codigo = 'CR'
      AND fecha_apertura > '2026-01-01'
) WITH DATA;

-- Verificar cantidad de registros
SELECT COUNT(*) AS total_registros 
FROM QTEMP.CUENTAS_A_CORREGIR;
-- Resultado esperado: 47 registros

-- PASO 2: Realizar UPDATE usando llave primaria
UPDATE PROD_DATA.CUENTAS C
SET moneda_codigo = 'CRC'
WHERE EXISTS (
    SELECT 1 FROM QTEMP.CUENTAS_A_CORREGIR T
    WHERE T.pais_codigo = C.pais_codigo
      AND T.cuenta_numero = C.cuenta_numero
);

-- Verificar cambio
SELECT COUNT(*) 
FROM PROD_DATA.CUENTAS
WHERE moneda_codigo = 'CRC'
  AND pais_codigo = 'CR'
  AND fecha_apertura > '2026-01-01';
-- Resultado esperado: 47 registros

-- PASO 3: Limpiar tabla temporal
DROP TABLE QTEMP.CUENTAS_A_CORREGIR;

COMMIT;

---
-- ROLLBACK: RFC-2026-123
--
-- Script de rollback para revertir corrección de códigos de moneda.
-- Revierte cambios de 'CRC' a 'COL' en cuentas afectadas.
--
-- @author Equipo Contabilidad
-- @date 2026-03-03
-- @project RFC-2026-123
-- @version v1.0
---

-- Recrear tabla temporal
CREATE TABLE QTEMP.CUENTAS_A_REVERTIR AS (
    SELECT pais_codigo, cuenta_numero
    FROM PROD_DATA.CUENTAS
    WHERE moneda_codigo = 'CRC'
      AND pais_codigo = 'CR'
      AND fecha_apertura > '2026-01-01'
) WITH DATA;

-- Revertir cambio
UPDATE PROD_DATA.CUENTAS C
SET moneda_codigo = 'COL'
WHERE EXISTS (
    SELECT 1 FROM QTEMP.CUENTAS_A_REVERTIR T
    WHERE T.pais_codigo = C.pais_codigo
      AND T.cuenta_numero = C.cuenta_numero
);

-- Limpiar
DROP TABLE QTEMP.CUENTAS_A_REVERTIR;

COMMIT;
```

---

## Checklist de Completitud

Antes de enviar a revisión, verifica:

- [ ] Diseño considera multi-país, multi-moneda, multi-banco
- [ ] Diseño es normalizado (mínimo 3FN)
- [ ] Verificado que no existe objeto similar con misma funcionalidad
- [ ] Se usan datos "core" del sistema (no crear silos)
- [ ] Código SQL explícito incluido
- [ ] Justificaciones documentadas
- [ ] Máximo 10 cambios en la historia
- [ ] Historia ingresada en pizarra de "Los Magníficos"
- [ ] Adjuntos completos (modelo, análisis de impacto)
- [ ] Requerimiento congruente con propuesta
- [ ] Proceso de housekeeping definido (para tablas nuevas)
- [ ] Datos sensibles identificados y coordinados

---

**Fuente**: Sección 1 y 7 - Check List de Revisión de Base de Datos BAC Credomatic
