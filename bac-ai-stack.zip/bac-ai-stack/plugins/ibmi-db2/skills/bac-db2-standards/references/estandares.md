# Estándares y Políticas Corporativas

Esta referencia cubre las políticas y estándares corporativos que deben cumplirse en todos los objetos de base de datos.

## Tabla de Contenido

1. [Dominios y Listas de Valores](#1-dominios-y-listas-de-valores)
2. [Nomenclatura de Constraints](#2-nomenclatura-de-constraints)
3. [Descripcionesignificativas](#3-descripciones-significativas)
4. [Pases a Producción](#4-pases-a-producción)
5. [Objetos Especiales](#5-objetos-especiales)

---

## 1. Dominios y Listas de Valores

### Dominios Lógicos

**Regla:** Cada columna definida sobre un dominio lógico documentado.

Un dominio especifica:
- Tipo de dato físico
- Valores permitidos
- Operaciones válidas
- Reglas de negocio

**Ejemplos de dominios:**

```sql
-- Dominio: CODIGO_PAIS
-- Tipo: CHAR(2)
-- Valores: Códigos ISO 3166-1 alpha-2 (CR, GT, SV, PA, etc.)
-- Operaciones: =, IN, NOT IN
pais_codigo CHAR(2) NOT NULL

-- Dominio: MONTO_MONETARIO
-- Tipo: DECIMAL(15,2)
-- Valores: >= 0
-- Operaciones: +, -, *, /, comparaciones
monto DECIMAL(15,2) NOT NULL
```

### Listas Finitas - Check Constraints

✓ **Lista finita de valores → Check Constraint + Documentación:**

```sql
-- Lista finita y limitada
estatus_cuenta CHAR(1) NOT NULL,

CONSTRAINT ck_cuentas_estatus
    CHECK (estatus_cuenta IN ('A', 'I', 'C', 'B'))
    
-- DOCUMENTAR en metadata
COMMENT ON COLUMN cuentas.estatus_cuenta IS 
    'Estatus de la cuenta: A=Activa, I=Inactiva, C=Cerrada, B=Bloqueada';
```

### Listas Infinitas - Tablas de Referencia

✓ **Lista flexible/extendible → Tabla de referencia + FK:**

```sql
-- Tabla de referencia para lista extendible
CREATE TABLE CAT_CODIGOS_RECHAZO (
    codigo_rechazo      FOR CODRCH CHAR(3) NOT NULL,
    descripcion         FOR DESCRI VARCHAR(100) NOT NULL,
    indicador_activo    FOR INDACT CHAR(1) NOT NULL DEFAULT 'S',
    
    CONSTRAINT pk_codigos_rechazo PRIMARY KEY (codigo_rechazo)
);

-- Uso con FK
-- CRMATRXPRO: CRM + A + TRX + PRO
CREATE TABLE CRMATRXPRO (
    transaccion_id      FOR IDTRX BIGINT NOT NULL,
    codigo_rechazo      FOR CODRCH CHAR(3),
    -- ...
    
    CONSTRAINT fk_trxpro_rechazo
        FOREIGN KEY (codigo_rechazo)
        REFERENCES CAT_CODIGOS_RECHAZO(codigo_rechazo)
        ON DELETE RESTRICT
        ON UPDATE RESTRICT
);
```

**Ejemplos de datos que requieren tabla de referencia:**
- Monedas (extendible)
- Tipos de documentos (puede crecer)
- Motivos de rechazo
- Categorías de productos
- Clasificaciones que cambien en el tiempo

---

## 2. Nomenclatura de Constraints

### Nombramiento Explícito Obligatorio

❌ **NO permitir generación automática:**
```sql
-- INCORRECTO - El motor genera: SYS_C0012345
CREATE TABLE test (id INT PRIMARY KEY);
```

✓ **Definir nombres descriptivos:**
```sql
-- CORRECTO - Nomenclatura estándar
CONSTRAINT pk_transacciones PRIMARY KEY (transaccion_id),
CONSTRAINT fk_transacciones_cuentas FOREIGN KEY (cuenta_id) ...,
CONSTRAINT ck_transacciones_estatus CHECK (estatus IN (...)),
CONSTRAINT uq_transacciones_referencia UNIQUE (referencia_externa)
```

### Estándar de Nomenclatura

| Tipo | Prefijo | Formato |
|------|---------|---------|
| Primary Key | `pk_` | `pk_<nombre_tabla>` |
| Foreign Key | `fk_` | `fk_<tabla>_<tabla_referenciada>` |
| Check | `ck_` | `ck_<tabla>_<campo>` |
| Unique | `uq_` | `uq_<tabla>_<campo(s)>` |
| Default | `df_` | `df_<tabla>_<campo>` |

**Ejemplos:**
```sql
CONSTRAINT pk_cuentas PRIMARY KEY (cuenta_numero)
CONSTRAINT fk_movimientos_cuentas FOREIGN KEY (cuenta_numero) ...
CONSTRAINT ck_cuentas_tipo CHECK (tipo_cuenta IN (...))
CONSTRAINT uq_cuentas_numero_externo UNIQUE (numero_cuenta_externo)
```

### No Contradicciones

❌ **Validar lógica de constraints:**

```sql
-- INCORRECTO - Contradicción
CONSTRAINT ck_edad_minima CHECK (edad >= 18),
CONSTRAINT ck_edad_maxima CHECK (edad < 18)  -- Imposible cumplir ambas!

-- INCORRECTO - Rango imposible
CONSTRAINT ck_saldo_positivo CHECK (saldo > 0),
CONSTRAINT ck_saldo_cero CHECK (saldo = 0)

-- CORRECTO
CONSTRAINT ck_edad_rango CHECK (edad >= 18 AND edad <= 120)
```

---

## 3. Descripciones Significativas

### Descripciones NO Técnicas

Las descripciones deben ser comprensibles para:
- Personal de negocio
- Terceras personas no técnicas
- Auditoría
- Nuevos miembros del equipo

❌ **Insuficiente:**
```sql
COMMENT ON TABLE tabla IS 'Tabla de datos';
COMMENT ON COLUMN tabla.campo IS 'Campo';
COMMENT ON COLUMN tabla.flg IS 'Flag';
COMMENT ON COLUMN tabla.ind IS 'Indicador';
```

✓ **Suficientemente significativo:**
```sql
COMMENT ON TABLE transacciones IS 
    'Registro de todas las transacciones financieras procesadas en los canales electrónicos (ATM, POS, móvil, web) para toda la región';

COMMENT ON COLUMN transacciones.estatus_autorizacion IS 
    'Estatus del proceso de autorización de la transacción. Valores: A=Aprobada y procesada, R=Rechazada por validaciones internas, D=Denegada por emisor, P=Pendiente de confirmación';

COMMENT ON COLUMN transacciones.indicador_reverso IS 
    'Indica si la transacción ha sido reversada posteriormente: S=Sí fue reversada, N=No ha sido reversada, P=Reverso parcial pendiente';
```

### Cada Campo Requiere Descripción

✓ **100% de campos documentados:**
```sql
-- COREACTADEP: CORE + A + CTA + DEP
CREATE TABLE COREACTADEP (
    cuenta_numero       FOR CTANUM BIGINT NOT NULL,
    tipo_cuenta         FOR TIPCTA CHAR(2) NOT NULL,
    moneda_codigo       FOR CODMON CHAR(3) NOT NULL,
    saldo_disponible    FOR SLDDSP DECIMAL(15,2) NOT NULL,
    -- ... más campos
);

-- Describir CADA UNO
COMMENT ON COLUMN cuentas.cuenta_numero IS 
    'Número único identificador de la cuenta a nivel regional';
    
COMMENT ON COLUMN cuentas.tipo_cuenta IS 
    'Tipo de cuenta según catálogo: AH=Ahorro, CC=Cuenta Corriente, DP=Depósito a Plazo';
    
COMMENT ON COLUMN cuentas.moneda_codigo IS 
    'Código de moneda ISO 4217 en la que opera la cuenta (USD, CRC, GTQ, etc.)';
    
COMMENT ON COLUMN cuentas.saldo_disponible IS 
    'Saldo actual disponible para retiros y transacciones, calculado como: saldo contable menos bloqueos activos';
```

---

## 4. Pases a Producción

### SQL con Esquema de Pases

✓ **Todo objeto nuevo vía pase SQL:**
```sql
-- Seguir procedimiento de pases establecido
-- Incluir en paquete de instalación
-- Versionado y catalogado
```

### Objetos Configurables

Si el objeto **impacta funcionalidad** de aplicaciones:
- Tratarlo como elemento configurable
- Pase a producción completo
- Procedimientos de resguardo de fuentes
- Seguir procesos de la empresa
- Catalogación obligatoria

**Ejemplos:**
- Índices usados explícitamente en aplicación
- Índices usados en hoja F de RPG
- Objetos accedidos por nombre en código

### Índices de Performance Únicamente

Si el índice es **solo para mejorar rendimiento**:
- Enviar por RFC
- Nomenclatura especial para evitar colisiones
- No requiere pase completo
- Ver detalles en [Referencias de Índices](indices.md)

---

## 5. Objetos Especiales

### Objetos Apropiados Según Necesidad

Utilizar el objeto correcto para cada situación:

| Necesidad | Objeto Recomendado |
|-----------|-------------------|
| Automatización al insertar/actualizar | `TRIGGER` |
| Consultas complejas recurrentes | `VIEW` o `MQT` |
| Generación de IDs únicos | `SEQUENCE` o `IDENTITY` |
| Lógica de negocio reutilizable | `STORED PROCEDURE` |
| Cálculos complejos reutilizables | `FUNCTION` |
| Consultas muy frecuentes (cache) | `MATERIALIZED QUERY TABLE` |

### Triggers

```sql
-- Ejemplo: Auditoría automática
CREATE TRIGGER trg_cuentas_audit
AFTER UPDATE ON CUENTAS
REFERENCING NEW AS N OLD AS O
FOR EACH ROW
BEGIN
    INSERT INTO CUENTAS_HIST (
        cuenta_numero,
        campo_modificado,
        valor_anterior,
        valor_nuevo,
        usuario,
        fecha_hora
    ) VALUES (
        N.cuenta_numero,
        'saldo_disponible',
        O.saldo_disponible,
        N.saldo_disponible,
        CURRENT USER,
        CURRENT TIMESTAMP
    );
END;
```

### Materialized Query Tables

```sql
-- Para consultas costosas y frecuentes
CREATE TABLE mqt_resumen_diario AS (
    SELECT 
        fecha,
        pais_codigo,
        COUNT(*) AS total_transacciones,
        SUM(monto) AS monto_total
    FROM TRANSACCIONES
    GROUP BY fecha, pais_codigo
)
DATA INITIALLY DEFERRED
REFRESH DEFERRED
MAINTAINED BY USER;

-- Refresh manual o por schedule
REFRESH TABLE mqt_resumen_diario;
```

### Stored Procedures

```sql
CREATE PROCEDURE sp_cerrar_cuenta (
    IN p_cuenta_numero BIGINT,
    IN p_motivo_cierre CHAR(2),
    OUT p_resultado CHAR(1),
    OUT p_mensaje VARCHAR(200)
)
LANGUAGE SQL

BEGIN
    -- Validaciones
    IF NOT EXISTS (SELECT 1 FROM CUENTAS WHERE cuenta_numero = p_cuenta_numero) THEN
        SET p_resultado = 'E';
        SET p_mensaje = 'Cuenta no existe';
        RETURN;
    END IF;
    
    -- Proceso
    UPDATE CUENTAS
    SET estatus = 'C',
        motivo_cierre = p_motivo_cierre,
        fecha_cierre = CURRENT DATE
    WHERE cuenta_numero = p_cuenta_numero;
    
    SET p_resultado = 'S';
    SET p_mensaje = 'Cuenta cerrada exitosamente';
END;

-- Metadata obligatoria
COMMENT ON PROCEDURE sp_cerrar_cuenta IS 
    'Proceso de cierre de cuenta. Valida saldos, bloqueos y dependencias antes de cerrar. Registra motivo y fecha de cierre en la tabla de cuentas.';
```

---

## Lineamientos y Políticas Publicadas

### Compliance Obligatorio

✓ **Cumplir con:**
- Estándares de nomenclatura publicados
- Políticas de seguridad de la información
- Lineamientos de arquitectura de datos
- Políticas de gestión de cambios
- Estándares de documentación

### Creación y Mantenimiento

Para cada tipo de objeto:
- Proceso de creación establecido
- Procedimientos de mantenimiento
- Catalogación obligatoria
- Retención de fuentes
- Control de versiones

### Fuentes de Información

Consultar documentación oficial:
- **Área de Arquitectura de Base de Datos**: Estándares técnicos
- **UAC (Unidad de Administración de Cambios)**: Procedimientos de pases
- **Gerencia de Seguridad**: Políticas de datos sensibles
- **Página oficial**: "Alcance Revisión de Base de Datos"

---

## Ejemplo Completo: Check Constraint con Documentación

```sql
CREATE TABLE PRESTAMOS (
    prestamo_numero     BIGINT NOT NULL,
    estatus_prestamo    CHAR(2) NOT NULL,
    tipo_garantia       CHAR(3),
    -- ...
    
    CONSTRAINT pk_prestamos PRIMARY KEY (prestamo_numero),
    
    -- Check constraint con lista finita
    CONSTRAINT ck_prestamos_estatus
        CHECK (estatus_prestamo IN (
            'SO',  -- Solicitado
            'AN',  -- En análisis
            'AP',  -- Aprobado
            'DE',  -- Desembolsado
            'VI',  -- Vigente
            'MO',  -- En mora
            'CA',  -- Cancelado
            'RE'   -- Rechazado
        )),
    
    -- Constraint de lógica de negocio
    CONSTRAINT ck_prestamos_garantia
        CHECK (
            (estatus_prestamo IN ('SO', 'AN', 'RE') AND tipo_garantia IS NULL)
            OR
            (estatus_prestamo IN ('AP', 'DE', 'VI', 'MO', 'CA') AND tipo_garantia IS NOT NULL)
        )
);

-- Metadata completa
COMMENT ON TABLE prestamos IS 
    'Registro maestro de préstamos otorgados a clientes en toda la región, incluyendo créditos personales, hipotecarios, vehiculares y empresariales';

COMMENT ON COLUMN prestamos.estatus_prestamo IS 
    'Estatus actual del préstamo en su ciclo de vida. Valores: SO=Solicitado por cliente, AN=En análisis crediticio, AP=Aprobado pendiente desembolso, DE=Desembolsado pendiente activación, VI=Vigente con pagos normales, MO=En mora con atrasos, CA=Cancelado completamente, RE=Rechazado por análisis';

COMMENT ON COLUMN prestamos.tipo_garantia IS 
    'Tipo de garantía asociada al préstamo. Valores catálogo CAT_TIPOS_GARANTIA. Obligatorio para préstamos aprobados, NULL para solicitados/rechazados';
```

---

## Checklist de Estándares

- [ ] Cada columna definida sobre dominio lógico documentado
- [ ] Listas finitas implementadas con check constraints
- [ ] Listas infinitas/flexibles con tablas de referencia + FK
- [ ] Constraints nombrados explícitamente (no auto-generados)
- [ ] Nomenclatura estándar: pk_, fk_, ck_, uq_
- [ ] No contradicciones entre constraints
- [ ] Descripción significativa en tabla/vista/SP/función
- [ ] Descripción significativa en CADA campo
- [ ] Descripciones NO técnicas (comprensibles para negocio)
- [ ] Objetos nuevos enviados con esquema de pases SQL
- [ ] Objetos configurables catalogados correctamente
- [ ] Uso de objetos apropiados (triggers, views, SPs, etc.)
- [ ] Cumplimiento de políticas corporativas publicadas
- [ ] Coordinación con UAC para pases a producción
- [ ] Resguardo de fuentes según lineamientos
- [ ] **✅ NUEVO - Checkpoint 107**: Nomenclatura validada con stored procedures oficiales

---

## 6. Validación de Nomenclatura con Stored Procedures Oficiales ✨ NUEVO

### Checkpoint 107: Validación Obligatoria de Nombres

**Pregunta**: ¿Los nombres de objetos fueron validados usando los stored procedures oficiales de LIBMHV?

**Criterio**:
- [x] AVP verificado con `UBDP_CONSULTA_AVP`
- [x] Abreviaturas consultadas con `UBDP_CONSULTA_ABREVIATURAS`
- [x] Nombre validado con `UBDP_VALIDAR_NOMBRES` ANTES de crear el objeto
- [x] Validación aprobada sin errores

### Stored Procedures Oficiales

**LIBMHV.UBDP_CONSULTA_AVP**
- **Propósito**: Verificar que el AVP (Application Version Production) existe en el catálogo oficial
- **Parámetros**: 
  - `PCOD` CHAR(10) IN - Código de AVP a buscar (vacío '' para búsqueda por nombre)
  - `PNOM` VARCHAR(100) IN - Nombre de aplicación para búsqueda (cuando PCOD está vacío)
- **Retorna**: Tabla con columnas AVP, DESCRIPCION, TIPO
- **Uso**: Al inicio del diseño

```sql
-- Opción 1: Verificar AVP específico por código
CALL LIBMHV.UBDP_CONSULTA_AVP('CRM', '');
-- Retorna: 1 fila con AVP='CRM', DESCRIPCION='...', TIPO='...'

-- Opción 2: Buscar AVPs por nombre de aplicación
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'BRIDGER');
-- Retorna múltiples filas:
-- BBRI | (Bridger Banca)                              | PDE
-- CBRI | (Objetos de interfaz Bridger)                | PDE
-- CENB | (Objetos de Base de Datos de Envio Bridger.) | PDE
-- TBRI | (Bridger Tarjetas)                           | PDE
```

**LIBMHV.UBDP_CONSULTA_ABREVIATURAS**
- **Propósito**: Consultar abreviaturas del catálogo oficial (**867 códigos** de LIBMHVTMP.HBDAABRDID)
- **Parámetros**: 
  - `PCOD` CHAR(3) IN - Código de abreviatura a buscar (vacío '' para búsqueda por término)
  - `PTERM` VARCHAR(100) IN - Término de búsqueda (cuando PCOD está vacío)
- **Retorna**: Tabla con columnas CODIGO_ABREVIATURA, DESCRIPCION, NOTAS_VARIAS
- **Uso**: Durante el diseño, para identificar abreviaturas apropiadas

```sql
-- Opción 1: Consultar abreviatura específica por código
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('RPT', '');  -- Respuesta
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('ERR', '');  -- Error

-- Opción 2: Buscar abreviaturas por término de negocio
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'Cliente');
-- Retorna múltiples filas:
-- CIF | Customer Information File                   | Es el nombre abreviado...
-- CTE | Cliente                                     | Cliente
-- POS | POS                                         | Maquina o terminal...
-- CEM | CoEmisor                                    | Entidad bancaria...
-- ... más resultados con 'Cliente' en descripción

-- Opción 3: Query directo a tabla (búsqueda manual)
SELECT CODABR, DESABR, NOTABR
FROM LIBMHVTMP.HBDAABRDID
WHERE UPPER(DESABR) LIKE '%RESPUESTA%'
ORDER BY CODABR;
```

**LIBMHV.UBDP_VALIDAR_NOMBRES**
- **Propósito**: Validar que el nombre del objeto cumple con estándares BAC (formato **[AVP][TIPO][ABR1][ABR2]**)
- **Parámetros**: 
  - `PAVP` CHAR(10) IN - Aplicación/AVP
  - `POBJ` CHAR(10) IN - Tipo: **'A'**, **'I'**, **'T'**, **'P'**, **'F'** (códigos de 1 letra)
  - `PABR1` CHAR(10) IN - Primera abreviatura
  - `PABR2` CHAR(10) IN - Segunda abreviatura
- **Retorna**: 2 filas (valores ingresados + descripciones traducidas)
- **Uso**: ANTES de ejecutar el CREATE (obligatorio)

```sql
-- Validar nombre de tabla ANTES de crear
CALL LIBMHV.UBDP_VALIDAR_NOMBRES(
    'CRM',      -- PAVP: Application/AVP code
    'A',        -- POBJ: 'A'=Tabla, 'I'=Índice, 'T'=Trigger, 'P'=Procedure, 'F'=Función
    'RPT',      -- PABR1: First abbreviation
    'ERR'       -- PABR2: Second abbreviation
);

-- Resultado (2 filas):
-- Fila 1: CRM | A | RPT | ERR | Nombre correcto
-- Fila 2: Programas Relativos a SIEBEL-CRM | Tabla | Respuesta | Error, Fallos | Nombre correcto
-- Si válido, el nombre del objeto es: CRMARPTRERR (CRM + A + RPT + ERR)
-- Proceder a crear:
CREATE TABLE PRODUCCION.CRMARPTRERR (
    RPT_ID          BIGINT NOT NULL,
    ERR_COD         CHAR(5) NOT NULL,
    MTO_RPT         DECIMAL(15,2) NOT NULL,
    ...
);
```

### Workflow de Validación Completo

```sql
-- FASE 1: Buscar AVP apropiado
-- Si conoces el nombre de la aplicación, buscar:
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'BRIDGER');
-- Resultado: BBRI, CBRI, CENB, TBRI (elegir el apropiado)

-- Verificar AVP específico:
CALL LIBMHV.UBDP_CONSULTA_AVP('CRM', '');
-- Si retorna fila con descripción, el AVP es válido

-- FASE 2: Buscar Abreviaturas (867 disponibles)
-- Si conoces el concepto de negocio, buscar:
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'Respuesta');
-- Resultado: RPT=Respuesta (más otras opciones)

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'Error');
-- Resultado: ERR=Error (más otras opciones)

-- Verificar abreviaturas específicas:
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('RPT', '');
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('ERR', '');

-- FASE 3: Validar Nombre Propuesto (formato [AVP][TIPO][ABR1][ABR2])
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('CRM', 'A', 'RPT', 'ERR');
-- Resultado: 2 filas con mensaje "Nombre correcto"

-- FASE 4: Crear Objeto (solo si validación exitosa)
-- Nombre resultante: CRMARPTRERR (CRM + A + RPT + ERR)
CREATE TABLE PRODUCCION.CRMARPTRERR (
    -- Campos...
);
```

### Tipos de Objeto Soportados

| Tipo | Código POBJ | Ejemplo Nombre Resultante |
|------|--------------|---------------------------|
| Tabla | **'A'** | CRMARPTRERR (CRM + A + RPT + ERR) |
| Índice | **'I'** | CRMIPRTERR (CRM + I + RPT + ERR) |
| Trigger | **'T'** | CRMTRPTERR (CRM + T + RPT + ERR) |
| Stored Procedure | **'P'** | CRMPINSRPT (CRM + P + INS + RPT) |
| Función | **'F'** | CRMFCALCSAL (CRM + F + CALC + SAL) |

⚠️ **NO soportados por UBDP_VALIDAR_NOMBRES**: Vista, Secuencia, Campo (validar manualmente)

### Ejemplo Correcto (Con Validación)

```sql
-- ✅ CORRECTO: Validación previa con stored procedures

-- Paso 1: Buscar y verificar AVP
-- Si solo conoces el nombre: buscar primero
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'SIEBEL');
-- Elegir: CRM (Programas Relativos a SIEBEL-CRM)

-- Verificar AVP elegido
CALL LIBMHV.UBDP_CONSULTA_AVP('CRM', '');

-- Paso 2: Buscar abreviaturas apropiadas (867 disponibles)
-- Por concepto de negocio:
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'Respuesta');
-- Resultado incluye: RPT=Respuesta

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'Error');
-- Resultado incluye: ERR=Error, Fallos

-- Verificar códigos elegidos:
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('RPT', '');
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('ERR', '');

-- Paso 3: Validar nombre (formato [AVP][TIPO][ABR1][ABR2])
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('CRM', 'A', 'RPT', 'ERR');
-- Resultado: 2 filas con mensaje "Nombre correcto"

-- Paso 4: Crear objeto (nombre validado ✓): CRMARPTRERR
CREATE TABLE PRODUCCION.CRMARPTRERR (
    RPT_ID              BIGINT          NOT NULL,
    ERR_COD             CHAR(5)         NOT NULL,
    TIP_ERR             CHAR(2)         NOT NULL,
    EST_ERR             CHAR(1)         NOT NULL,
    MTO_ERR             DECIMAL(15,2)   NOT NULL,
    FEC_ERR             DATE            NOT NULL,
    
    -- Auditoría obligatoria
    USUARIOCREACION     FOR USRCRE CHAR(18),
    FECHACREACION       FOR FECCRE TIMESTAMP DEFAULT CURRENT TIMESTAMP,
    USUARIOMODIFICA     FOR USRMOD CHAR(18),
    FECHAMODIFICA       FOR FECMOD TIMESTAMP,
    
    CONSTRAINT pk_rpt_err PRIMARY KEY (RPT_ID)
);

-- Paso 5: Validar nombre de índice
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('CRM', 'I', 'RPT', 'ERR');

-- Paso 6: Crear índice (nombre validado ✓)
CREATE INDEX PRODUCCION.IXF_RPTRERR_FEC
    ON CRMARPTRERR (FEC_ERR DESC);
```

### Ejemplo Incorrecto (Sin Validación)

```sql
-- ❌ INCORRECTO: Crear sin validar nomenclatura

-- Se crea directamente sin consultar SPs oficiales
CREATE TABLE PRODUCCION.CLIENTES_TRANSACCIONES (
    -- Nombre no sigue abreviaturas oficiales
    -- No fue validado con UBDP_VALIDAR_NOMBRES
    -- Alto riesgo de rechazo en revisión DBA
);
```

### Impacto si NO se Cumple

- ⚠️ **Rechazo en revisión DBA**: Nomenclatura no oficial
- ⚠️ **Retrabajo**: Necesidad de renombrar objetos después de creados
- ⚠️ **Inconsistencia**: No alineado con catálogo de **867 abreviaturas oficiales**
- ⚠️ **Dificultad de mantenimiento**: Nombres no estándar dificultan comprensión
- ⚠️ **Riesgo de colisión**: Nombres inventados pueden duplicarse

### Beneficios de Validación con SPs

- ✅ **Primera vez correcto**: 90%+ de aprobación en primera revisión
- ✅ **Consistencia**: Uso de catálogo oficial de **867 abreviaturas** (LIBMHVTMP.HBDAABRDID)
- ✅ **Reducción de ciclos**: De 3-5 ciclos a 1 ciclo de revisión DBA
- ✅ **Velocidad**: Tiempo de aprobación de 4 días a 1 día
- ✅ **Cumplimiento**: 100% alineado con políticas corporativas

### Referencias

- **Catálogo completo**: Ver [Nomenclaturas Oficiales](nomenclaturas.md)
- **Tabla de abreviaturas**: `LIBMHVTMP.HBDAABRDID` (**867 códigos oficiales**, NO usar LIBMHV.ABREVIA)
- **Documentación visual**: `docs/images/nomenclatura_*.jpg`

---

**Total de checkpoints**: **107** (106 anteriores + 1 nuevo de validación con SPs)

---

**Fuente**: Sección 3 - Check List de Revisión de Base de Datos BAC Credomatic
