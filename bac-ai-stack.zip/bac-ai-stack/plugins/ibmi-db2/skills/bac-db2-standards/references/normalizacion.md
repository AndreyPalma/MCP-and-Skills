# Normalización - Formas Normales y Diseño Relacional

Esta referencia cubre los requisitos de normalización que deben cumplirse en el diseño de tablas.

## Tabla de Contenido

1. [Formas Normales Requeridas](#1-formas-normales-requeridas)
2. [Integridad Referencial](#2-integridad-referencial)
3. [Diseño de Campos](#3-diseño-de-campos)
4. [Anti-patrones a Evitar](#4-anti-patrones-a-evitar)

---

## 1. Formas Normales Requeridas

### Mínimo: Tercera Forma Normal (3FN)

**Requisito:** Todo diseño debe cumplir AL MENOS con 3FN.

### Primera Forma Normal (1FN)

✓ **Elimina grupos repetidos - Each atributo tiene identidad propia y atómica**

❌ **INCORRECTO - Grupos repetidos:**
```sql
CREATE TABLE CLIENTES_MAL (
    cliente_id      INT,
    nombre          VARCHAR(100),
    telefono1       VARCHAR(20),  -- Grupo repetido
    telefono2       VARCHAR(20),  -- Grupo repetido
    telefono3       VARCHAR(20),  -- Grupo repetido
    email1          VARCHAR(100), -- Grupo repetido
    email2          VARCHAR(100)  -- Grupo repetido
);
```

✓ **CORRECTO - Identidad propia:**
```sql
CREATE TABLE CLIENTES (
    cliente_id      INT NOT NULL,
    nombre          VARCHAR(100) NOT NULL,
    PRIMARY KEY (cliente_id)
);

CREATE TABLE CLIENTES_TELEFONOS (
    cliente_id      INT NOT NULL,
    telefono        VARCHAR(20) NOT NULL,
    tipo_telefono   CHAR(1) NOT NULL,  -- C=Casa, O=Oficina, M=Móvil
    PRIMARY KEY (cliente_id, telefono),
    FOREIGN KEY (cliente_id) REFERENCES CLIENTES(cliente_id)
        ON DELETE RESTRICT ON UPDATE RESTRICT
);

CREATE TABLE CLIENTES_EMAILS (
    cliente_id      INT NOT NULL,
    email           VARCHAR(100) NOT NULL,
    tipo_email      CHAR(1) NOT NULL,  -- P=Personal, T=Trabajo
    PRIMARY KEY (cliente_id, email),
    FOREIGN KEY (cliente_id) REFERENCES CLIENTES(cliente_id)
        ON DELETE RESTRICT ON UPDATE RESTRICT
);
```

### Segunda Forma Normal (2FN)

✓ **Elimina dependencias parciales de la llave**

Campos deben depender de **toda la llave**, no de parte de ella.

❌ **INCORRECTO - Dependencia parcial:**
```sql
CREATE TABLE DETALLE_ORDEN_MAL (
    orden_id            INT NOT NULL,
    producto_id         INT NOT NULL,
    producto_nombre     VARCHAR(100),  -- Depende solo de producto_id
    producto_categoria  VARCHAR(50),   -- Depende solo de producto_id
    cantidad            INT NOT NULL,
    precio_unitario     DECIMAL(11,2),
    PRIMARY KEY (orden_id, producto_id)
);
-- producto_nombre depende solo de producto_id, no de la llave completa
```

✓ **CORRECTO - Sin dependencias parciales:**
```sql
CREATE TABLE PRODUCTOS (
    producto_id         INT NOT NULL,
    producto_nombre     VARCHAR(100) NOT NULL,
    producto_categoria  VARCHAR(50) NOT NULL,
    PRIMARY KEY (producto_id)
);

CREATE TABLE DETALLE_ORDEN (
    orden_id            INT NOT NULL,
    producto_id         INT NOT NULL,
    cantidad            INT NOT NULL,
    precio_unitario     DECIMAL(11,2) NOT NULL,
    PRIMARY KEY (orden_id, producto_id),
    FOREIGN KEY (producto_id) REFERENCES PRODUCTOS(producto_id)
        ON DELETE RESTRICT ON UPDATE RESTRICT
);
```

### Tercera Forma Normal (3FN)

✓ **Elimina dependencias transitivas**

Campos no-llave deben depender **directamente de la llave**, no de otros campos no-llave.

> *"Dependiente de la llave, de toda la llave, y de nada más que la llave"*

❌ **INCORRECTO - Dependencia transitiva:**
```sql
CREATE TABLE EMPLEADOS_MAL (
    empleado_id         INT NOT NULL,
    nombre              VARCHAR(100),
    departamento_id     INT NOT NULL,
    departamento_nombre VARCHAR(100),  -- Depende de departamento_id, no de empleado_id
    departamento_jefe   VARCHAR(100),  -- Depende de departamento_id, no de empleado_id
    salario             DECIMAL(11,2),
    PRIMARY KEY (empleado_id)
);
-- departamento_nombre depende de departamento_id, que depende de empleado_id (transitivo)
```

✓ **CORRECTO - Sin dependencias transitivas:**
```sql
CREATE TABLE DEPARTAMENTOS (
    departamento_id     INT NOT NULL,
    departamento_nombre VARCHAR(100) NOT NULL,
    departamento_jefe   VARCHAR(100),
    PRIMARY KEY (departamento_id)
);

CREATE TABLE EMPLEADOS (
    empleado_id         INT NOT NULL,
    nombre              VARCHAR(100) NOT NULL,
    departamento_id     INT NOT NULL,
    salario             DECIMAL(11,2) NOT NULL,
    PRIMARY KEY (empleado_id),
    FOREIGN KEY (departamento_id) REFERENCES DEPARTAMENTOS(departamento_id)
        ON DELETE RESTRICT ON UPDATE RESTRICT
);
```

---

## 2. Integridad Referencial

### Usar Constraints Explícitos

✓ **Integridad referencial obligatoria donde aplique:**

```sql
CREATE TABLE TRANSACCIONES (
    transaccion_id  BIGINT NOT NULL,
    cuenta_numero   BIGINT NOT NULL,
    moneda_codigo   CHAR(3) NOT NULL,
    -- ...
    PRIMARY KEY (transaccion_id)
);

-- FK explícita, NO dentro de CREATE TABLE
ALTER TABLE TRANSACCIONES
    ADD CONSTRAINT fk_transacciones_cuentas
    FOREIGN KEY (cuenta_numero)
    REFERENCES CUENTAS(cuenta_numero)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;

ALTER TABLE TRANSACCIONES
    ADD CONSTRAINT fk_transacciones_monedas
    FOREIGN KEY (moneda_codigo)
    REFERENCES CAT_MONEDAS(moneda_codigo)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;
```

### Restricción: Maestros del Core No Migrados

❌ **NO colocar FK hacia maestros no migrados:**

```sql
-- INCORRECTO - Si MAESTRO_CLIENTES es del core no migrado
ALTER TABLE MI_TABLA
    ADD CONSTRAINT fk_mi_tabla_clientes
    FOREIGN KEY (cif)
    REFERENCES CORE_VIEJO.MAESTRO_CLIENTES(cif)  -- NO hacer esto
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;

-- Razón: Maestros del core viejo pueden tener problemas de:
-- - Integridad
-- - Performance
-- - Sincronización
```

✓ **Alternativa - Validación por programación:**
```sql
-- Validar en SP o código de aplicación
CREATE PROCEDURE sp_insertar_registro (
    IN p_cif CHAR(12),
    ...
)
BEGIN
    -- Validar existencia manualmente
    IF NOT EXISTS (SELECT 1 FROM CORE_VIEJO.MAESTRO_CLIENTES WHERE cif = p_cif) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CIF no existe';
    END IF;
    
    -- Continuar con inserción
    INSERT INTO MI_TABLA ...;
END;
```

### No IR entre DDS y SQL

⚠ **Archivos DDS con SQL: No usar FK explícita**

```sql
-- Si tabla_dds es un archivo DDS (no SQL)
-- NO crear FK explícita, usar validación programática
```

---

## 3. Diseño de Campos

### Atributos Simples (No Compuestos)

❌ **INCORRECTO - Campos compuestos:**
```sql
nombre_completo VARCHAR(200)  -- Compuesto de varios elementos
```

✓ **CORRECTO - Atributos simples:**
```sql
primer_nombre       VARCHAR(50) NOT NULL,
segundo_nombre      VARCHAR(50),
primer_apellido     VARCHAR(50) NOT NULL,
segundo_apellido    VARCHAR(50),
apellido_casada     VARCHAR(50)
```

**Beneficios:**
- Búsquedas específicas (por apellido)
- Ordenamiento correcto
- Validaciones individuales
- Reportes segmentados

### Atributos Monovaluados (No Multivaluados)

❌ **INCORRECTO - Multivaluados:**
```sql
telefono1 VARCHAR(20),
telefono2 VARCHAR(20),
telefono3 VARCHAR(20)
```

✓ **CORRECTO - Tabla relacionada:**
```sql
-- Ver ejemplo en Primera Forma Normal
CREATE TABLE CLIENTES_TELEFONOS (
    cliente_id  INT,
    telefono    VARCHAR(20),
    tipo        CHAR(1),
    PRIMARY KEY (cliente_id, telefono)
);
```

### No Campos Derivados

❌ **INCORRECTO - Campo derivado:**
```sql
CREATE TABLE PERSONAS (
    persona_id          INT,
    fecha_nacimiento    DATE NOT NULL,
    edad                INT  -- Derivado de fecha_nacimiento ❌
);
```

✓ **CORRECTO - Calcular cuando se necesite:**
```sql
CREATE TABLE PERSONAS (
    persona_id          INT NOT NULL,
    fecha_nacimiento    DATE NOT NULL,
    PRIMARY KEY (persona_id)
);

-- Vista con campo calculado
CREATE VIEW vw_personas_detalle AS
SELECT 
    persona_id,
    fecha_nacimiento,
    TIMESTAMPDIFF(YEAR, fecha_nacimiento, CURRENT DATE) AS edad
FROM PERSONAS;
```

**Campos derivados comunes a evitar:**
- edad (derivado de fecha_nacimiento)
- saldo_total (derivado de suma de movimientos)
- nombre_completo (derivado de primer_nombre + apellidos)
- dias_mora (derivado de fecha_vencimiento y fecha_actual)

---

## 4. Anti-patrones a Evitar

### Redundancia y Ambigüedad

❌ **NO redundar información:**

```sql
-- INCORRECTO - Redundancia de información de moneda
CREATE TABLE TRANSACCIONES_MAL (
    transaccion_id      BIGINT,
    moneda_codigo       CHAR(3),
    moneda_nombre       VARCHAR(50),  -- Redundante
    moneda_simbolo      CHAR(3),      -- Redundante
    moneda_decimales    INT           -- Redundante
);

-- CORRECTO - Usar FK a tabla de monedas
CREATE TABLE TRANSACCIONES (
    transaccion_id      BIGINT,
    moneda_codigo       CHAR(3),
    FOREIGN KEY (moneda_codigo) REFERENCES CAT_MONEDAS(moneda_codigo)
);
```

### No Duplicar Estructuras

❌ **Evitar tablas similares con misma función:**

```sql
-- INCORRECTO - Silos de información
CREATE TABLE CLIENTES_TARJETAS (...);
CREATE TABLE CLIENTES_PRESTAMOS (...);
CREATE TABLE CLIENTES_CUENTAS (...);
-- Todos almacenando datos básicos del cliente

-- CORRECTO - Maestro único
CREATE TABLE CLIENTES (...);  -- Maestro centralizado

CREATE TABLE TARJETAS (
    tarjeta_numero  CHAR(16),
    cliente_id      INT,
    FOREIGN KEY (cliente_id) REFERENCES CLIENTES(cliente_id)
);
```

---

## Ejemplo Completo: Diseño Normalizado

### Caso: Sistema de Órdenes

✓ **Diseño correcto en 3FN:**

```sql
-- 1. CLIENTES
CREATE TABLE CLIENTES (
    cliente_id          INT NOT NULL,
    primer_nombre       VARCHAR(50) NOT NULL,
    primer_apellido     VARCHAR(50) NOT NULL,
    fecha_nacimiento    DATE NOT NULL,
    PRIMARY KEY (cliente_id)
);

-- 2. PRODUCTOS
CREATE TABLE PRODUCTOS (
    producto_id         INT NOT NULL,
    nombre_producto     VARCHAR(100) NOT NULL,
    categoria_id        INT NOT NULL,
    precio_base         DECIMAL(11,2) NOT NULL,
    PRIMARY KEY (producto_id)
);

CREATE TABLE CATEGORIAS (
    categoria_id        INT NOT NULL,
    nombre_categoria    VARCHAR(50) NOT NULL,
    PRIMARY KEY (categoria_id)
);

ALTER TABLE PRODUCTOS
    ADD CONSTRAINT fk_productos_categorias
    FOREIGN KEY (categoria_id) REFERENCES CATEGORIAS(categoria_id)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

-- 3. ÓRDENES
CREATE TABLE ORDENES (
    orden_id            INT NOT NULL,
    cliente_id          INT NOT NULL,
    fecha_orden         DATE NOT NULL,
    estatus             CHAR(1) NOT NULL,
    PRIMARY KEY (orden_id),
    CONSTRAINT ck_ordenes_estatus CHECK (estatus IN ('P', 'C', 'E', 'X'))
);

ALTER TABLE ORDENES
    ADD CONSTRAINT fk_ordenes_clientes
    FOREIGN KEY (cliente_id) REFERENCES CLIENTES(cliente_id)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

-- 4. DETALLE ÓRDENES
CREATE TABLE ORDENES_DETALLE (
    orden_id            INT NOT NULL,
    linea_numero        INT NOT NULL,
    producto_id         INT NOT NULL,
    cantidad            INT NOT NULL,
    precio_unitario     DECIMAL(11,2) NOT NULL,
    PRIMARY KEY (orden_id, linea_numero)
);

ALTER TABLE ORDENES_DETALLE
    ADD CONSTRAINT fk_detalle_ordenes
    FOREIGN KEY (orden_id) REFERENCES ORDENES(orden_id)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE ORDENES_DETALLE
    ADD CONSTRAINT fk_detalle_productos
    FOREIGN KEY (producto_id) REFERENCES PRODUCTOS(producto_id)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

-- 5. VISTAPara totales (no almacenar derivados)
CREATE VIEW vw_ordenes_totales AS
SELECT 
    o.orden_id,
    o.cliente_id,
    c.primer_nombre || ' ' || c.primer_apellido AS nombre_cliente,
    o.fecha_orden,
    o.estatus,
    SUM(d.cantidad * d.precio_unitario) AS total_orden,
    COUNT(d.linea_numero) AS total_lineas
FROM ORDENES o
JOIN CLIENTES c ON o.cliente_id = c.cliente_id
JOIN ORDENES_DETALLE d ON o.orden_id = d.orden_id
GROUP BY o.orden_id, o.cliente_id, c.primer_nombre, c.primer_apellido, 
         o.fecha_orden, o.estatus;
```

**¿Por qué está en 3FN?**

1. **1FN**: Todos los atributos son atómicos (no grupos repetidos)
2. **2FN**: No hay dependencias parciales (campos dependen de toda la llave)
3. **3FN**: No hay dependencias transitivas (campos no-llave no dependen de otros campos no-llave)

---

## Checklist de Normalización

- [ ] Cumple Primera Forma Normal (atributos atómicos, sin grupos repetidos)
- [ ] Cumple Segunda Forma Normal (sin dependencias parciales)
- [ ] Cumple Tercera Forma Normal (sin dependencias transitivas)
- [ ] Mínimo 3FN en todas las tablas
- [ ] Integridad referencial explícita donde aplique
- [ ] No FK hacia maestros del core no migrados
- [ ] Validación programática para archivos DDS (si aplica)
- [ ] Campos simples, no compuestos (nombre separado de apellido)
- [ ] Campos monovaluados, no multivaluados (una tabla para teléfonos)
- [ ] Sin campos derivados almacenados (calcular en vistas/queries)
- [ ] Sin redundancia de datos entre tablas
- [ ] Sin ambigüedad o contradicción en diseño
- [ ] No duplicación de estructuras similares (evitar silos)

---

**Fuente**: Sección 4 - Check List de Revisión de Base de Datos BAC Credomatic
