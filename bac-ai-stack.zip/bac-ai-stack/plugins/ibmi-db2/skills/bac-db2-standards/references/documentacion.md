# Documentación y Metadata

Esta referencia cubre los requisitos de documentación obligatoria para todos los objetos de base de datos.

## Tabla de Contenido

0. [Formato de Comentarios en Código](#0-formato-de-comentarios-en-código)
1. [Metadata de Tablas y Vistas](#1-metadata-de-tablas-y-vistas)
2. [Metadata de Campos](#2-metadata-de-campos)
3. [Metadata de Índices](#3-metadata-de-índices)
4. [Metadata de Objetos Programáticos](#4-metadata-de-objetos-programáticos)
5. [Documentación en Código SQL](#5-documentación-en-código-sql)

---

## 0. Formato de Comentarios en Código

### Estándar de Formato de Encabezado

✓ **Todos los objetos deben iniciar con bloque de comentarios estándar:**

```sql
---
-- NOMBRE_OBJETO: Descripción breve del propósito (1 línea)
--
-- Descripción detallada del objeto explicando su funcionalidad,
-- alcance, contexto de uso y cualquier información relevante para
-- entender el propósito del objeto. Debe ser comprensible para
-- personal de negocio y nuevos miembros del equipo.
--
-- @author Nombre del Autor
-- @date YYYY-MM-DD
-- @project Código de Proyecto (ej: MSN-8140)
-- @version PN-número
---
```

### Elementos Obligatorios del Encabezado

| Elemento | Descripción | Ejemplo |
|----------|-------------|---------|
| **Nombre** | Nombre del objeto + descripción breve (1 línea) | `MCCAPAIPAR: Parámetros por país` |
| **Descripción** | Explicación detallada (2-5 líneas) | Ver ejemplos abajo |
| **@author** | Nombre completo del creador | `Luis Fernández Soto` |
| **@date** | Fecha de creación formato ISO | `2025-03-04` |
| **@project** | Código de proyecto o iniciativa | `MSN-8140 FEES` |
| **@version** | Número de versión o PN | `PN-0015647` |

### Ejemplos por Tipo de Objeto

#### Tabla

```sql
---
-- CRMARPTRERR: Registro de respuestas con errores
--
-- Tabla que almacena el registro de respuestas que generaron errores
-- durante el procesamiento en el sistema CRM. Incluye código de error,
-- descripción, tipo de error y estatus. Utilizada para análisis de
-- fallos y métricas de calidad del servicio.
--
-- @author Ana Gómez
-- @date 2025-03-04
-- @project CRM-MONITORING
-- @version PN-0019500
---
CREATE TABLE PRODUCCION.CRMARPTRERR (
    RPT_ID              BIGINT NOT NULL,
    ERR_COD             CHAR(5) NOT NULL,
    -- ... más campos
    CONSTRAINT pk_rpt_err PRIMARY KEY (RPT_ID)
);

COMMENT ON TABLE CRMARPTRERR IS
    'Registro de respuestas con errores del sistema CRM para análisis de fallos';
```

#### Vista

```sql
---
-- CUMACNSCTA: Consulta de clientes por número de cuenta
--
-- Vista que permite consultar información completa de clientes a partir
-- de su número de cuenta, combinando datos de clientes (CUMST) y cuentas
-- (ACMSTTB). Utilizada por el servicio de consulta de clientes (12139).
--
-- @author Luis Fernández Soto
-- @date 2025-10
-- @version PN-0019404
---
CREATE OR REPLACE VIEW CUMACNSCTA AS (
    SELECT /* campos */
    FROM CUMST C
    INNER JOIN ACMSTTB AC ON AC.ACMCUN = C.CUSCUN
);

COMMENT ON VIEW CUMACNSCTA IS
    'Vista de consulta de clientes por número de cuenta';
```

#### Stored Procedure

```sql
---
-- MCCPVALPAI: Validar país para comisión
--
-- Procedimiento que valida si un país está configurado para cobro de
-- comisiones y retorna sus parámetros (excepción adulto mayor, porcentaje
-- IVA). Valida estatus activo y existencia del país en catálogo.
--
-- Parámetros:
--   P_CODIGO_PAIS: Código ISO del país (3 caracteres)
--   R_EXCEPCION_ADULTO_MAYOR: Indicador de excepción (S/N)
--   R_PORCENTAJE_IVA: Porcentaje de IVA aplicable
--   R_VALIDO: Indicador de validación exitosa (S/N)
--
-- @author ALPHA
-- @date 2024-10-10
-- @project MSN-8140 FEES
-- @version PN-0015647
---
CREATE OR REPLACE PROCEDURE MCCPVALPAI (
    IN  P_CODIGO_PAIS CHAR(3),
    OUT R_EXCEPCION_ADULTO_MAYOR CHAR(1),
    OUT R_PORCENTAJE_IVA DECIMAL(5,2),
    OUT R_VALIDO CHAR(1)
)
LANGUAGE SQL
BEGIN
    -- Lógica del procedimiento
END;

COMMENT ON PROCEDURE MCCPVALPAI IS
    'Validación de país para cobro de comisiones';
```

#### Función

```sql
---
-- IBSFTESTOT: Totales de tesorería por cajas
--
-- Función que consulta y calcula los totales de transacciones realizadas
-- sobre cuentas contables de tesorería durante el día, según el concepto
-- que identifica la cuenta. Retorna cantidad, ingresos, egresos, saldo
-- inicial y saldo final.
--
-- Parámetros:
--   TELLER: Usuario del IBS Branch para obtener banco y sucursal
--   CURRENCY: Moneda de la cuenta de tesorería
--   CONCEPT: Concepto que identifica la cuenta en CNOFC
--
-- Retorna:
--   QUANTITY: Cantidad de movimientos realizados
--   INCOME: Suma de montos entrantes
--   EXPENSES: Suma de montos salientes
--   START: Monto inicial
--   FINAL: Monto final
--
-- @author ALPHA
-- @date 2023-10
-- @project PN-0008322
-- @version PN-0015672
---
CREATE OR REPLACE FUNCTION IBSFTESTOT (
    TELLER CHAR(3),
    CURRENCY CHAR(3),
    CONCEPT CHAR(3)
)
RETURNS TABLE (
    QUANTITY INT,
    INCOME DECIMAL(13,2),
    /* ... más campos */
)
LANGUAGE SQL
BEGIN
    RETURN SELECT /* ... */;
END;

COMMENT ON FUNCTION IBSFTESTOT IS
    'Retorna los totales de tesorería por cajas';
```

#### Índice

```sql
---
-- BRIISBSB01: Índice funcional para tabla BRIISBCB
--
-- Índice creado para optimizar el acceso y lectura de la tabla BRIASBCBIT
-- por los campos ACCION e IDSUBESTADO. Implementado para mejorar el
-- rendimiento durante el proceso de IPL en servidores.
--
-- @author Oscar Stanley Sandoval Rivera
-- @date 2025-04-24
-- @project Creación de índices por IPL
-- @version v1.0
---
CREATE INDEX BRIISBCB01 ON BRIASBCBIT (ACCION, IDSUBESTADO);
```

### Comentarios Inline en Lógica

✓ **Para explicar lógica compleja dentro del código:**

```sql
BEGIN
    -- Validar que el cliente tenga productos activos
    IF (SELECT COUNT(*) FROM PRODUCTOS WHERE CLI_ID = p_cliente_id) = 0 THEN
        SIGNAL SQLSTATE '70001' SET MESSAGE_TEXT = 'Cliente sin productos';
    END IF;
    
    --#region Cálculo de comisiones
    -- Comisiones se calculan según tabla de tarifas vigente
    -- considerando tipo de cliente y saldo promedio trimestral
    SET v_comision = (
        SELECT tarifa_monto
        FROM TARIFAS
        WHERE tipo_cliente = v_tipo_cli
          AND saldo_minimo <= v_saldo_promedio
    );
    --#endregion
    
    -- Aplicar descuento por fidelidad si aplica
    IF v_antiguedad_anos >= 5 THEN
        SET v_comision = v_comision * 0.90;  -- 10% descuento
    END IF;
END;
```

### Comentarios para Historial de Cambios

✓ **Para procedimientos/funciones con múltiples versiones:**

```sql
---
-- IBSFTESTOT: Totales de tesorería por cajas
--
-- [Descripción principal...]
--
-- @author ALPHA
-- @date 2023-10
-- @project PN-0008322
-- @version PN-0015672
--
-- Historial de cambios:
-- @rev 2024-10 ALPHA - PN-0015091: Se quita de los cálculos las comisiones
-- @rev 2024-12 ALPHA - PN-0015672: Se cambia join con AUDIT para mejorar performance
---
```

### ❌ Formatos NO Recomendados

**Evitar:**

```sql
-- ❌ Bloques decorativos con bordes
--************************************************************
--* NOMBRE: MI_TABLA                                         *
--* AUTOR: JUAN PEREZ                                        *
--************************************************************

-- ❌ Encabezados extensos con palabras clave repetitivas
-- NOMBRE DE LA TABLA:
--   MI_TABLA
-- DESCRIPCIÓN:
--   TABLA DE DATOS
-- OBJETIVO:
--   ALMACENAR DATOS
-- TIPO DE TABLA:
--   MAESTRA
-- ORIGEN DE LOS DATOS:
--   SISTEMA X
-- PERMANENCIA:
--   PERMANENTE
-- USO:
--   CONSULTAS
-- FLUJO:
--   ENTRADA MANUAL

-- ❌ Comentarios técnicos poco útiles
-- Esta es la tabla
-- Tiene campos
-- Se crea con CREATE TABLE
```

### Beneficios del Formato Estándar

- ✅ **Consistencia**: Mismo formato en todos los objetos
- ✅ **Trazabilidad**: Información de autor, proyecto y versión
- ✅ **Mantenibilidad**: Fácil de actualizar y entender
- ✅ **Profesional**: Aspecto limpio y organizado
- ✅ **Comprensible**: Para técnicos y no técnicos
- ✅ **Compatible**: Con `COMMENT ON` obligatorio

---

## 1. Metadata de Tablas y Vistas

### Obligatorio: Descripción de Tabla/Vista

✓ **Toda tabla nueva requiere COMMENT ON TABLE:**

```sql
CREATE TABLE TRANSACCIONES_ONLINE (
    transaccion_id      FOR IDTRX BIGINT NOT NULL,
    -- ... campos
    PRIMARY KEY (transaccion_id)
);

-- OBLIGATORIO
COMMENT ON TABLE TRANSACCIONES_ONLINE IS 
    'Registro de transacciones procesadas a través de canales digitales (banca móvil, banca web, API) para todos los países de la región. Incluye transferencias, pagos de servicios y consultas que generan movimiento contable';
```

### Características de Buena Metadata de Tabla

✓ **Descripción debe incluir:**
1. **Propósito**: ¿Qué almacena?
2. **Alcance**: ¿Regional, país específico, producto específico?
3. **Contexto**: ¿De dónde vienen los datos?
4. **Relación**: ¿Cómo se integra con otros objetos?

**Ejemplos:**

```sql
-- Ejemplo 1: Tabla de Configuración
COMMENT ON TABLE PARAMETROS_TASAS IS 
    'Parámetros de tasas de interés y comisiones aplicables a productos crediticios. Configurable por país, tipo de producto y rango de monto. Utilizada por motor de cálculo de intereses en proceso nocturno';

-- Ejemplo 2: Tabla Transaccional
COMMENT ON TABLE BITACORA_ACCESOS IS 
    'Bitácora de auditoría de todos los accesos a sistemas críticos. Registra usuario, fecha/hora, acción realizada e IP origen. Requerido por normativa de seguridad SOX. Retención: 7 años';

-- Ejemplo 3: Tabla Maestra
COMMENT ON TABLE COREAPRDMST IS 
    'Catálogo maestro regional de productos financieros disponibles (cuentas, préstamos, tarjetas, inversiones). Incluye configuración de características, comisiones y reglas de negocio por producto';

-- Ejemplo 4: Vista
COMMENT ON VIEW VW_CARTERA_VIGENTE IS 
    'Vista consolidada de cartera de préstamos vigentes con saldos actualizados. Combina datos de PRESTAMOS, MOVIMIENTOS_PRESTAMO y PAGOS. Utilizada para reportería gerencial y regulatoria';
```

---

## 2. Metadata de Campos

### Obligatorio: Descripción de CADA Campo

✓ **Cada columna debe tener COMMENT ON COLUMN:**

```sql
-- COREACTADEP: CORE + A (Tabla) + CTA (Cuenta) + DEP (Depósito)
CREATE TABLE COREACTADEP (
    cuenta_numero           FOR CTANUM BIGINT NOT NULL,
    tipo_cuenta             FOR TIPCTA CHAR(2) NOT NULL,
    moneda_codigo           FOR CODMON CHAR(3) NOT NULL,
    saldo_disponible        FOR SLDDSP DECIMAL(15,2) NOT NULL,
    saldo_contable          FOR SLDCTB DECIMAL(15,2) NOT NULL,
    estatus_cuenta          FOR STCCTA CHAR(1) NOT NULL,
    fecha_apertura          FOR FECAPE DATE NOT NULL,
    fecha_ultimo_movimiento FOR FECULMOV DATE,
    indicador_bloqueada     FOR INDBLQ CHAR(1) NOT NULL DEFAULT 'N',
    PRIMARY KEY (cuenta_numero)
);

-- OBLIGATORIO para CADA campo
COMMENT ON COLUMN COREACTADEP.cuenta_numero IS 
    'Número único identificador de la cuenta a nivel regional. Generado secuencialmente por país';

COMMENT ON COLUMN COREACTADEP.tipo_cuenta IS 
    'Tipo de cuenta según catálogo de productos: AH=Ahorro, CC=Cuenta Corriente, DP=Depósito a Plazo, FI=Fideicomiso';

COMMENT ON COLUMN COREACTADEP.moneda_codigo IS 
    'Código ISO 4217 de la moneda en que opera la cuenta (USD, CRC, GTQ, SVC, PAB, NIO)';

COMMENT ON COLUMN COREACTADEP.saldo_disponible IS 
    'Saldo actual disponible para retiros y transferencias. Calculado como: saldo_contable menos bloqueos y retenciones activas';

COMMENT ON COLUMN COREACTADEP.saldo_contable IS 
    'Saldo contable de la cuenta incluyendo todos los movimientos procesados. Base para cálculo de intereses y reportería';

COMMENT ON COLUMN COREACTADEP.estatus_cuenta IS 
    'Estatus actual de la cuenta: A=Activa, I=Inactiva, C=Cerrada, B=Bloqueada, S=Suspendida';

COMMENT ON COLUMN CUENTAS.fecha_apertura IS 
    'Fecha en que se abrió la cuenta y fue activada para operar';

COMMENT ON COLUMN CUENTAS.fecha_ultimo_movimiento IS 
    'Fecha del último movimiento (débito o crédito) registrado en la cuenta. NULL para cuentas sin movimientos';

COMMENT ON COLUMN CUENTAS.indicador_bloqueada IS 
    'Indica si la cuenta tiene bloqueo administrativo o legal vigente: S=Sí bloqueada, N=No bloqueada. Bloqueo impide transacciones';
```

### Características de Buena Metadata de Campo

✓ **Descripción debe incluir:**

1. **Qué representa**: Propósito del campo
2. **Valores posibles**: Para campos con lista de valores
3. **Formato/Rango**: Para códigos o números
4. **Cálculo**: Si es derivado o calculado (en vistas)
5. **NULL handling**: Qué significa NULL si se permite
6. **Relaciones**: Si referencia otra tabla

**Patrones recomendados:**

```sql
-- Patrón 1: Campos con check constraint
COMMENT ON COLUMN tabla.campo_estatus IS 
    'Estatus del registro. Valores: A=Activo, I=Inactivo, C=Cancelado';

-- Patrón 2: Campos con FK
COMMENT ON COLUMN tabla.moneda_codigo IS 
    'Código de moneda ISO 4217. Referencia a tabla CAT_MONEDAS';

-- Patrón 3: Campos con formato específico
COMMENT ON COLUMN tabla.codigo_swift IS 
    'Código SWIFT/BIC formato estándar 8 u 11 caracteres';

-- Patrón 4: Campos calculados (en vistas)
COMMENT ON COLUMN vista.dias_atraso IS 
    'Días de atraso en el pago. Calculado como: CURRENT DATE - fecha_vencimiento';

-- Patrón 5: Campos que permiten NULL
COMMENT ON COLUMN tabla.fecha_cierre IS 
    'Fecha de cierre de la cuenta. NULL indica que la cuenta está abierta';
```

### NO Descripciones Genéricas

❌ **INSUFICIENTE:**
```sql
COMMENT ON COLUMN tabla.flg IS 'Flag';
COMMENT ON COLUMN tabla.ind IS 'Indicador';
COMMENT ON COLUMN tabla.cod IS 'Código';
COMMENT ON COLUMN tabla.fec IS 'Fecha';
COMMENT ON COLUMN tabla.campo1 IS 'Campo';
```

✓ **SUFICIENTE:**
```sql
COMMENT ON COLUMN tabla.indicador_requiere_aprobacion IS 
    'Indica si la transacción requiere aprobación de supervisor antes de procesarse: S=Requiere aprobación, N=No requiere';

COMMENT ON COLUMN tabla.codigo_autorizacion IS 
    'Código alfanumérico de 6 dígitos generado por el emisor al autorizar la transacción';

COMMENT ON COLUMN tabla.fecha_vencimiento_pago IS 
    'Fecha límite para realizar el pago sin generar mora ni intereses adicionales';
```

---

## 3. Metadata de Índices

### Obligatorio: Descripción de Índices

✓ **Índices funcionales DEBEN tener COMMENT:**

```sql
-- Índice funcional
CREATE INDEX IXF_TRANSACCIONES_CUENTA_FECHA
    ON TRANSACCIONES(cuenta_numero, fecha_transaccion DESC);

-- OBLIGATORIO para índices funcionales
COMMENT ON INDEX IXF_TRANSACCIONES_CUENTA_FECHA IS 
    'Índice utilizado por pantalla CONS_TRANS_CTA (consulta de transacciones por cuenta). Ordenamiento descendente por fecha para mostrar transacciones más recientes primero. Requerido por módulo de consultas web y móvil';
```

✓ **Índices de performance DEBEN documentar justificación:**

```sql
-- Índice de performance
CREATE INDEX IXP_PRESTAMOS_MORA_2026_RFC789
    ON PRESTAMOS(fecha_vencimiento, estatus_mora, monto_vencido);

-- OBLIGATORIO documentar mejora
COMMENT ON INDEX IXP_PRESTAMOS_MORA_2026_RFC789 IS 
    'Índice de performance para reporte diario de cartera en mora. Optimiza query de 2.5 minutos a 8 segundos. Creado en RFC-789-2026. Soporta reporte RPT_MORA_DIARIO ejecutado a las 06:00 AM';
```

---

## 4. Metadata de Objetos Programáticos

### Stored Procedures

✓ **Documentar propósito, parámetros y comportamiento:**

```sql
CREATE PROCEDURE sp_cerrar_cuenta (
    IN p_cuenta_numero      BIGINT,
    IN p_motivo_cierre      CHAR(2),
    IN p_usuario            VARCHAR(30),
    OUT p_resultado         CHAR(1),
    OUT p_mensaje           VARCHAR(200)
)
LANGUAGE SQL
BEGIN
    -- Lógica del procedimiento
    ...
END;

-- METADATA OBLIGATORIA
COMMENT ON PROCEDURE sp_cerrar_cuenta IS 
    'Proceso de cierre formal de cuenta. Valida que no existan saldos pendientes, retenciones o bloqueos. Registra motivo de cierre y genera movimiento contable de liquidación. Actualiza estatus a C=Cerrada.

Parámetros:
- p_cuenta_numero: Número de cuenta a cerrar
- p_motivo_cierre: Código de motivo (ver CAT_MOTIVOS_CIERRE)
- p_usuario: Usuario que solicita el cierre
- p_resultado: S=Éxito, E=Error, W=Warning
- p_mensaje: Descripción del resultado

Excepciones:
- Error si saldo <> 0
- Error si tiene bloqueos activos
- Error si tiene cheques pendientes

Usado por: Módulo de administración de cuentas web y sucursales';
```

### Functions

```sql
CREATE FUNCTION fn_calcular_dias_mora (
    p_fecha_vencimiento DATE,
    p_fecha_referencia  DATE
)
RETURNS INTEGER
LANGUAGE SQL
DETERMINISTIC
BEGIN
    RETURN CASE 
        WHEN p_fecha_referencia > p_fecha_vencimiento 
        THEN DAYS(p_fecha_referencia) - DAYS(p_fecha_vencimiento)
        ELSE 0
    END;
END;

COMMENT ON FUNCTION fn_calcular_dias_mora IS 
    'Calcula días de mora transcurridos desde fecha de vencimiento hasta fecha de referencia. Retorna 0 si no hay mora. Usado en cálculo de intereses moratorios y clasificación de cartera.

Parámetros:
- p_fecha_vencimiento: Fecha límite de pago
- p_fecha_referencia: Fecha actual o de análisis

Retorna: Cantidad de días en mora (0 si no hay mora)

Ejemplo: fn_calcular_dias_mora(''2026-01-01'', ''2026-01-15'') = 14';
```

### Triggers

```sql
CREATE TRIGGER trg_cuentas_audit
AFTER UPDATE ON CUENTAS
REFERENCING NEW AS N OLD AS O
FOR EACH ROW
BEGIN
    -- Lógica de auditoría
    ...
END;

COMMENT ON TRIGGER trg_cuentas_audit IS 
    'Trigger de auditoría que registra cambios en campos críticos de cuentas (saldo, estatus, bloqueos). Inserta registro en CUENTAS_AUDIT con usuario, fecha/hora y valores anterior/nuevo. Ejecuta después de UPDATE.

Campos auditados:
- saldo_disponible
- saldo_contable
- estatus_cuenta
- indicador_bloqueada

Tabla destino: CUENTAS_AUDIT';
```

---

## 5. Documentación en Código SQL

### Estructura de Script SQL

```sql
---
-- TRANSACCIONES_DIGITAL: Transacciones de canales digitales
--
-- Almacenar todas las transacciones originadas en canales digitales
-- (móvil, web, API) incluyendo transferencias, pagos de servicios,
-- recargas y consultas con movimiento contable.
--
-- Alcance:
--   - Regional (todos los países)
--   - Multi-moneda
--   - Multi-banco
--
-- Dependencias:
--   - CUENTAS (FK)
--   - CAT_TIPOS_TRANSACCION (FK)
--   - CAT_MONEDAS (FK)
--
-- Housekeeping:
--   - Retención en línea: 90 días
--   - Archivo histórico: TRANSACCIONES_DIGITAL_HIST
--   - Proceso: JOB_HOUSEKEEP_TRANSDIG (mensual)
--
-- @author Equipo Digital Banking
-- @date 2026-03-03
-- @project PASE-2026-089
-- @version v1.0
---

CREATE TABLE CRMATRXDGT (
    -- IDENTIFICACIÓN
    transaccion_id          FOR IDTRX BIGINT NOT NULL,
    pais_codigo             FOR CODPAI CHAR(2) NOT NULL,
    
    -- ORIGEN
    cuenta_origen           FOR CTAORG BIGINT NOT NULL,
    canal_origen            FOR CNLORG CHAR(3) NOT NULL,  -- MOB, WEB, API
    
    -- DESTINO
    cuenta_destino          FOR CTADST BIGINT,
    beneficiario_nombre     FOR NOMBEN VARCHAR(100),
    
    -- DATOS TRANSACCIONALES
    tipo_transaccion        FOR TIPTRX CHAR(3) NOT NULL,
    moneda_codigo           FOR CODMON CHAR(3) NOT NULL,
    monto                   FOR MONTO DECIMAL(15,2) NOT NULL,
    
    -- FECHAS
    fecha_solicitud         FOR FECSOL TIMESTAMP NOT NULL,
    fecha_proceso           FOR FECPRO TIMESTAMP,
    fecha_aplicacion        FOR FECAPL DATE,
    
    -- CONTROL
    estatus                 FOR ESTATUS CHAR(2) NOT NULL,
    codigo_autorizacion     FOR CODAUT VARCHAR(20),
    
    -- AUDITORÍA
    usuario_solicita        FOR USRSOL VARCHAR(30) NOT NULL,
    ip_origen               FOR IPORG VARCHAR(45),
    dispositivo_id          FOR IDDSP VARCHAR(100),
    
    -- LLAVE PRIMARIA
    CONSTRAINT pk_transacciones_digital 
        PRIMARY KEY (transaccion_id)
);

-- Metadata de tabla y campos
COMMENT ON TABLE CRMATRXDGT IS 
    'Transacciones procesadas por canales digitales (móvil, web, API). Registro regional de transferencias, pagos de servicios, recargas y consultas con movimiento';

COMMENT ON COLUMN PROD_DATA.TRANSACCIONES_DIGITAL.transaccion_id IS 
    'Identificador único regional de la transacción. Generado por sequence SEQ_TRANS_DIGITAL';

COMMENT ON COLUMN PROD_DATA.TRANSACCIONES_DIGITAL.canal_origen IS 
    'Canal digital de origen: MOB=Móvil, WEB=Banca Web, API=API Externa';

-- ... más comments para cada campo

-- Constraints (check, foreign keys)
-- Check constraints
ALTER TABLE PROD_DATA.TRANSACCIONES_DIGITAL
    ADD CONSTRAINT ck_transdig_canal
    CHECK (canal_origen IN ('MOB', 'WEB', 'API'));

ALTER TABLE PROD_DATA.TRANSACCIONES_DIGITAL
    ADD CONSTRAINT ck_transdig_estatus
    CHECK (estatus IN ('PE', 'PR', 'AP', 'RE', 'CA'));

ALTER TABLE PROD_DATA.TRANSACCIONES_DIGITAL
    ADD CONSTRAINT ck_transdig_monto
    CHECK (monto > 0);

-- Foreign keys
ALTER TABLE PROD_DATA.TRANSACCIONES_DIGITAL
    ADD CONSTRAINT fk_transdig_cuenta_origen
    FOREIGN KEY (cuenta_origen)
    REFERENCES PROD_DATA.CUENTAS(cuenta_numero)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE PROD_DATA.TRANSACCIONES_DIGITAL
    ADD CONSTRAINT fk_transdig_moneda
    FOREIGN KEY (moneda_codigo)
    REFERENCES CORE.CAT_MONEDAS(moneda_codigo)
    ON DELETE RESTRICT ON UPDATE RESTRICT;

-- Índices para optimización de consultas
-- Índice funcional para consultas por cuenta
CREATE INDEX PROD_DATA.IXF_TRANSDIG_CUENTA_FECHA
    ON PROD_DATA.TRANSACCIONES_DIGITAL(cuenta_origen, fecha_solicitud DESC);

COMMENT ON INDEX PROD_DATA.IXF_TRANSDIG_CUENTA_FECHA IS 
    'Índice funcional para pantalla de consulta de transacciones digitales por cuenta. Usado por módulos móvil y web';

-- Grants de seguridad (si aplica)
GRANT SELECT ON PROD_DATA.TRANSACCIONES_DIGITAL TO ROLE_CONSULTA;
GRANT SELECT, INSERT, UPDATE ON PROD_DATA.TRANSACCIONES_DIGITAL TO ROLE_APLICATIVO;
```

---

## Template Rápido de Documentación

### Para Tablas

```sql
-- Crear tabla
CREATE TABLE nombre_tabla (...);

-- Metadata de tabla
COMMENT ON TABLE nombre_tabla IS 
    '[Propósito]. [Alcance]. [Contexto de uso]. [Retención si aplica]';

-- Metadata de cada campo
COMMENT ON COLUMN nombre_tabla.campo1 IS 
    '[Descripción]. [Valores posibles si aplica]. [NULL handling si aplica]';

-- Repetir para CADA campo
```

### Para Stored Procedures

```sql
CREATE PROCEDURE nombre_sp (...) ...;

COMMENT ON PROCEDURE nombre_sp IS 
    '[Descripción general].
    
Parámetros:
- param1: [descripción]
- param2: [descripción]
- ...

[Comportamiento especial].
[Excepciones].
[Usado por: aplicativos]';
```

### Para Índices

```sql
CREATE INDEX nombre_indice ON tabla (...);

COMMENT ON INDEX nombre_indice IS 
    '[Funcional: usado por módulo X] o [Performance: optimiza query Y de N seg a M seg]. [Contexto adicional]';
```

---

## Checklist de Documentación

- [ ] Tabla tiene COMMENT ON TABLE
- [ ] TODOS los campos tienen COMMENT ON COLUMN
- [ ] Vistas tienen COMMENT ON VIEW
- [ ] Índices funcionales tienen COMMENT ON INDEX
- [ ] Índices de performance documentan mejora cuantificada
- [ ] Stored Procedures con COMMENT incluyendo parámetros
- [ ] Functions con COMMENT incluyendo ejemplo de uso
- [ ] Triggers con COMMENT explicando comportamiento
- [ ] Sequences/Aliases documentados (si aplica)
- [ ] Descripciones NO técnicas (comprensibles para negocio)
- [ ] Descripciones suficientemente significativas
- [ ] No descripciones genéricas ("Flag", "Campo", etc.)
- [ ] Valores posibles documentados para campos con listas
- [ ] NULL handling explicado cuando se permite NULL
- [ ] Script SQL con comentarios de secciones
- [ ] Dependencias identificadas en documentación
- [ ] Housekeeping documentado para tablas nuevas

---

**Fuente**: Sección 9 - Check List de Revisión de Base de Datos BAC Credomatic
