# Modelo Físico - Estructura SQL y Definiciones

Esta referencia cubre todos los aspectos técnicos de la definición física de objetos de base de datos usando SQL puro.

## Tabla de Contenido

1. [Principios Fundamentales](#1-principios-fundamentales)
2. [Tipos de Datos](#2-tipos-de-datos)
3. [Constraints y Reglas](#3-constraints-y-reglas)
4. [Campos Especiales](#4-campos-especiales)
5. [Vistas y Objetos Dependientes](#5-vistas-y-objetos-dependientes)
6. [Mejores Prácticas SQL](#6-mejores-prácticas-sql)

---

## 1. Principios Fundamentales

### SQL Puro Exclusivamente

✓ **USAR:**
- SQL estándar DB2
- CREATE TABLE, ALTER TABLE
- Constraints explícitos

❌ **NO USAR:**
- Archivos DDS
- Archivos S/36
- Archivos planos
- Generación automática de nombres por el motor

### Nombres Cortos y Largos

Si el gestor permite ambos:
```sql
CREATE TABLE PROD_DATA.TRANSACCIONES (
    -- Nombre corto: TRNID, Nombre largo: transaccion_id
    transaccion_id BIGINT NOT NULL
);

-- Mantener consistencia entre ambos sistemas de nomenclatura
```

### Descripciones Obligatorias

❌ **Insuficiente:**
```sql
COMMENT ON COLUMN tabla.campo IS 'Flag';
COMMENT ON COLUMN tabla.estado IS 'Bandera';
```

✓ **Correcto:**
```sql
COMMENT ON COLUMN transacciones.estatus_autorizacion 
    IS 'Estatus de autorización de la transacción. Valores posibles: APROBADA, RECHAZADA, PENDIENTE, CANCELADA';

COMMENT ON COLUMN cuentas.indicador_activa
    IS 'Indica si la cuenta está actualmente activa y disponible para transacciones (S=Sí, N=No)';
```

---

## 2. Tipos de Datos

### Campos de Fecha y Hora

✓ **Usar tipos nativos apropiados:**

```sql
-- FECHAS COMPLETAS
fecha_apertura      DATE NOT NULL,
fecha_nacimiento    DATE,

-- FECHA Y HORA
fecha_hora_transaccion  TIMESTAMP NOT NULL DEFAULT CURRENT TIMESTAMP,

-- SOLO HORA
hora_procesamiento  TIME
```

❌ **INCORRECTO - Campos separados:**
```sql
-- NO HACER ESTO
anio_apertura   INTEGER,
mes_apertura    INTEGER,
dia_apertura    INTEGER
```

### Campos Monetarios

**Regla:** Usar espacio suficiente para escalabilidad

```sql
-- MÍNIMOS RECOMENDADOS
monto_transaccion       DECIMAL(15,2) NOT NULL,  -- Hasta 999,999,999,999.99
saldo_disponible        DECIMAL(15,2) NOT NULL,
limite_credito          DECIMAL(13,2) NOT NULL,  -- Hasta 9,999,999,999.99
comision                DECIMAL(11,2) NOT NULL,  -- Hasta 999,999,999.99

-- Para montos grandes (transferencias internacionales, etc.)
monto_swift            DECIMAL(18,2) NOT NULL
```

### Campos de Porcentajes y Tasas

```sql
-- PORCENTAJES (0-100%)
porcentaje_comision     DECIMAL(5,2) NOT NULL,   -- 0.00 a 999.99%
tasa_impuesto          DECIMAL(4,2) NOT NULL,   -- 0.00 a 99.99%

-- TASAS CON MAYOR PRECISIÓN
tasa_interes           DECIMAL(7,4) NOT NULL,   -- 0.0000 a 999.9999%
factor_conversion      DECIMAL(9,6) NOT NULL    -- Mayor precisión
```

### Campos Alfanuméricos

✓ **Consistencia con campos existentes:**

```sql
-- CIF (Customer Information File)
cif_tarjetas    CHAR(12) NOT NULL,     -- Alfanumérico para Tarjetas
cif_banco       INTEGER NOT NULL,       -- Numérico (9 dígitos) para Banco

-- Códigos estándar
pais_codigo     CHAR(2) NOT NULL,       -- ISO 3166-1 alpha-2
moneda_codigo   CHAR(3) NOT NULL,       -- ISO 4217
banco_codigo    CHAR(3) NOT NULL
```

⚠ **VARCHAR para campos largos:**
```sql
-- Para campos > 50 caracteres, considerar VARCHAR
descripcion_transaccion     VARCHAR(200),
comentarios                 VARCHAR(500),
direccion_completa          VARCHAR(150)

-- Campos cortos: usar CHAR fijo
codigo_sucursal    CHAR(4) NOT NULL,
tipo_documento     CHAR(3) NOT NULL
```

---

## 3. Constraints y Reglas

### Reglas de Integridad Referencial

✓ **SIEMPRE usar RESTRICT:**

```sql
-- CORRECTO
ALTER TABLE TRANSACCIONES
    ADD CONSTRAINT fk_transacciones_cuentas
    FOREIGN KEY (cuenta_numero)
    REFERENCES CUENTAS(cuenta_numero)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;
```

❌ **NO usar CASCADE, SET NULL, etc.:**
```sql
-- INCORRECTO
ON DELETE CASCADE    -- NO permitido
ON UPDATE SET NULL   -- NO permitido
```

### Llaves Foráneas en Llaves Primarias

⚠ **Regla crítica:** Si una FK es parte de la PK, usar TODOS los campos de la FK en la PK

```sql
-- CORRECTO
CREATE TABLE MOVIMIENTOS (
    pais_codigo         CHAR(2) NOT NULL,
    cuenta_numero       BIGINT NOT NULL,     -- FK completa
    movimiento_id       BIGINT NOT NULL,
    
    CONSTRAINT pk_movimientos 
        PRIMARY KEY (pais_codigo, cuenta_numero, movimiento_id)
);

ALTER TABLE MOVIMIENTOS
    ADD CONSTRAINT fk_movimientos_cuentas
    FOREIGN KEY (pais_codigo, cuenta_numero)  -- FK completa
    REFERENCES CUENTAS(pais_codigo, cuenta_numero)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;
```

❌ **INCORRECTO - FK parcial en PK:**
```sql
-- Puede generar comportamientos inesperados
PRIMARY KEY (pais_codigo, movimiento_id)  -- Falta cuenta_numero
```

### Constraints No Contradictorios

❌ **NO crear constraints que se contradigan:**

```sql
-- INCORRECTO
ALTER TABLE PRODUCTOS
    ADD CONSTRAINT ck_precio_minimo CHECK (precio > 100),
    ADD CONSTRAINT ck_precio_maximo CHECK (precio < 50);  -- Imposible!
```

### Nombres Explícitos de Constraints

✓ **Definir nombres manualmente:**

```sql
CONSTRAINT pk_transacciones PRIMARY KEY (...),
CONSTRAINT fk_transacciones_cuentas FOREIGN KEY (...),
CONSTRAINT ck_transacciones_estatus CHECK (...),
CONSTRAINT uq_transacciones_referencia UNIQUE (...)
```

❌ **NO dejar que el motor genere nombres automáticos**

---

## 4. Campos Especiales

### Campos de Auditoría

Para **tablas críticas**, incluir:

```sql
CREATE TABLE CUENTAS (
    -- Campos de negocio
    cuenta_numero       BIGINT NOT NULL,
    -- ... más campos ...
    
    -- AUDITORÍA
    usuario_inserta     VARCHAR(30) NOT NULL,
    fecha_insercion     TIMESTAMP NOT NULL DEFAULT CURRENT TIMESTAMP,
    usuario_modifica    VARCHAR(30),
    fecha_modificacion  TIMESTAMP,
    
    CONSTRAINT pk_cuentas PRIMARY KEY (cuenta_numero)
);
```

### Tablas de Bitácoras

Para **tablas críticas**, considerar tabla histórica:

```sql
CREATE TABLE CUENTAS_HIST (
    -- Todos los campos de CUENTAS
    cuenta_numero       BIGINT NOT NULL,
    -- ... campos iguales a CUENTAS ...
    
    -- CAMPOS ADICIONALES DE HISTÓRICO
    accion              CHAR(1) NOT NULL,    -- I=Insert, U=Update, D=Delete
    usuario_accion      VARCHAR(30) NOT NULL,
    fecha_hora_accion   TIMESTAMP NOT NULL DEFAULT CURRENT TIMESTAMP,
    
    CONSTRAINT pk_cuentas_hist 
        PRIMARY KEY (cuenta_numero, fecha_hora_accion)
);

-- Trigger para alimentar histórico (ejemplo conceptual)
CREATE TRIGGER trg_cuentas_hist
AFTER UPDATE ON CUENTAS
-- lógica de inserción en CUENTAS_HIST
```

### NOT NULL por Defecto

✓ **Regla:** Todos los campos NOT NULL salvo justificación

```sql
-- PREFERIR
nombre              VARCHAR(100) NOT NULL,
estatus             CHAR(1) NOT NULL DEFAULT 'A',
fecha_creacion      DATE NOT NULL DEFAULT CURRENT DATE,

-- Solo permitir NULL con justificación válida
comentario_opcional VARCHAR(500),  -- Justificación: no siempre hay comentario
fecha_cierre        DATE            -- Justificación: NULL = cuenta abierta
```

### Valores DEFAULT

✓ **Usar cuando sea apropiado:**

```sql
estatus             CHAR(1) NOT NULL DEFAULT 'A',
indicador_activo    CHAR(1) NOT NULL DEFAULT 'S',
contador            INTEGER NOT NULL DEFAULT 0,
fecha_registro      TIMESTAMP NOT NULL DEFAULT CURRENT TIMESTAMP
```

⚠ **DEFAULT debe estar en check constraint:**

```sql
estatus CHAR(1) NOT NULL DEFAULT 'A',  -- DEFAULT es 'A'
CONSTRAINT ck_estatus CHECK (estatus IN ('A', 'I', 'P'))  -- 'A' debe estar aquí
```

---

## 5. Vistas y Objetos Dependientes

### Vistas Lógicas

⚠ **Si aplica en el gestor de BD:**

Cuando se modifica una tabla con vistas lógicas:
```sql
-- 1. Tabla original
CREATE TABLE CUENTAS_V1 (...);

-- 2. Agregar campo nuevo
ALTER TABLE CUENTAS_V1 ADD COLUMN saldo_bloqueado DECIMAL(15,2);

-- 3. CREAR NUEVA VISTA LÓGICA
CREATE VIEW CUENTAS AS
SELECT 
    cuenta_numero,
    -- ... campos existentes ...
    saldo_bloqueado  -- Nuevo campo
FROM CUENTAS_V1;
```

### Objetos en Misma Biblioteca

✓ **Regla:** Objetos dependientes en biblioteca de tabla principal

```sql
-- Tabla en PROD_DATA
CREATE TABLE PROD_DATA.TRANSACCIONES (...);

-- Vista dependiente: MISMA biblioteca
CREATE VIEW PROD_DATA.VW_TRANSACCIONES_DIA AS
SELECT * FROM PROD_DATA.TRANSACCIONES
WHERE fecha = CURRENT DATE;

-- Índice: MISMA biblioteca
CREATE INDEX PROD_DATA.IX_TRANSACCIONES_FECHA
    ON PROD_DATA.TRANSACCIONES(fecha);

-- Trigger: MISMA biblioteca
CREATE TRIGGER PROD_DATA.TRG_TRANSACCIONES_AUDIT
-- ...
```

### Presentar Campos Completos

En modelos y documentación:
- Mostrar TODOS los campos de tablas a modificar
- Identificar llaves primarias gráficamente
- Identificar llaves foráneas explícitamente
- Listar constraints
- Indicar vistas, lógicos y objetos dependientes impactados

---

## 6. Mejores Prácticas SQL

### SELECT Explícito

❌ **NUNCA usar SELECT \*:**

```sql
-- INCORRECTO
SELECT * FROM TRANSACCIONES;

-- EN VISTAS
CREATE VIEW vw_resumen AS
SELECT * FROM TRANSACCIONES;  -- NO!
```

✓ **SIEMPRE nombrar campos explícitamente:**

```sql
-- CORRECTO
SELECT 
    transaccion_id,
    fecha,
    monto,
    estatus
FROM TRANSACCIONES;

-- EN VISTAS
CREATE VIEW vw_transacciones_activas AS
SELECT 
    transaccion_id,
    cuenta_numero,
    fecha,
    monto,
    descripcion
FROM TRANSACCIONES
WHERE estatus = 'ACTIVO';
```

### Llaves Primarias Simples

⚠ **Evitar campos complejos en PK:**

❌ **NO recomendado en PK:**
```sql
-- Impacta rendimiento negativamente
PRIMARY KEY (descripcion_larga),           -- VARCHAR(200)
PRIMARY KEY (nombre_completo, direccion),  -- Campos largos
PRIMARY KEY (monto_decimal)                -- DECIMAL
```

✓ **Preferir en PK:**
```sql
PRIMARY KEY (id),                          -- INTEGER, BIGINT
PRIMARY KEY (codigo),                      -- CHAR(10)
PRIMARY KEY (pais, banco, id)              -- Campos cortos
```

### Identity y Sequences

✓ **Permitido con validación:**

```sql
-- IDENTITY
CREATE TABLE TRANSACCIONES (
    transaccion_id BIGINT NOT NULL 
        GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
    -- más campos...
    PRIMARY KEY (transaccion_id)
);

-- SEQUENCE
CREATE SEQUENCE seq_transacciones
    START WITH 1
    INCREMENT BY 1
    NO CYCLE;
```

⚠ **Validar antes:**
- Impacto en replicación
- Uso en servidores de contingencia
- Sincronización entre ambientes

### Journaling

Para tablas con:
- Integridad referencial
- Control de compromiso
- Replicación de datos

**Coordinar con DBA** para registrar por Journal:
```sql
-- Comando IBM i (ejemplo)
CHGJRN OBJ(BIBLIOTECA/TABLA) JRN(JOURNAL/DIARIO)
```

---

## Diseños a Evitar

### Diseños Horizontales

❌ **NO crear "columnas virtuales" mediante filas:**

```sql
-- INCORRECTO - Diseño horizontal
CREATE TABLE PARAMETROS_HORIZONTAL (
    entidad_id      INTEGER,
    parametro_nombre VARCHAR(50),  -- Actúa como "columna"
    parametro_valor  VARCHAR(100)  -- Valor genérico
);

-- Problemas:
-- - Sin validación de tipos
-- - Sin constraints significativos
-- - Difícil de consultar
-- - Problemas de performance
```

✓ **CORRECTO - Diseño vertical (normalizado):**

```sql
CREATE TABLE CONFIGURACION_ENTIDAD (
    entidad_id          INTEGER NOT NULL,
    dias_gracia         INTEGER NOT NULL,
    tasa_interes        DECIMAL(7,4) NOT NULL,
    comision_minima     DECIMAL(11,2) NOT NULL,
    indicador_activo    CHAR(1) NOT NULL,
    
    PRIMARY KEY (entidad_id),
    CONSTRAINT ck_indicador CHECK (indicador_activo IN ('S', 'N'))
);
```

### Archivos Temporales

✓ **Usar tablas temporales SQL:**

```sql
-- Para variables temporales, reportes
DECLARE GLOBAL TEMPORARY TABLE temp_calculos AS (
    SELECT ...
) WITH DATA
ON COMMIT PRESERVE ROWS;

-- En biblioteca temporal (QTEMP en IBM i)
CREATE TABLE QTEMP.TEMP_PROCESO AS (
    SELECT ...
) WITH DATA;
```

❌ **NO crear tablas permanentes como "temporales"**

---

## Ejemplo Completo de Tabla

```sql
---
-- TRANSACCIONES_TARJETA: Transacciones de tarjetas de crédito y débito
--
-- Almacenar todas las transacciones realizadas con tarjetas de crédito
-- y débito en la región. Incluye información de autorización, montos,
-- conversiones de moneda, comisiones y auditoría completa.
--
-- @author Equipo Tarjetas
-- @date 2026-02-15
-- @project CORE-TARJETAS
-- @version v1.0
---

CREATE TABLE PROD_DATA.TRANSACCIONES_TARJETA (
    -- LLAVES
    pais_codigo             FOR CODPAI CHAR(2) NOT NULL,
    banco_codigo            FOR CODBCO CHAR(3) NOT NULL,
    transaccion_id          FOR IDTRX BIGINT NOT NULL,
    
    -- IDENTIFICACIÓN
    tarjeta_numero          FOR NUMTDC CHAR(16) NOT NULL,
    comercio_codigo         FOR CODCOM VARCHAR(15) NOT NULL,
    
    -- DATOS TRANSACCIONALES
    fecha_transaccion       FOR FECTRX DATE NOT NULL,
    hora_transaccion        FOR HORATRX TIME NOT NULL,
    fecha_hora_proceso      FOR FHPROC TIMESTAMP NOT NULL DEFAULT CURRENT TIMESTAMP,
    
    -- MONTOS
    moneda_transaccion      FOR MONTRX CHAR(3) NOT NULL,
    monto_transaccion       FOR MTOTRX DECIMAL(15,2) NOT NULL,
    monto_moneda_local      FOR MTOLOCL DECIMAL(15,2) NOT NULL,
    tasa_cambio             FOR TASCMB DECIMAL(9,6),
    comision                FOR COMISN DECIMAL(11,2) NOT NULL DEFAULT 0.00,
    
    -- ESTATUS Y CONTROL
    tipo_transaccion        FOR TIPTRX CHAR(2) NOT NULL,  -- CO=Compra, RE=Retiro, etc.
    estatus_autorizacion    FOR STCAUT CHAR(1) NOT NULL,  -- A=Aprobada, R=Rechazada, P=Pendiente
    codigo_autorizacion     FOR CODAUT VARCHAR(10),
    
    -- AUDITORÍA
    usuario_proceso         FOR USRPRO VARCHAR(30) NOT NULL,
    fecha_creacion          FOR FECCRE TIMESTAMP NOT NULL DEFAULT CURRENT TIMESTAMP,
    usuario_modificacion    FOR USRMOD VARCHAR(30),
    fecha_modificacion      FOR FECMOD TIMESTAMP,
    
    -- LLAVE PRIMARIA
    CONSTRAINT pk_transacciones_tarjeta 
        PRIMARY KEY (pais_codigo, banco_codigo, transaccion_id)
);

-- COMMENTS (Metadata)
COMMENT ON TABLE PROD_DATA.TRANSACCIONES_TARJETA 
    IS 'Registro de todas las transacciones con tarjetas de crédito y débito realizadas en la región, incluyendo compras, retiros, y reversos';

COMMENT ON COLUMN PROD_DATA.TRANSACCIONES_TARJETA.transaccion_id
    IS 'Identificador único secuencial de la transacción dentro del país y banco';

COMMENT ON COLUMN PROD_DATA.TRANSACCIONES_TARJETA.tipo_transaccion
    IS 'Código del tipo de transacción: CO=Compra, RE=Retiro, AJ=Ajuste, RV=Reverso';

-- CHECK CONSTRAINTS
ALTER TABLE PROD_DATA.TRANSACCIONES_TARJETA
    ADD CONSTRAINT ck_transacciones_tipo
    CHECK (tipo_transaccion IN ('CO', 'RE', 'AJ', 'RV', 'PA'));

ALTER TABLE PROD_DATA.TRANSACCIONES_TARJETA
    ADD CONSTRAINT ck_transacciones_estatus
    CHECK (estatus_autorizacion IN ('A', 'R', 'P', 'C'));

ALTER TABLE PROD_DATA.TRANSACCIONES_TARJETA
    ADD CONSTRAINT ck_transacciones_monto
    CHECK (monto_transaccion >= 0);

-- FOREIGN KEYS
ALTER TABLE PROD_DATA.TRANSACCIONES_TARJETA
    ADD CONSTRAINT fk_transacciones_tarjetas
    FOREIGN KEY (tarjeta_numero)
    REFERENCES PROD_DATA.TARJETAS(tarjeta_numero)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;

ALTER TABLE PROD_DATA.TRANSACCIONES_TARJETA
    ADD CONSTRAINT fk_transacciones_monedas
    FOREIGN KEY (moneda_transaccion)
    REFERENCES CORE.MONEDAS(moneda_codigo)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;

-- ÍNDICES (si son necesarios para funcionalidad)
CREATE INDEX PROD_DATA.IX_TRANSACCIONES_TARJETA_FECHA
    ON PROD_DATA.TRANSACCIONES_TARJETA(fecha_transaccion, banco_codigo);

CREATE INDEX PROD_DATA.IX_TRANSACCIONES_TARJETA_NUM
    ON PROD_DATA.TRANSACCIONES_TARJETA(tarjeta_numero, fecha_transaccion);
```

---

## Checklist de Modelo Físico

- [ ] Definición únicamente en SQL puro (no DDS, no S/36)
- [ ] Nombres cortos y largos definidos y consistentes
- [ ] Descripciones significativas en TODOS los objetos y campos
- [ ] Cumple política de nomenclatura corporativa
- [ ] Tipos de datos apropiados (DATE, TIMESTAMP, DECIMAL correcto)
- [ ] Campos monetarios mínimo DECIMAL(11,2)
- [ ] Campos porcentajes mínimo DECIMAL(4,2)
- [ ] Consistencia con campos existentes del core
- [ ] Integridad referencial con ON DELETE/UPDATE RESTRICT
- [ ] No campos separados para fechas (año, mes, día)
- [ ] NOT NULL en todos los campos (salvo justificación)
- [ ] DEFAULT values definidos donde aplique
- [ ] Campos de auditoría en tablas críticas
- [ ] Tabla de bitácoras considerada para tablas críticas
- [ ] Vistas lógicas creadas para modificaciones (si aplica)
- [ ] SELECT explícito (no SELECT *)
- [ ] Objetos dependientes en misma biblioteca
- [ ] Journaling evaluado
- [ ] Identity/Sequence validado para replicación
- [ ] No diseños horizontales
- [ ] Llaves primarias con campos simples
- [ ] Nombres de constraints definidos explícitamente

---

**Fuente**: Sección 2 - Check List de Revisión de Base de Datos BAC Credomatic
