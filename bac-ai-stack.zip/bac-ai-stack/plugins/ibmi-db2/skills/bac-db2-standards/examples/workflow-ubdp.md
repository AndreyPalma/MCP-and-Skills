# Workflow UBDP — Ejemplo Completo

Ejemplo del workflow obligatorio de validación de nomenclatura para el objeto
`BRIAMSTTRN` (Maestro de Transacciones, sistema Bridger).

## Paso 1 — Buscar AVP

```sql
-- Buscar AVP por nombre de aplicación
CALL LIBMHV.UBDP_CONSULTA_AVP('', 'bridger');
```

**Resultado típico:**
```
BBRI | Bridger Banca           | PDE
CBRI | Objetos interfaz Bridger| PDE
CENB | Envio Bridger           | PDE
TBRI | Bridger Tarjetas        | PDE
```

**Selección:** `BBRI` (Bridger Banca — aplica para este requerimiento)

**Regla de truncamiento AVP (4 → 3 chars):**
- El primer carácter indica el ámbito: `B`=Banca, `T`=Tarjetas, `C`=Corporativo
- Se omite para que el nombre del objeto no supere 10 chars
- `BBRI` → `BRI` (se omite `B`)
- Validar con AVP COMPLETO (`BBRI`); crear con AVP TRUNCADO (`BRI`)

## Paso 2 — Buscar Abreviaturas por Concepto de Negocio

```sql
-- Consultar por concepto, no por código
CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'maestro');
-- Retorna: MST | Maestro | Maestro

CALL LIBMHV.UBDP_CONSULTA_ABREVIATURAS('', 'transaccion');
-- Retorna: TRN | Transaccion | Transaccion
```

**Notas:**
- Consultá siempre por concepto de negocio, nunca por código directo
- Si hay múltiples resultados, seleccioná la opción más apropiada al contexto
- **Nunca uses abreviaturas hardcodeadas** — siempre obtenerlas dinámicamente

## Paso 3 — Validar Nombre con AVP Completo

```sql
-- Tipos: 'A'=Tabla, 'I'=Índice, 'T'=Trigger, 'P'=Procedure
CALL LIBMHV.UBDP_VALIDAR_NOMBRES('BBRI', 'A', 'MST', 'TRN');
```

**Resultado esperado:** Nombre correcto ✓

## Paso 4 — Componer Nombre con AVP Truncado

| Segmento | Valor | Fuente |
|----------|-------|--------|
| AVP truncado | `BRI` | UBDP_CONSULTA_AVP → truncar primer char de BBRI |
| Tipo | `A` | Regla de nomenclatura (A=Tabla) |
| ABR1 | `MST` | UBDP_CONSULTA_ABREVIATURAS('maestro') |
| ABR2 | `TRN` | UBDP_CONSULTA_ABREVIATURAS('transaccion') |
| **Nombre corto** | **`BRIAMSTTRN`** | BRI+A+MST+TRN = 10 chars ✓ |
| Nombre largo | `BRIDGER_MAESTRO_TRANSACCIONES` | Descriptivo UPPERCASE |
| RCDFMT | `BRIRMSTTRN` | Reemplazar `A` por `R` → BRI+R+MST+TRN |

## Verificar que el objeto no exista

```sql
SELECT TABLE_NAME, TABLE_SCHEMA, TABLE_TEXT
FROM QSYS2.SYSTABLES
WHERE TABLE_SCHEMA = 'LIBRERIAOBJ'
  AND TABLE_NAME = 'BRIAMSTTRN';
-- Sin resultados → OK para crear
```
