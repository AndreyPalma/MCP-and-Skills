---
name: bac-db2-standards
version: 1.0.0
description: >
  Diseño y revisión de objetos de base de datos DB2 para BAC Credomatic.
  Esta skill debe usarse cuando el usuario solicite revisar diseños de base de datos,
  crear tablas, vistas, índices, stored procedures, o cualquier objeto DB2 para BAC Credomatic.
  También debe dispararse cuando el usuario mencione "estándares de base de datos", "revisar diseño",
  "crear tabla", "procedimiento almacenado", "diseño DB2", "validar FK", "crear índice de rendimiento",
  "diseñar stored procedure", "enviar por RFC", "checklist DBA",
  o necesite verificar cumplimiento con las políticas de datos de BAC Credomatic.
---

# BAC Credomatic DB2 Standards

Guía de estándares para diseño y revisión de objetos DB2 en BAC Credomatic.
Actúa como **arquitecto de datos**: diseña con rigor, valida con los 107 checkpoints,
y entrega documentación completa.

## Modos de Operación

### Modo Diseño — "Necesito crear un objeto"
1. Clarificar tipo, propósito, región y carpeta destino.
2. Ejecutar el workflow UBDP (AVP → abreviaturas → validar nombre).
3. Cargar las referencias según el tipo de objeto.
4. Generar SQL completo.

### Modo Revisión — "Revisá este diseño / cumple estándares"
1. Recibir el diseño del usuario.
2. Cargar las referencias del tipo de objeto.
3. Aplicar los 107 checkpoints.
4. Reportar hallazgos con correcciones sugeridas.

---

## Workflow Obligatorio de Nomenclatura (UBDP)

**Ejecutar ANTES de diseñar cualquier objeto.** Los 3 stored procedures están en `LIBMHV`:

```
1. UBDP_CONSULTA_AVP            → obtener el AVP del aplicativo
2. UBDP_CONSULTA_ABREVIATURAS   → obtener ABR1 y ABR2 por concepto de negocio
3. UBDP_VALIDAR_NOMBRES         → validar el nombre compuesto [AVP][TIPO][ABR1][ABR2]
```

**Regla de truncamiento AVP:** Los AVP de 4 chars omiten el primer char para objetos
(B=Banca, T=Tarjetas, C=Corporativo). Validar con AVP completo; crear con AVP truncado.

**Fórmula del nombre** según tipo:

| Tipo | Fórmula | Consecutivo | Ejemplo |
|------|---------|-------------|--------|
| Tabla (A), SP (P), Trigger (T), UDF (F) | `[AVP(3)][TIPO(1)][ABR1(3)][ABR2(3)]` | — | BRIAMSTTRN |
| Índice | `[TABLA(máx 8)][NN]` | 01..99 en SYSINDEXES | BRIASBCB01 |
| Vista SQL | `[TABLA_PRINC(máx 8)][NN]` | 01..99 en SYSTABLES | CUMST05 |
| LF / Archivo Lógico | `[TABLA(máx 7)][V][NN]` | 01..99 en SYSTABLES | MCCACANV01 |
| FK Script sube/baja | `[AVP(3)][S][NNN][S/B]` | 001..999 en filesystem | MCCS001S/B |

**Tipos válidos para UBDP:** `A`=Tabla, `I`=Índice, `T`=Trigger, `P`=Procedure, `F`=Función.
Vistas y LF no pasan por UBDP_VALIDAR_NOMBRES.

Consecutivo: buscar el último usado en catálogo o filesystem → incrementar. Si ninguno existe → empezar en 01 (o 001 para FK).

**Ejemplo completo:** Ver [`examples/workflow-ubdp.md`](examples/workflow-ubdp.md)

---

## Referencias por Tipo de Objeto

Cargá solo las referencias que el objeto necesita.

| # | Referencia | Archivo | Cuándo cargar |
|---|-----------|---------|---------------|
| 1 | **Nomenclaturas** | `references/nomenclaturas.md` | SIEMPRE — todos los objetos. >5k palabras: buscar sección por tipo |
| 2 | **Completitud** | `references/completitud.md` | SIEMPRE — tablas, RFCs |
| 3 | **Documentación** | `references/documentacion.md` | SIEMPRE — todos los objetos |
| 4 | **Modelo Físico** | `references/modelo-fisico.md` | Tablas |
| 5 | **Normalización** | `references/normalizacion.md` | Tablas |
| 6 | **Integridad de Datos** | `references/integridad-datos.md` | Tablas |
| 7 | **Restricciones** | `references/restricciones.md` | Tablas |
| 8 | **Índices** | `references/indices.md` | Índices |
| 9 | **Estándares** | `references/estandares.md` | Stored procedures, todos |
| 10 | **Campo Mappings** | `references/campo-mappings.md` | Al definir nombres de campos FOR — solo consulta, no usar abreviaturas directamente |

### Mapa de dependencias

```
nomenclaturas.md ──→ completitud.md      (nombres antes de definir estructura)
modelo-fisico.md ──→ normalizacion.md    (tipos de datos y relaciones juntos)
integridad-datos.md ──→ restricciones.md (constraints y sus reglas técnicas)
indices.md ──→ modelo-fisico.md          (índices necesitan entender la tabla)
```

---

## Carga a Demanda

Comenzá siempre con `nomenclaturas.md` + `documentacion.md`. Luego cargá solo lo que el tipo de objeto requiere (ver tabla de referencias). No cargues todas las referencias al inicio.

---

## Workflow de Diseño

Cuando el usuario solicite crear o revisar objetos de base de datos, seguí este proceso:

### 1. Entender el Requerimiento

Clarificar: tipo de objeto, propósito, contexto regional (multi-país/moneda/banco),
volumen esperado, datos sensibles, carpeta destino (default: `qsrcsql/`).

**Obligatorio siempre — nunca inferir:** biblioteca de producción y AVP del aplicativo.

### 2. Verificar Pre-requisitos

Antes de diseñar, buscar objetos similares en DB2 por descripción:

```sql
SELECT TABLE_NAME, TABLE_SCHEMA, TABLE_TEXT, TABLE_TYPE
FROM QSYS2.SYSTABLES
WHERE TABLE_TEXT IS NOT NULL
  AND (UPPER(TABLE_TEXT) LIKE UPPER('%keyword1%')
    OR UPPER(TABLE_TEXT) LIKE UPPER('%keyword2%')
    OR UPPER(TABLE_TEXT) LIKE UPPER('%keyword3%'))
  AND TABLE_TYPE IN ('T', 'V', 'P')
  AND TABLE_SCHEMA NOT LIKE 'Q%'
ORDER BY TABLE_NAME
FETCH FIRST 10 ROWS ONLY;
```

**Regla:** Siempre proceder con el diseño del nuevo objeto. Si se encuentran similares,
informar al usuario en la sección "⚠️ Posibles Objetos Similares" para que evalúe si
necesita crear uno nuevo o puede reutilizar uno existente. Si no hay similares, indicar
explícitamente "No se encontraron objetos con descripción similar."

También verificar:
- ¿Se pueden reutilizar tablas existentes del "core"?
- ¿Contiene datos sensibles? → coordinar con Gerencia de Datos Sensibles.

### 3. Aplicar Checklist de Revisión

Ejecutar el workflow UBDP (ver [Workflow Obligatorio](#workflow-obligatorio-de-nomenclatura-ubdp)).
Cargar las referencias según el tipo (ver [tabla de referencias](#referencias-por-tipo-de-objeto)).

### 4. Generar los Archivos

Generar entre 1 y 3 archivos en la carpeta designada:
1. **`[NOMBRE_CORTO].[ext]`** — código SQL (CREATE + COMMENT ON + LABEL ON + PK/CHECK constraints)
2. **`[AVP]S[NNN]S.sql`** — sube integridad referencial (ADD CONSTRAINT FOREIGN KEY) _(si aplica)_
3. **`[AVP]S[NNN]B.sql`** — baja integridad referencial (DROP CONSTRAINT) _(si aplica)_

**Regla de Integridad Referencial:** Las FK constraints **NUNCA** van dentro del `CREATE TABLE`.
Se generan en scripts separados por proyecto. Si ya existen scripts del proyecto, agregar los
nuevos ADD/DROP a los existentes. Ver ejemplos: [`examples/mccs001s.sql`](examples/mccs001s.sql)
y [`examples/mccs001b.sql`](examples/mccs001b.sql).

Extensiones: `.table` / `.index` / `.view` / `.sqlprc` / `.sqludf` / `.lf` / `.trigger` / `.sql`

### Ejemplos por Tipo de Objeto

Todos los ejemplos están aprobados por DBA y se encuentran en `examples/`.

| Tipo | Archivo | Objeto |
|------|---------|--------|
| Tabla maestro | [`mccacanpar.table`](examples/mccacanpar.table) | Parámetros por canal (maestro) |
| Tabla bitácora | [`mccacanpab.table`](examples/mccacanpab.table) | Parámetros por canal (bitácora) |
| Tabla trabajo | [`mccacanpat.table`](examples/mccacanpat.table) | Parámetros por canal (temporal) |
| Vista SQL | [`cumst05.view`](examples/cumst05.view) | Consulta cliente por cuenta |
| Archivo lógico | [`mccacanv01.lf`](examples/mccacanv01.lf) | Vista DDS sobre tabla maestro |
| Índice | [`briisbcb01.index`](examples/briisbcb01.index) | Índice de rendimiento IPL |
| Stored Procedure SQL | [`mccpvalcan.sqlprc`](examples/mccpvalcan.sqlprc) | Validación de canal |
| Stored Procedure RPG | [`mccpejcacb.sqlprc`](examples/mccpejcacb.sqlprc) | Interfaz para programa RPG |
| Función tabla | [`ibsftestot.sqludf`](examples/ibsftestot.sqludf) | Totales de tesorería por cajas |
| Integridad up | [`mccs001s.sql`](examples/mccs001s.sql) | Subir FK del módulo MCC |
| Integridad down | [`mccs001b.sql`](examples/mccs001b.sql) | Bajar FK del módulo MCC |
| Workflow UBDP | [`workflow-ubdp.md`](examples/workflow-ubdp.md) | AVP → abreviaturas → validar |

### 5. Validar los 107 Checkpoints

Ver sección **Checklist de Validación** más abajo.

### 6. Confirmar al Usuario

Mostrar: archivos generados, AVP (4→3 chars), abreviaturas usadas,
nombre corto (≤10 chars), nombre largo (MAYÚSCULAS), resultado UBDP_VALIDAR_NOMBRES.

---

## Reglas AS400 (Obligatorias en Todo Objeto)

- Máximo **80 caracteres por línea**
- Nombres largos en **MAYÚSCULAS**
- Referencias siempre por **nombre corto** (≤10 chars)
- Sin guiones bajos dobles (`__`)
- `RCDFMT` obligatorio **solo en tablas físicas** (reemplazar char de tipo por `R`)
- `RENAME TABLE` obligatorio **solo en tablas físicas**; vistas usan `FOR SYSTEM NAME`
- **FK constraints NUNCA dentro del `CREATE TABLE`** — usar scripts S001S/S001B separados
- Campos de auditoría: `CHAR(18)` para usuarios, `TIMESTAMP` con `WITH DEFAULT USER/CURRENT TIMESTAMP`

---

## Checklist de Validación — 107 Checkpoints

**Completitud (11):** propósito documentado, alcance regional, volumen estimado, datos sensibles identificados, alternativas evaluadas.

**Modelo Físico (28):** tipos de datos apropiados, NOT NULL explícito, precisión en decimales (montos: DECIMAL(11,2), porcentajes: DECIMAL(4,2)), sin valores implícitos.

**Estándares (13):** nombre corto ≤10 chars, nombre largo UPPERCASE, prefijo de tipo correcto, campos en español.

**Normalización (10):** mínimo 3NF, sin dependencias parciales ni transitivas, sin grupos repetitivos, claves primarias apropiadas.

**Integridad (19):** PRIMARY KEY definida y nombrada, FOREIGN KEY con nombre explícito, CHECK constraints nombradas, sin UNIQUE INDEX (usar UNIQUE CONSTRAINT).

**Restricciones (9):** todas las constraints con nombre explícito, nomenclatura BAC, nombres de PKs correctos.

**Índices (5):** índices de rendimiento vs funcionales diferenciados, sin UNIQUE INDEX, nomenclatura correcta.

**Documentación (4):** COMMENT ON TABLE, COMMENT ON COLUMN (todos), LABEL ON TABLE, LABEL ON COLUMN IS + TEXT IS (todos). Sin descripciones genéricas.
**Nota por tipo:** Índices solo requieren header de comentarios. SPs/UDFs/Triggers usan COMMENT ON PROCEDURE/FUNCTION/TRIGGER. Vistas usan COMMENT ON TABLE + COLUMN sin LABEL ON.

**Nomenclatura (1):** UBDP_VALIDAR_NOMBRES retorna VÁLIDO.

---

## Principios Clave BAC Credomatic

**Multi-Región:** Diseñar siempre pensando en multi-país, multi-moneda, multi-banco.

**Reutilización:** Usar datos "core" existentes. No crear silos. Verificar objetos similares antes de diseñar uno nuevo.

**Calidad de Datos:** No campos multi-propósito, no diseños horizontales, no campos compuestos, no campos multivaluados, no campos derivados.

**Español por defecto:** Toda la base de datos en español. Excepción: términos de negocio justificados o tablas existentes en producción.

**SQL Puro:** No DDS, no archivos S/36, no archivos planos. Todo en SQL estándar DB2.

**Seguridad:** Seguir lineamientos de datos sensibles. No exponer CIF, tarjetas ni cuentas sin coordinación con el área de seguridad.

---

## Casos Especiales

**RFCs (cambios de datos en producción):** Script con UPDATE/DELETE usando llave primaria, rollback completo, validaciones pre/post, conteo esperado de registros. Ver `references/completitud.md`.

**Índices de rendimiento:** Enviar por RFC. Nomenclatura especial. Sin atributo UNIQUE. Justificar necesidad.

**Stored Procedures:** SELECT explícito de campos (nunca SELECT *). Metadata completa. Crear en misma biblioteca que tabla principal. Ver `references/estandares.md`.

---

## Límites Técnicos

- Máximo 10 cambios por historia de revisión
- No modificar archivos con restricción de cambios (ej. propios de IBS)
- No usar NVARCHAR/NCHAR sin justificación
- Vistas lógicas: generar nueva vista con cada cambio
- No índices UNIQUE (usar CONSTRAINT UNIQUE en tabla)
- No archivos multiformato sin justificación
