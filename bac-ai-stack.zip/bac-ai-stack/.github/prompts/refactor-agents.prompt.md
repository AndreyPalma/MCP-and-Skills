Necesito refactorizar el plugin ibmi-rpg con los agentes de RPG y sus skills asociadas rpg-best-practices y rpg-fw7-services
para eliminar el acoplamiento fuerte entre ambos.

### Principio rector

  Agente = QUÉ lograr + coordinación + formato de salida
  Skill  = CÓMO hacerlo (queries, reglas, fórmulas, templates, checkpoints)

### Paso 1 — Análisis de acoplamiento (solo leer, no modificar)

Lee los archivos:
- El agente: {RUTA_AGENTE}
- La skill principal: {RUTA_SKILL}
- Las referencias que usa la skill (si las tiene)

Identificá y reportá:

1. RUTAS HARDCODEADAS en el agente
   - Listar toda ruta a archivos de la skill que aparezca en el agente
   - (ej: `references/nomenclaturas.md`, `examples/*.sql`, `**/SKILL.md`)

2. CONTENIDO DUPLICADO entre agente y skill
   - Tablas, queries SQL, fórmulas, reglas que aparecen en AMBOS archivos
   - Indicar en qué sección de cada archivo aparece

3. CONOCIMIENTO TÉCNICO que solo vive en el agente y debería estar en la skill
   - Reglas de negocio, algoritmos, templates, fórmulas, criterios
   - Que NO dependen de la coordinación ni del formato de salida
   - Que son reutilizables por cualquier otro agente que use la misma skill

4. CONOCIMIENTO DE COORDINACIÓN que debe QUEDARSE en el agente
   - Propósito y descripción del agente
   - Protocolo de carga de la skill (cómo cargarla, no qué contiene)
   - Tripwires y límites operacionales (máximo de queries, condiciones de stop)
   - QUÉ datos pedirle al usuario (no CÓMO procesarlos)
   - Pasos de alto nivel (qué hacer, no cómo hacerlo)
   - Formato de salida / retorno estructurado
   - Reglas conductuales del agente

Presentá el diagnóstico en este formato antes de hacer cualquier cambio:

  ### Diagnóstico de Acoplamiento

  **Rutas hardcodeadas en el agente:**
  | Ruta | Aparece en sección |
  
  **Contenido duplicado:**
  | Contenido | En agente (sección) | En skill (sección) |
  
  **Conocimiento técnico a mover a la skill:**
  | Contenido | Actualmente en | Sección destino en skill |
  
  **Conocimiento de coordinación que se queda en el agente:**
  | Contenido | Razón |

### Paso 2 — Refactorización de la Skill

Modificá la skill para que sea la fuente de verdad de TODO el conocimiento técnico.

Reglas para la skill:
- NO debe mencionar el nombre de ningún agente específico
- NO debe asumir un flujo conversacional — es un libro de reglas, no un procedimiento
- DEBE tener secciones con nombres estables y descriptivos (los agentes las referenciarán por nombre)
- DEBE absorber todo lo que identificaste en el Paso 1 como "conocimiento técnico"
- PUEDE tener un índice claro al inicio para que los agentes sepan qué sección buscar
- Si el conocimiento ya existía en la skill de forma resumida, expandirlo con el detalle que vivía en el agente
- Mantener las referencias a archivos externos DENTRO de la skill (los agentes no deben saber que existen)

Estructura recomendada para la skill refactorizada:
  1. Frontmatter (sin cambios — name, context, description, triggers)
  2. Índice de secciones (qué contiene la skill y para qué sirve cada sección)
  3. Secciones de conocimiento técnico (una por dominio, con nombres estables)
  4. Tabla de referencias externas si aplica (solo dentro de la skill)
  5. Principios y límites técnicos

### Paso 3 — Refactorización del Agente

Modificá el agente para que sea delgado: solo coordinación, no conocimiento.

Reglas para el agente:
- El protocolo de carga de la skill dice CÓMO cargarla (pasos), no DÓNDE están sus archivos internos
- Cada paso del workflow dice QUÉ hacer y referencia la SECCIÓN de la skill donde está el CÓMO
  - ❌ PROHIBIDO: "Ejecutá esta query SQL: SELECT TABLE_NAME FROM..."
  - ✅ CORRECTO: "Ejecutá la query de verificación que la skill define en 'Queries de Descubrimiento'"
  - ❌ PROHIBIDO: "Cargá references/nomenclaturas.md, references/completitud.md..."
  - ✅ CORRECTO: "Cargá las referencias según el tipo de objeto — la skill define qué cargar en 'Referencias por Tipo'"
- No debe contener tablas de fórmulas, queries SQL, reglas AS400, templates de código
- DEBE mantener: propósito, protocolo de carga, tripwires, formato de salida, reglas conductuales
- El formato de salida (reporte, retorno estructurado) SÍ vive en el agente — es parte de su contrato

Estructura recomendada para el agente refactorizado:
  1. Frontmatter (sin cambios — name, description, examples, tools, model, color)
  2. Propósito (2-4 líneas)
  3. Skill Requerida (qué contiene + protocolo de carga)
  4. Reglas de Carga de Contexto (permitido / prohibido / tripwires)
  5. Lo Que Necesitás del Usuario (inputs mínimos)
  6. Qué Hacer (pasos de alto nivel, cada uno referenciando secciones de la skill)
  7. Formato de Retorno (el reporte visible + el bloque estructurado)
  8. Reglas Conductuales (comportamiento del agente, no reglas de negocio)

### Criterios de Validación

Antes de dar el trabajo por terminado, verificá:

[ ] El agente NO contiene ninguna ruta a archivos internos de la skill
[ ] El agente NO contiene queries SQL, fórmulas, o templates de código
[ ] El agente NO contiene tablas de reglas técnicas que ya están en la skill
[ ] La skill NO menciona el nombre de ningún agente específico
[ ] La skill tiene secciones con nombres estables que los agentes pueden referenciar
[ ] Si se reorganizan las referencias internas de la skill, el agente no necesita cambios
[ ] Si se agrega un nuevo tipo de objeto, solo cambia la skill, no el agente
[ ] El formato de salida del agente es completo y no depende de la skill para renderizarse

### Notas adicionales

- Si encontrás que el agente realiza tareas que son completamente redundantes con lo que
  ya hace la skill (misma lógica, misma descripción), evaluá si esa tarea debería ser
  simplemente "seguir la sección X de la skill" o si existe un motivo real para duplicarla.

- Si encontrás contenido en el agente que NO encaja ni en "coordinación" ni en "conocimiento
  técnico de la skill" (ej: reglas de formato de salida muy específicas al agente),
  dejalo en el agente — no todo debe migrarse.

- Si la skill tiene múltiples agentes consumidores, asegurate de que el conocimiento migrado
  sea realmente genérico y aplicable a todos, no específico de un agente.