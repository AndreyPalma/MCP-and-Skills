# Arquitectura Multi-Agente IBM i — Claude Code (VS Code)

## Estructura de Archivos

Coloca todos los archivos `.md` en tu proyecto dentro de `.claude/agents/`:

```
tu-proyecto/
└── .claude/
    └── agents/
        ├── intake-agent.md          ← Capa 0: captura requerimiento
        ├── master-orchestrator.md   ← Capa 1: coordina todo
        ├── research-agent.md        ← Pre-Dev: exploración de specs/código
        ├── impact-agent.md          ← Pre-Dev: análisis de impacto
        ├── spec-builder-agent.md    ← Pre-Dev: construye especificación técnica
        ├── rpg-orchestrator.md      ← Dev: coordina pipeline RPG
        ├── rpg-explorar.md          ← Dev RPG: lee y extrae contexto
        ├── rpg-aplicar.md           ← Dev RPG: aplica cambios de código
        ├── rpg-verificar.md         ← Dev RPG: verifica cambios
        ├── db2-orchestrator.md      ← Dev: coordina pipeline DB2
        ├── db2-explorar.md          ← Dev DB2: lee estructura actual
        ├── db2-aplicar.md           ← Dev DB2: aplica DDL
        ├── db2-verificar.md         ← Dev DB2: verifica cambios
        ├── verification-agent.md    ← Post-Dev: verificación cross-dominio
        └── doc-agent.md             ← Post-Dev: actualiza specs y documentación
```

## Flujo de Ejecución

```
Usuario (conversación directa)
    │
    ▼
[intake-agent]          → Produce: Request Package
    │
    ▼
[master-orchestrator]   → Lee: Request Package
    │
    ├─── PRE-DEV PIPELINE ──────────────────────────────────┐
    │    [research-agent]    → Produce: Dependency Map      │
    │    [impact-agent]      → Produce: Impact Report       │
    │    [spec-builder-agent]→ Produce: Technical Spec      │
    │    ← Usuario aprueba la spec antes de continuar →     │
    │                                                        │
    ├─── DEV PIPELINE ──────────────────────────────────────┤
    │    SOLO_DB2:  [db2-orchestrator]                      │
    │    SOLO_RPG:  [rpg-orchestrator]                      │
    │    CROSS:     [db2-orchestrator] → ✓ → [rpg-orch]    │
    │                                                        │
    └─── POST-DEV PIPELINE ─────────────────────────────────┘
         [verification-agent] → verificación cross-dominio
         [doc-agent]          → actualiza OpenSpec + docs
```

## Estructura OpenSpec Recomendada

```
tu-proyecto/
└── openspec/
    ├── specs/
    │   ├── programs/
    │   │   ├── RPGCLI01/spec.md
    │   │   └── RPGFAC01/spec.md
    │   ├── tables/
    │   │   ├── CLIENTES/spec.md
    │   │   └── PEDIDOS/spec.md
    │   └── cross/
    │       └── CLIENTES-programs/spec.md  ← relaciones cross-dominio
    └── changes/
        └── REQ-20250120-143022/
            ├── proposal.md
            ├── design.md
            ├── tasks.md
            ├── technical-spec.md
            └── execution-summary.md
```

## Reglas de Contexto (gestión de ventana)

| Agente | Recibe | NO recibe |
|--------|--------|-----------|
| research-agent | Request Package | conversación del usuario |
| impact-agent | Dependency Map + Request Package | código fuente completo |
| spec-builder-agent | Request Package + Map + Impact | conversación |
| rpg-orchestrator | Sección RPG de la spec | sección DB2 |
| db2-orchestrator | Sección DB2 de la spec | sección RPG |
| rpg-explorar | Nombres de programas + spec | código de otros programas |
| rpg-aplicar | Contexto extraído + spec | programa completo |
| verification-agent | Spec + Execution Reports | código fuente |
| doc-agent | Todos los reports | conversación del usuario |

## Colores por Capa

- 🔵 `blue` — Orquestadores (master, rpg, db2)
- 🩵 `cyan` — Exploración (intake, research, rpg-explorar, db2-explorar)
- 🟢 `green` — Aplicación (spec-builder, rpg-aplicar, db2-aplicar)
- 🟡 `yellow` — Verificación (impact, rpg-verificar, db2-verificar, verification)
- 🟣 `magenta` — Documentación (doc-agent)

## Activación

Con todos los archivos en `.claude/agents/`, Claude Code los auto-descubre.
El flujo comienza cuando describes un requerimiento al usuario — el intake-agent
se activa automáticamente por su descripción.
